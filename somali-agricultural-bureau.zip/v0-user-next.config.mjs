/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true, // Required for static export
  },
  // This is important for static export to ensure proper path resolution
  trailingSlash: true,
};

export default nextConfig;

