"use client"

import { createContext, useContext, type ReactNode, useState, useEffect } from "react"

// Define the shape of our translations
export type Translations = {
  [key: string]: string
}

export type Language = "en" | "so" | "am"

// Define the context type
type TranslationContextType = {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string, params?: Record<string, string | number>) => string
}

// Create the context with default values
const TranslationContext = createContext<TranslationContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key) => key,
})

// Translation data
const translations: { [key in Language]: Translations } = {
  en: {
    // Header and Navigation
    "nav.home": "Home",
    "nav.about": "About Us",
    "nav.directorates": "Directorates",
    "nav.programs": "Programs & Projects",
    "nav.resources": "Resources",
    "nav.news": "News & Events",
    "nav.vacancies": "Vacancies",
    "nav.contact": "Contact Us",
    "nav.announcements": "Announcements",
    "bureau.name": "SRS Agriculture Bureau",
    "bureau.tagline": "Leading Agricultural Excellence and Innovation",

    // Directorate submenu
    "nav.directorates.crop": "Agricultural Production",
    "nav.directorates.extension": "Agricultural Extension",
    "nav.directorates.natural": "Natural Resources",
    "nav.directorates.irrigation": "Irrigation Development",
    "nav.directorates.food": "Food Security",
    "nav.directorates.marketing": "Marketing & Cooperatives",
    "nav.directorates.full.crop": "Agricultural Production and Crop Protection Directorate",
    "nav.directorates.full.extension": "Agricultural Extension and Technology Transfer Directorate",
    "nav.directorates.full.natural": "Natural Resources Development and Management Directorate",
    "nav.directorates.full.irrigation": "Small-Scale Irrigation Development Directorate",
    "nav.directorates.full.food": "Food Security and Nutrition Directorate",
    "nav.directorates.full.marketing": "Marketing and Cooperative Development Directorate",

    // Programs submenu
    "nav.programs.psnp": "PSNP-5 Program",
    "nav.programs.drdip": "DRDIP-II",
    "nav.programs.pact": "PACT",
    "nav.programs.crew": "CREW",

    // Resources submenu
    "nav.resources.policy": "Policy and Strategy",
    "nav.resources.plans": "Plans and Reports",
    "nav.resources.proclamations": "Proclamations",
    "nav.resources.directives": "Directives",
    "nav.resources.regulations": "Regulations",
    "nav.resources.manuals": "Manuals and Guidelines",
    "nav.resources.publications": "Publications",

    // Announcements submenu
    "nav.announcements.jobs": "Job Vacancy",
    "nav.announcements.tenders": "Tender",

    // Common elements
    "back.to.directorates": "Back to Directorates",
    director: "Director",
    email: "Email",
    phone: "Phone",
    office: "Office",
    programs: "Programs",
    relatedResources: "Related Resources",
    contactDirectorate: "Contact This Directorate",
    keyServices: "Key Services",
    overview: "Overview",
    "contact.us": "Contact Us",
    "send.message": "Send us a message",
    "contact.form.desc": "Fill out the form below to get in touch with us",
    name: "Name",
    message: "Message",
    submit: "Submit",
    "contact.info": "Contact Information",
    "contact.reach": "Reach out to us through the following channels",
    address: "Address",
    website: "Website",
    "office.location": "Office Location",
    "map.desc": "View our office location on the map",
    "bureau.head.title": "Message from the Bureau Head",
    "bureau.head.name": "Abdulahi Mohamed Muse",
    "bureau.head.position": "Head of Bureau, SRS Agricultural Bureau",
    "bureau.head.message1":
      "It is my great pleasure to welcome you to the official website of the Somali Regional State Agricultural Bureau. Our bureau is committed to transforming the agricultural sector in our region, ensuring food security, and improving the livelihoods of our farmers and pastoralists.",
    "bureau.head.message2":
      "Through this website, we aim to provide you with valuable information about our programs, services, and initiatives. We invite you to explore our website and learn more about our work. Thank you for your interest in the Somali Regional State Agricultural Bureau.",
    "vision.short":
      "To see the pastoral and agro-pastoral communities in the region moved from the subsistence pastoralist and farming system to self-reliance market-oriented production and become one of marketable products suppliers in the horn of Africa.",
    "mission.short":
      "To transform the existing pastoralists and agro-pastoralists way of life of the region to a modern sustainable production system, by adopting the appropriate agriculture technologies and to eventually alleviate the deeply rooted poverty of the region.",
    "bureau.goal": "Our Goal",
    "goal.text":
      "To promote sustainable agricultural development and improve the livelihoods of farmers and pastoralists in the Somali Region.",
    "news.title": "Recent News",
    "news.item": "News Item {number}",
    "news.item.title": "News Title {number}",
    "news.item.desc":
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor.",
    "news.readmore": "Read More",
    "partners.title": "Development Partners",
    partner: "Partner {number}",
    "weather.current": "Current Weather in Jijiga",
    "weather.jijiga": "Jijiga",
    "weather.sunny": "Sunny",
    "weather.cloudy": "Cloudy",
    "weather.rainy": "Rainy",
    "weather.humidity": "Humidity",
    "weather.rain": "Chance of Rain",
    "stats.cultivated": "Cultivated Land",
    "stats.land": "Irrigated Land",
    "stats.agricultural": "Agricultural Production",
    "stats.forest": "Forest Cover",
    "stats.hectares": "Hectares",
    "banner.title1": "Empowering Farmers, Transforming Agriculture",
    "banner.desc1":
      "We are dedicated to supporting farmers and promoting sustainable agricultural practices in the Somali Region.",
    "banner.title2": "Investing in Innovation, Building a Sustainable Future",
    "banner.desc2":
      "We are committed to investing in innovative technologies and building a sustainable future for agriculture in our region.",
    "banner.title3": "Working Together for a Prosperous Agricultural Community",
    "banner.desc3":
      "We believe in the power of collaboration and are working together with our partners to build a prosperous agricultural community in the Somali Region.",
    "banner.previous": "Previous slide",
    "banner.next": "Next slide",
    "footer.quicklinks": "Quick Links",
    "quicklinks.services": "Our Services",
    "announcements.jobs.title": "Job Vacancies",
    "footer.contact": "Contact Us",
    "footer.copyright": "© 2025 Somali Regional State Agricultural Bureau. All rights reserved.",
    "directorates.title": "Our Directorates",
    "directorates.intro":
      "Explore the specialized directorates within the Somali Regional State Agricultural Bureau, each dedicated to specific areas of agricultural development and natural resource management.",
    "directorates.keyservices": "Key Services",
    "directorates.learnmore": "Learn More",
    "directorates.collaboration.title": "Collaboration for Impact",
    "directorates.collaboration.text":
      "We actively collaborate with local communities, government agencies, and international partners to maximize the impact of our programs and initiatives.",
    // Not Found Page
    "not_found.title": "Page Not Found",
    "not_found.message": "The page you are looking for doesn't exist or has been moved.",
    "not_found.back_home": "Back to Home",
  },
  so: {
    // Header and Navigation
    "nav.home": "Hoyga",
    "nav.about": "Naga Warbixi",
    "nav.directorates": "Agaasimayaasha",
    "nav.programs": "Barnaamijyada & Mashaariicda",
    "nav.resources": "Ilaha",
    "nav.news": "Wararka & Dhacdooyinka",
    "nav.vacancies": "Banaanbaxyada Shaqada",
    "nav.contact": "Nala Soo Xiriir",
    "nav.announcements": "Ogeysiisyada",
    "bureau.name": "Xafiiska Beeraha ee SRS",
    "bureau.tagline": "Hoggaaminta Heerka Sare ee Beeraha iyo Hal-abuurka",

    // Directorate submenu
    "nav.directorates.crop": "Wax Soo Saarka Beeraha",
    "nav.directorates.extension": "Fidinta Beeraha",
    "nav.directorates.natural": "Kheyraadka Dabiiciga ah",
    "nav.directorates.irrigation": "Horumarinta Waraabka",
    "nav.directorates.food": "Amniga Cuntada",
    "nav.directorates.marketing": "Suuqgeynta & Iskaashatooyinka",
    "nav.directorates.full.crop": "Agaasinka Wax Soo Saarka Beeraha iyo Ilaalinta Dalagga",
    "nav.directorates.full.extension": "Agaasinka Fidinta Beeraha iyo Wareejinta Tignoolajiyada",
    "nav.directorates.full.natural": "Agaasinka Horumarinta iyo Maareynta Kheyraadka Dabiiciga ah",
    "nav.directorates.full.irrigation": "Agaasinka Horumarinta Waraabka Yar",
    "nav.directorates.full.food": "Agaasinka Amniga Cuntada iyo Nafaqada",
    "nav.directorates.full.marketing": "Agaasinka Suuqgeynta iyo Horumarinta Iskaashatooyinka",

    // Programs submenu
    "nav.programs.psnp": "Barnaamijka PSNP-5",
    "nav.programs.drdip": "DRDIP-II",
    "nav.programs.pact": "PACT",
    "nav.programs.crew": "CREW",

    // Resources submenu
    "nav.resources.policy": "Siyaasadda iyo Istaraatiijiyadda",
    "nav.resources.plans": "Qorshayaasha iyo Warbixinnada",
    "nav.resources.proclamations": "Baaqashooyinka",
    "nav.resources.directives": "Tilmaamaha",
    "nav.resources.regulations": "Xeerarka",
    "nav.resources.manuals": "Buugaagta iyo Tilmaamaha",
    "nav.resources.publications": "Daabacaadaha",

    // Announcements submenu
    "nav.announcements.jobs": "Shaqo Banaan",
    "nav.announcements.tenders": "Tender",

    // Common elements
    "back.to.directorates": "Ku Noqo Agaasimayaasha",
    director: "Agaasime",
    email: "Iimaylka",
    phone: "Telefoonka",
    office: "Xafiiska",
    programs: "Barnaamijyada",
    relatedResources: "Ilaha La Xiriira",
    contactDirectorate: "La Xiriir Agaasimkan",
    keyServices: "Adeegyada Muhiimka ah",
    overview: "Guudmar",
    "contact.us": "Nala Soo Xiriir",
    "send.message": "Noo soo dir fariin",
    "contact.form.desc": "Buuxi foomka hoose si aad noola soo xiriirto",
    name: "Magaca",
    message: "Fariinta",
    submit: "Dir",
    "contact.info": "Macluumaadka Xiriirka",
    "contact.reach": "Nala soo xiriir kanaalada soo socda",
    address: "Cinwaanka",
    website: "Websaydhka",
    "office.location": "Goobta Xafiiska",
    "map.desc": "Ka eeg goobta xafiiskeena khariidadda",
    // Not Found Page
    "not_found.title": "Bogga Lama Helin",
    "not_found.message": "Bogga aad raadinaysaa ma jiro ama waa la wareejiyay.",
    "not_found.back_home": "Ku Noqo Bogga Hore",
  },
  am: {
    // Header and Navigation
    "nav.home": "ቤት",
    "nav.about": "ስለ እኛ",
    "nav.directorates": "ዳይሬክቶሬቶች",
    "nav.programs": "ፕሮግራሞች እና ፕሮጀክቶች",
    "nav.resources": "ሀብቶች",
    "nav.news": "ዜና እና ክስተቶች",
    "nav.vacancies": "ክፍት የስራ ቦታዎች",
    "nav.contact": "ያግኙን",
    "nav.announcements": "ማስታወቂያዎች",
    "bureau.name": "የ SRS ግብርና ቢሮ",
    "bureau.tagline": "በግብርና የላቀነት እና ፈጠራን መምራት",

    // Directorate submenu
    "nav.directorates.crop": "የግብርና ምርት",
    "nav.directorates.extension": "የግብርና ኤክስቴንሽን",
    "nav.directorates.natural": "የተፈጥሮ ሀብት",
    "nav.directorates.irrigation": "የመስኖ ልማት",
    "nav.directorates.food": "የምግብ ዋስትና",
    "nav.directorates.marketing": "ግብይት እና ትብብር",
    "nav.directorates.full.crop": "የግብርና ምርት እና የሰብል ጥበቃ ዳይሬክቶሬት",
    "nav.directorates.full.extension": "የግብርና ኤክስቴንሽን እና የቴክኖሎጂ ሽግግር ዳይሬክቶሬት",
    "nav.directorates.full.natural": "የተፈጥሮ ሀብት ልማት እና አስተዳደር ዳይሬክቶሬት",
    "nav.directorates.full.irrigation": "አነስተኛ የመስኖ ልማት ዳይሬክቶሬት",
    "nav.directorates.full.food": "የምግብ ዋስትና እና የተመጣጠነ ምግብ ዳይሬክቶሬት",
    "nav.directorates.full.marketing": "የግብይት እና የህብረት ስራ ማህበራት ልማት ዳይሬክቶሬት",

    // Programs submenu
    "nav.programs.psnp": "የ PSNP-5 ፕሮግራም",
    "nav.programs.drdip": "DRDIP-II",
    "nav.programs.pact": "PACT",
    "nav.programs.crew": "CREW",

    // Resources submenu
    "nav.resources.policy": "ፖሊሲ እና ስትራቴጂ",
    "nav.resources.plans": "ዕቅዶች እና ሪፖርቶች",
    "nav.resources.proclamations": "አዋጆች",
    "nav.resources.directives": "መመሪያዎች",
    "nav.resources.regulations": "ደንቦች",
    "nav.resources.manuals": "መመሪያዎች እና መመሪያዎች",
    "nav.resources.publications": "ህትመቶች",

    // Announcements submenu
    "nav.announcements.jobs": "ክፍት የሥራ ቦታ",
    "nav.announcements.tenders": "ጨረታ",

    // Common elements
    "back.to.directorates": "ወደ ዳይሬክቶሬቶች ተመለስ",
    director: "ዳይሬክተር",
    email: "ኢሜይል",
    phone: "ስልክ",
    office: "ቢሮ",
    programs: "ፕሮግራሞች",
    relatedResources: "ተዛማጅ ሀብቶች",
    contactDirectorate: "ይህን ዳይሬክቶሬት ያግኙ",
    keyServices: "ዋና አገልግሎቶች",
    overview: "አጠቃላይ እይታ",
    "contact.us": "ያግኙን",
    "send.message": "መልዕክት ይላኩልን",
    "contact.form.desc": "እባክዎን ከዚህ በታች ያለውን ቅጽ ይሙሉ",
    name: "ስም",
    message: "መልዕክት",
    submit: "አስገባ",
    "contact.info": "የመገኛ መረጃ",
    "contact.reach": "በሚከተሉት ቻናሎች ያግኙን",
    address: "አድራሻ",
    website: "ድህረ ገጽ",
    "office.location": "የቢሮ ቦታ",
    "map.desc": "የቢሮአችንን ቦታ በካርታው ላይ ይመልከቱ",
    // Not Found Page
    "not_found.title": "ገጹ አልተገኘም",
    "not_found.message": "እየፈለጉት ያለው ገጽ የለም ወይም ተንቀሳቅሷል።",
    "not_found.back_home": "ወደ መነሻ ገጽ ተመለስ",
  },
}

// Provider component
export const TranslationProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>("en")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language | null
    if (savedLanguage && ["en", "so", "am"].includes(savedLanguage)) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  // Translation function with parameter support
  const t = (key: string, params?: Record<string, string | number>): string => {
    let text = translations[language][key] || key

    // Replace parameters if provided
    if (params) {
      Object.entries(params).forEach(([param, value]) => {
        text = text.replace(`{${param}}`, String(value))
      })
    }

    return text
  }

  return <TranslationContext.Provider value={{ language, setLanguage, t }}>{children}</TranslationContext.Provider>
}

// Custom hook to use the translation context
export const useTranslation = () => useContext(TranslationContext)

