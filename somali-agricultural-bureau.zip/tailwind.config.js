/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
    "*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Custom colors for the agricultural theme
        earth: {
          100: "#f5f1e6", // light beige
          200: "#e6dcc8", // beige
          300: "#c8b28e", // tan
          400: "#a68a64", // light brown
          500: "#8c6d46", // medium brown
          600: "#6b5338", // dark brown
          700: "#4d3c28", // very dark brown
        },
        foliage: {
          100: "#e8f5e9", // very light green
          200: "#c8e6c9", // light green
          300: "#a5d6a7", // medium-light green
          400: "#81c784", // medium green
          500: "#66bb6a", // medium-dark green
          600: "#4caf50", // dark green
          700: "#388e3c", // very dark green
          800: "#2e7d32", // forest green
        },
        water: {
          100: "#e1f5fe", // very light blue
          200: "#b3e5fc", // light blue
          300: "#81d4fa", // medium-light blue
          400: "#4fc3f7", // medium blue
          500: "#29b6f6", // medium-dark blue
          600: "#03a9f4", // dark blue
          700: "#0288d1", // very dark blue
          800: "#0277bd", // deep blue
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}

