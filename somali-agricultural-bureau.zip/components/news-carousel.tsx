"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

type NewsItem = {
  id: number
  title: string
  description: string
  date: string
  image: string
}

const newsItems: NewsItem[] = [
  {
    id: 1,
    title: "New Irrigation Project Launched in Gode Zone",
    description:
      "The bureau has launched a new irrigation project that will benefit over 500 farmers in the Gode Zone.",
    date: "March 15, 2025",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 3,
    title: "Agricultural Training Program for Youth Begins Next Month",
    description:
      "A new training program targeting young farmers will begin next month, focusing on sustainable practices.",
    date: "March 5, 2025",
    image: "/placeholder.svg?height=200&width=400",
  },
  {
    id: 4,
    title: "Drought-Resistant Seeds Distribution Completed",
    description: "Over 1,000 farmers received drought-resistant seeds as part of our climate adaptation program.",
    date: "March 1, 2025",
    image: "/placeholder.svg?height=200&width=400",
  },
]

export default function NewsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % newsItems.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + newsItems.length) % newsItems.length)
  }

  // Auto-advance slides every 5 seconds
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative">
      <h2 className="mb-4 text-2xl font-bold">Latest News</h2>
      <div className="relative overflow-hidden rounded-lg">
        <div
          className="flex transition-transform duration-500 ease-in-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {newsItems.map((item) => (
            <div key={item.id} className="w-full flex-shrink-0 px-1">
              <Card className="h-full">
                <div className="relative h-48 w-full overflow-hidden rounded-t-lg">
                  <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                </div>
                <CardHeader className="p-4">
                  <CardTitle className="line-clamp-2 text-lg">{item.title}</CardTitle>
                  <CardDescription>{item.date}</CardDescription>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="line-clamp-2 text-sm text-muted-foreground">{item.description}</p>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Link href="/news">
                    <Button variant="outline" size="sm">
                      Read More
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          ))}
        </div>
      </div>

      <Button
        variant="outline"
        size="icon"
        className="absolute left-0 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur"
        onClick={prevSlide}
      >
        <ChevronLeft className="h-4 w-4" />
        <span className="sr-only">Previous slide</span>
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute right-0 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur"
        onClick={nextSlide}
      >
        <ChevronRight className="h-4 w-4" />
        <span className="sr-only">Next slide</span>
      </Button>

      <div className="mt-4 flex justify-center space-x-2">
        {newsItems.map((_, index) => (
          <button
            key={index}
            className={`h-2 w-2 rounded-full ${index === currentIndex ? "bg-primary" : "bg-muted"}`}
            onClick={() => setCurrentIndex(index)}
          >
            <span className="sr-only">Go to slide {index + 1}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

