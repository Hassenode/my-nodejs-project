import Link from "next/link"
import Image from "next/image"
import { Facebook, Twitter, Mail, Phone, MapPin, Globe } from "lucide-react"
import { useTranslation } from "@/contexts/translation-context"

export default function Footer() {
  const { t } = useTranslation()

  return (
    <footer className="bg-slate-800 text-white">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-3">
              <Image
                src="/placeholder.svg?height=50&width=50"
                alt={`${t("bureau.name")} Logo`}
                width={50}
                height={50}
                className="rounded-full"
              />
              <div className="text-xl font-bold">{t("bureau.name")}</div>
            </div>
            <p className="mt-2 text-sm">{t("bureau.tagline")}</p>
            <p className="mt-4 text-sm text-gray-300">{t("mission.text")}</p>
          </div>
          <div>
            <h3 className="text-base font-medium">{t("footer.quicklinks")}</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white">
                  {t("nav.about")}
                </Link>
              </li>
              <li>
                <Link href="/services" className="text-gray-300 hover:text-white">
                  {t("quicklinks.services")}
                </Link>
              </li>
              <li>
                <Link href="/projects" className="text-gray-300 hover:text-white">
                  {t("nav.programs")}
                </Link>
              </li>
              <li>
                <Link href="/announcements/jobs" className="text-gray-300 hover:text-white">
                  {t("announcements.jobs.title")}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white">
                  {t("nav.contact")}
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-base font-medium">{t("footer.contact")}</h3>
            <address className="mt-4 not-italic text-sm text-gray-300">
              <div className="flex items-start gap-2 mb-2">
                <MapPin className="h-4 w-4 mt-1 text-turquoise" />
                <p>
                  JigJiga, Somali Regional State
                  <br />
                  P.O. Box: 206
                </p>
              </div>
              <div className="flex items-start gap-2 mb-2">
                <Phone className="h-4 w-4 mt-1 text-turquoise" />
                <p>+251-257753584/7418</p>
              </div>
              <div className="flex items-start gap-2 mb-2">
                <Mail className="h-4 w-4 mt-1 text-turquoise" />
                <a href="mailto:srs-banr@gov.et" className="hover:text-white">
                  srs-banr@gov.et
                </a>
              </div>
              <div className="flex items-start gap-2">
                <Globe className="h-4 w-4 mt-1 text-turquoise" />
                <a
                  href="http://srs-banr.gov.et/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white"
                >
                  http://srs-banr.gov.et/
                </a>
              </div>
            </address>
            <div className="mt-4 flex space-x-4">
              <Link href="#" className="text-gray-300 hover:text-white">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-700 pt-8 text-center text-sm text-gray-300">
          <p>{t("footer.copyright")}</p>
        </div>
      </div>
    </footer>
  )
}

