"use client"

import { useState, useEffect } from "react"
import { Cloud, CloudRain, Sun, Thermometer } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

type WeatherData = {
  temperature: number
  condition: "sunny" | "cloudy" | "rainy"
  humidity: number
  rainChance: number
}

export default function WeatherWidget() {
  const { t } = useTranslation()
  const [weather, setWeather] = useState<WeatherData>({
    temperature: 28,
    condition: "sunny",
    humidity: 45,
    rainChance: 10,
  })

  // In a real app, you would fetch actual weather data here
  useEffect(() => {
    // Simulate weather changes for demo purposes
    const interval = setInterval(() => {
      const conditions = ["sunny", "cloudy", "rainy"] as const
      const randomCondition = conditions[Math.floor(Math.random() * conditions.length)]

      setWeather({
        temperature: Math.floor(Math.random() * 10) + 25, // 25-35°C
        condition: randomCondition,
        humidity: Math.floor(Math.random() * 30) + 40, // 40-70%
        rainChance: Math.floor(Math.random() * 30), // 0-30%
      })
    }, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  const getWeatherIcon = () => {
    switch (weather.condition) {
      case "sunny":
        return <Sun className="h-6 w-6 text-amber-500" />
      case "cloudy":
        return <Cloud className="h-6 w-6 text-gray-500" />
      case "rainy":
        return <CloudRain className="h-6 w-6 text-blue-500" />
    }
  }

  const getConditionText = (condition: string) => {
    switch (condition) {
      case "sunny":
        return t("weather.sunny")
      case "cloudy":
        return t("weather.cloudy")
      case "rainy":
        return t("weather.rainy")
      default:
        return condition
    }
  }

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-medium">{t("weather.jijiga")}</h3>
            <div className="mt-1 flex items-center">
              <Thermometer className="mr-1 h-4 w-4 text-red-500" />
              <span className="text-lg font-bold">{weather.temperature}°C</span>
            </div>
          </div>
          <div className="flex flex-col items-center">
            {getWeatherIcon()}
            <span className="mt-1 text-xs capitalize">{getConditionText(weather.condition)}</span>
          </div>
        </div>
        <div className="mt-2 text-xs text-muted-foreground">
          <div>
            {t("weather.humidity")}: {weather.humidity}%
          </div>
          <div>
            {t("weather.rain")}: {weather.rainChance}%
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

