"use client"

import { useState, useEffect, useRef } from "react"
import { Globe } from "lucide-react"

const languages = [
  { name: "English", code: "en", flag: "🇬🇧" },
  { name: "Somali", code: "so", flag: "🇸🇴" },
  { name: "Amharic", code: "am", flag: "🇪🇹" },
]

export default function LanguageSelector() {
  const [currentLanguage, setCurrentLanguage] = useState(languages[0])
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef(null)

  // Load saved language on mount
  useEffect(() => {
    const savedLang = localStorage.getItem("language")
    if (savedLang) {
      const lang = languages.find((l) => l.code === savedLang)
      if (lang) setCurrentLanguage(lang)
    }
  }, [])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const handleLanguageChange = (lang) => {
    console.log("Changing language to:", lang.name)
    setCurrentLanguage(lang)
    localStorage.setItem("language", lang.code)
    setIsOpen(false)
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className="flex items-center gap-1 px-2 py-1 text-white hover:bg-slate-700 rounded text-sm"
        onClick={() => setIsOpen(!isOpen)}
      >
        <Globe className="h-3.5 w-3.5" />
        <span>{currentLanguage.flag}</span>
        <span className="hidden md:inline">{currentLanguage.name}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1 w-40 bg-slate-800 border border-slate-700 rounded shadow-lg z-50">
          {languages.map((lang) => (
            <button
              key={lang.code}
              className={`w-full text-left px-4 py-2 text-sm flex items-center gap-2 hover:bg-slate-700 ${
                currentLanguage.code === lang.code ? "bg-slate-700" : ""
              }`}
              onClick={() => handleLanguageChange(lang)}
            >
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
              {currentLanguage.code === lang.code && <span className="ml-auto">✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

