"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown, Mail, Phone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useTranslation } from "@/contexts/translation-context"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { t } = useTranslation()

  // Define navigation items with translations
  const navItems = [
    { name: t("nav.home"), href: "/" },
    { name: t("nav.about"), href: "/about" },
    {
      name: t("nav.directorates"),
      href: "/directorates",
      hasSubmenu: true,
      submenu: [
        { name: t("nav.directorates.full.crop"), href: "/directorates/crop-production" },
        { name: t("nav.directorates.full.extension"), href: "/directorates/extension" },
        { name: t("nav.directorates.full.natural"), href: "/directorates/natural-resources" },
        { name: t("nav.directorates.full.irrigation"), href: "/directorates/irrigation" },
        { name: t("nav.directorates.full.food"), href: "/directorates/food-security" },
        { name: t("nav.directorates.full.marketing"), href: "/directorates/marketing" },
      ],
    },
    {
      name: t("nav.programs"),
      href: "/projects",
      hasSubmenu: true,
      submenu: [
        { name: t("nav.programs.psnp"), href: "/projects/psnp-5" },
        { name: t("nav.programs.drdip"), href: "/projects/drdip-ii" },
        { name: t("nav.programs.pact"), href: "/projects/pact" },
        { name: t("nav.programs.crew"), href: "/projects/crew" },
      ],
    },
    {
      name: t("nav.resources"),
      href: "/resources",
      hasSubmenu: true,
      submenu: [
        { name: t("nav.resources.policy"), href: "/resources/policy-and-strategy" },
        { name: t("nav.resources.plans"), href: "/resources/plans-and-reports" },
        { name: t("nav.resources.proclamations"), href: "/resources/proclamations" },
        { name: t("nav.resources.directives"), href: "/resources/directives" },
        { name: t("nav.resources.regulations"), href: "/resources/regulations" },
        { name: t("nav.resources.manuals"), href: "/resources/manuals-and-guidelines" },
        { name: t("nav.resources.publications"), href: "/resources/publications" },
      ],
    },
    { name: t("nav.news"), href: "/news" },
    {
      name: t("nav.announcements"),
      href: "/announcements",
      hasSubmenu: true,
      submenu: [
        { name: t("nav.announcements.jobs"), href: "/announcements/jobs" },
        { name: t("nav.announcements.tenders"), href: "/announcements/tenders" },
      ],
    },
    { name: t("nav.contact"), href: "/contact" },
  ]

  return (
    <header className="w-full">
      {/* Top contact bar */}
      <div className="bg-green-700 py-1 text-white">
        <div className="container flex justify-between items-center">
          <div className="flex items-center gap-4 text-xs">
            <a href="mailto:srs-banr@gov.et" className="flex items-center gap-1 hover:underline">
              <Mail className="h-3.5 w-3.5" />
              <span>srs-banr@gov.et</span>
            </a>
            <a href="tel:+251257753584" className="flex items-center gap-1 hover:underline">
              <Phone className="h-3.5 w-3.5" />
              <span>+251-257753584</span>
            </a>
          </div>
        </div>
      </div>

      <div className="bg-turquoise py-3">
        <div className="container">
          <div className="flex justify-center items-center">
            <Link href="/" className="flex flex-col items-center">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Agri.jpg-ZILdoAWMAR2wYpShQDx12NjU5UTvhR.jpeg"
                alt={t("bureau.name")}
                width={70}
                height={70}
                className="rounded-full"
              />
              <div className="text-center">
                <h1 className="text-xl font-bold text-white md:text-2xl">{t("bureau.name")}</h1>
                <p className="text-sm text-white">{t("bureau.tagline")}</p>
              </div>
            </Link>
          </div>
        </div>
      </div>

      <div className="bg-slate-800 text-white">
        <div className="container">
          <div className="flex h-12 items-center justify-between">
            {/* Desktop Navigation */}
            <nav className="hidden md:flex md:items-center md:justify-center md:flex-1">
              <div className="flex flex-wrap justify-center">
                {navItems.map((item) => {
                  if (item.hasSubmenu) {
                    return (
                      <DropdownMenu key={item.name}>
                        <DropdownMenuTrigger asChild>
                          <button className="flex items-center gap-1 px-1.5 py-1 text-xs font-medium text-white transition-colors hover:bg-slate-700 hover:text-white lg:text-sm lg:px-2">
                            {item.name}
                            <ChevronDown className="h-3 w-3 lg:h-4 lg:w-4" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start" className="w-56 bg-slate-800 text-white border-slate-700">
                          {item.submenu?.map((subItem) => (
                            <DropdownMenuItem
                              key={subItem.name}
                              asChild
                              className="hover:bg-slate-700 focus:bg-slate-700"
                            >
                              <Link href={subItem.href} className="w-full">
                                {subItem.name}
                              </Link>
                            </DropdownMenuItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )
                  }
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="px-1.5 py-1 text-xs font-medium text-white transition-colors hover:bg-slate-700 hover:text-white lg:text-sm lg:px-2"
                    >
                      {item.name}
                    </Link>
                  )
                })}
              </div>
            </nav>

            <div className="flex items-center gap-4 md:hidden">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-slate-700"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <span className="sr-only">Toggle menu</span>
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>

            <div className="hidden md:flex md:items-center md:gap-2">
              <Button variant="outline" size="sm" className="h-8 bg-red-600 text-white hover:bg-red-700 px-2 text-xs">
                LIVE
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="bg-slate-800 py-4">
            <nav className="container flex flex-col space-y-2">
              {navItems.map((item) => {
                if (item.hasSubmenu) {
                  return (
                    <div key={item.name} className="space-y-2">
                      <Link
                        href={item.href}
                        className="px-4 py-2 text-base font-medium text-white hover:bg-slate-700 flex items-center justify-between"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {item.name}
                      </Link>
                      <div className="pl-6 space-y-2 border-l border-slate-700 ml-4">
                        {item.submenu?.map((subItem) => (
                          <Link
                            key={subItem.name}
                            href={subItem.href}
                            className="px-4 py-1 text-sm font-medium text-gray-300 hover:bg-slate-700 hover:text-white block"
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    </div>
                  )
                }
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="px-4 py-2 text-base font-medium text-white hover:bg-slate-700"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                )
              })}
              <div className="mt-4 px-4 flex items-center justify-between">
                <Button variant="outline" size="sm" className="bg-red-600 text-white hover:bg-red-700">
                  LIVE
                </Button>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}

