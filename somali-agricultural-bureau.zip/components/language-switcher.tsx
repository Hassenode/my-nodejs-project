"use client"

import { useState, useEffect, useRef } from "react"
import { Globe } from "lucide-react"
import { useTranslation, type Language } from "@/contexts/translation-context"

const languages = [
  { name: "English", code: "en", flag: "🇬🇧" },
  { name: "Somali", code: "so", flag: "🇸🇴" },
  { name: "Amharic", code: "am", flag: "🇪🇹" },
]

export default function LanguageSwitcher() {
  const { language, setLanguage } = useTranslation()
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  // Make sure the page reload happens when language changes
  const handleLanguageChange = (lang: Language) => {
    if (lang === language) return

    setLanguage(lang)
    setIsOpen(false)

    // Force a page reload to ensure all components update with the new language
    // This is a more reliable approach for ensuring all components get the new language
    window.location.reload()
  }

  // Get current language object
  const currentLanguage = languages.find((lang) => lang.code === language) || languages[0]

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className="flex items-center gap-1 px-3 py-2 text-white hover:bg-slate-700 rounded text-sm font-medium transition-colors"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <Globe className="h-4 w-4 mr-1" />
        <span className="text-lg">{currentLanguage.flag}</span>
        <span className="hidden md:inline">{currentLanguage.name}</span>
      </button>

      {isOpen && (
        <div
          className="absolute right-0 mt-1 w-48 bg-slate-800 border border-slate-700 rounded shadow-lg z-50 overflow-hidden"
          role="menu"
          aria-orientation="vertical"
        >
          {languages.map((lang) => (
            <button
              key={lang.code}
              className={`w-full text-left px-4 py-3 text-sm flex items-center gap-3 hover:bg-slate-700 transition-colors ${
                language === lang.code ? "bg-slate-700" : ""
              }`}
              onClick={() => handleLanguageChange(lang.code as Language)}
              role="menuitem"
            >
              <span className="text-lg">{lang.flag}</span>
              <span className="text-white">{lang.name}</span>
              {language === lang.code && <span className="ml-auto text-green-400">✓</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

