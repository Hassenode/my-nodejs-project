"use client"

import { useState, useEffect } from "react"
import { Globe } from "lucide-react"

const languages = [
  { name: "English", code: "en", flag: "🇬🇧" },
  { name: "Somali", code: "so", flag: "🇸🇴" },
  { name: "Amharic", code: "am", flag: "🇪🇹" },
]

export default function SimpleLanguageSelector() {
  const [selectedLanguage, setSelectedLanguage] = useState("en")
  const [showDropdown, setShowDropdown] = useState(false)

  // Get the current language object
  const currentLanguage = languages.find((lang) => lang.code === selectedLanguage) || languages[0]

  // Function to change language
  const changeLanguage = (code) => {
    console.log("Language changed to:", code)
    setSelectedLanguage(code)
    setShowDropdown(false)

    // In a real app, you would do more here to change the actual language
    // This is just for demonstration
    try {
      localStorage.setItem("selectedLanguage", code)
    } catch (error) {
      console.error("Error saving language to localStorage:", error)
    }
  }

  // Load saved language on component mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("selectedLanguage")
      if (saved) {
        setSelectedLanguage(saved)
      }
    } catch (error) {
      console.error("Error loading language from localStorage:", error)
    }
  }, [])

  return (
    <div className="relative inline-block text-left">
      <div>
        <button
          type="button"
          className="inline-flex items-center justify-center gap-x-1.5 rounded-md bg-slate-700 px-3 py-1.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-600"
          onClick={() => setShowDropdown(!showDropdown)}
        >
          <Globe className="h-4 w-4" aria-hidden="true" />
          <span>{currentLanguage.flag}</span>
          <span className="hidden md:inline">{currentLanguage.name}</span>
        </button>
      </div>

      {showDropdown && (
        <div className="absolute right-0 z-10 mt-2 w-40 origin-top-right rounded-md bg-slate-700 shadow-lg ring-1 ring-black ring-opacity-5">
          <div className="py-1">
            {languages.map((language) => (
              <button
                key={language.code}
                onClick={() => changeLanguage(language.code)}
                className={`block w-full px-4 py-2 text-left text-sm ${
                  selectedLanguage === language.code ? "bg-slate-600 text-white" : "text-white hover:bg-slate-600"
                }`}
              >
                <span className="inline-flex items-center">
                  <span className="mr-2">{language.flag}</span>
                  <span>{language.name}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

