import Image from "next/image"
import Link from "next/link"
import { Calendar, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const newsItems = [
  {
    id: 1,
    title: "New Irrigation Project Launched in Gode Zone",
    excerpt:
      "The bureau has launched a new irrigation project that will benefit over 500 farmers in the Gode Zone, providing sustainable water access for crop production.",
    date: "March 15, 2025",
    readTime: "5 min read",
    image: "/placeholder.svg?height=300&width=600",
  },
  {
    id: 3,
    title: "Agricultural Training Program for Youth Begins Next Month",
    excerpt:
      "A new training program targeting young farmers will begin next month, focusing on sustainable practices and modern farming techniques to attract youth to agriculture.",
    date: "March 5, 2025",
    readTime: "3 min read",
    image: "/placeholder.svg?height=300&width=600",
  },
  {
    id: 4,
    title: "Drought-Resistant Seeds Distribution Completed",
    excerpt:
      "Over 1,000 farmers received drought-resistant seeds as part of our climate adaptation program to improve resilience against changing weather patterns.",
    date: "March 1, 2025",
    readTime: "4 min read",
    image: "/placeholder.svg?height=300&width=600",
  },
]

const upcomingEvents = [
  {
    id: 1,
    title: "Farmer Workshop",
    date: "March 20, 2025",
    location: "Jijiga Training Center",
  },
  {
    id: 3,
    title: "Agricultural Exhibition",
    date: "April 5-7, 2025",
    location: "Jijiga Exhibition Grounds",
  },
  {
    id: 4,
    title: "Water Management Seminar",
    date: "April 15, 2025",
    location: "Kebri Dehar",
  },
  {
    id: 5,
    title: "Crop Disease Prevention Workshop",
    date: "April 22, 2025",
    location: "Gode Training Center",
  },
]

export default function NewsPage() {
  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">News & Events</h1>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <h2 className="mb-6 text-2xl font-bold">Latest News</h2>

          <div className="space-y-8">
            {newsItems.map((item) => (
              <Card key={item.id} className="overflow-hidden">
                <div className="relative h-48 w-full sm:h-64">
                  <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{item.title}</CardTitle>
                  <CardDescription className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {item.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {item.readTime}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href={`/news/${item.id}`}>Read More</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-8 flex justify-center">
            <Button variant="outline">Load More News</Button>
          </div>
        </div>

        <div>
          <h2 className="mb-6 text-2xl font-bold">Upcoming Events</h2>

          <Card>
            <CardHeader>
              <CardTitle>Event Calendar</CardTitle>
              <CardDescription>Upcoming agricultural events in the Somali Region</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="border-b pb-4 last:border-0">
                    <h3 className="font-medium">{event.title}</h3>
                    <p className="text-sm text-muted-foreground">{event.date}</p>
                    <p className="text-sm text-muted-foreground">{event.location}</p>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View All Events
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

