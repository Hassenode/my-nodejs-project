"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Leaf } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function CropProductionPage() {
  const { t, language } = useTranslation()

  // Translation keys for Crop Production page
  const translations = {
    en: {
      title: "Agricultural Production and Crop Protection Directorate",
      backToDirectorates: "Back to Directorates",
      description:
        "This directorate focuses on increasing agricultural productivity and protecting crops from pests and diseases.",
      overview: "Overview",
      overviewText1:
        "The Agricultural Production and Crop Protection Directorate is responsible for enhancing crop productivity and ensuring crop health throughout the Somali Region. We work closely with farmers to introduce improved farming practices, provide quality inputs, and implement effective pest and disease management strategies.",
      overviewText2:
        "Our team of agricultural experts provides technical guidance to farmers on crop selection, land preparation, planting techniques, and post-harvest handling to maximize yields and reduce losses.",
      keyServices: "Key Services",
      service1Title: "Expansion of Cultivated Land",
      service1Text:
        "We support farmers in expanding their cultivated land through land clearing, soil preparation, and providing guidance on sustainable land use practices. Our goal is to increase the area under cultivation while ensuring environmental sustainability.",
      service2Title: "Distribution of Quality Inputs",
      service2Text:
        "We ensure farmers have access to high-quality seeds, fertilizers, and other agricultural inputs. We work with suppliers and research institutions to identify and distribute inputs that are suitable for the local conditions and can improve crop yields.",
      service3Title: "Pest and Disease Control",
      service3Text:
        "We implement integrated pest and disease management strategies to protect crops from damage. This includes early detection systems, biological control methods, and judicious use of pesticides when necessary. We also train farmers on safe handling of agricultural chemicals.",
      service4Title: "Research and Development",
      service4Text:
        "We collaborate with research institutions to develop and test improved farming techniques that are suitable for the Somali Region's climate and soil conditions. This includes drought-resistant crop varieties, conservation agriculture, and climate-smart farming practices.",
      service5Title: "Technical Assistance",
      service5Text:
        "Our team provides hands-on technical assistance to farmers through field visits, demonstrations, and training sessions. We help farmers implement best practices in crop production and address challenges they face in their farming operations.",
      director: "Director",
      directorName: "Ahmed Hassan",
      email: "Email",
      phone: "Phone",
      office: "Office",
      programs: "Programs",
      program1: "Drought-Resistant Crop Introduction",
      program2: "Integrated Pest Management",
      program3: "Soil Fertility Enhancement",
      program4: "Post-Harvest Loss Reduction",
      program5: "Farmer Field Schools",
      relatedResources: "Related Resources",
      resource1: "Crop Production Guide for Somali Region",
      resource2: "Pest and Disease Identification Manual",
      resource3: "Seasonal Planting Calendar",
      resource4: "Fertilizer Application Guidelines",
      contactDirectorate: "Contact This Directorate",
    },
    so: {
      title: "Agaasinka Wax Soo Saarka Beeraha iyo Ilaalinta Dalagga",
      backToDirectorates: "Ku Noqo Agaasimayaasha",
      description:
        "Agaasinkani wuxuu diiradda saaraa kordhinta wax soo saarka beeraha iyo ilaalinta dalagga cayayaanka iyo cudurrada.",
      overview: "Guudmar",
      overviewText1:
        "Agaasinka Wax Soo Saarka Beeraha iyo Ilaalinta Dalagga waxaa mas'uul ka ah xoojinta wax soo saarka dalagga iyo hubinta caafimaadka dalagga ee Gobolka Soomaalida oo dhan. Waxaan si dhow ula shaqeynaa beeralayda si aan u soo bandhigno hab-dhaqannada beerashada ee la hagaajiyay, bixino soo-gelinta tayada leh, oo aan u fulino xeeladaha wax ku ool ah ee maaraynta cayayaanka iyo cudurrada.",
      overviewText2:
        "Kooxdayada khubarada beeraha waxay siisaa hagitaan farsamo beeralayda ku saabsan doorashada dalagga, diyaarinta dhulka, farsamooyinka beerista, iyo maaraynta ka-dib goosashada si loo gaaro wax soo saar ugu badan oo loo yareeyo khasaaraha.",
      keyServices: "Adeegyada Muhiimka ah",
      service1Title: "Ballaarinta Dhulka La Beeray",
      service1Text:
        "Waxaan taageernaa beeralayda si ay u ballaariyaan dhulkooda la beeray iyada oo loo marayo nadiifinta dhulka, diyaarinta ciidda, iyo bixinta hagitaan ku saabsan hab-dhaqannada isticmaalka dhulka ee waara. Hadafkayagu waa in aan kordhino aagga beerashada iyada oo la hubinayo waara deegaanka.",
      service2Title: "Qaybinta Soo-gelinta Tayada leh",
      service2Text:
        "Waxaan hubinaa in beeralaydu ay helaan abuur tayo sare leh, bacrimiyeyaal, iyo soo-gelinta kale ee beeraha. Waxaan la shaqeynaa sahayda iyo hay'adaha cilmi-baarista si loo aqoonsado oo loo qaybiyo soo-gelinta ku habboon xaaladaha deegaanka oo hagaajin kara wax soo saarka dalagga.",
      service3Title: "Xakamaynta Cayayaanka iyo Cudurrada",
      service3Text:
        "Waxaan fulinnaa xeeladaha isku dhafan ee maaraynta cayayaanka iyo cudurrada si looga ilaaliyo dalagga waxyeelada. Tan waxaa ka mid ah nidaamyada ogaanshaha hore, hab-dhaqannada xakamaynta bayolojiga, iyo isticmaalka caqliga leh ee sunta cayayaanka marka loo baahdo. Waxaan sidoo kale tababarnaa beeralayda ku saabsan maaraynta badbaadada leh ee kiimikada beeraha.",
      service4Title: "Cilmi-baarista iyo Horumarinta",
      service4Text:
        "Waxaan la shaqeynaa hay'adaha cilmi-baarista si aan u horumarino oo aan u tijaabiyo farsamooyinka beerashada ee la hagaajiyay ee ku habboon cimilada iyo xaaladaha ciidda ee Gobolka Soomaalida. Tan waxaa ka mid ah noocyada dalagga ee adkeysi u leh abaaraha, beerashada ilaalinta, iyo hab-dhaqannada beerashada cimilada-caqliga leh.",
      service5Title: "Gargaarka Farsamo",
      service5Text:
        "Kooxdayadu waxay siisaa gargaar farsamo oo toos ah beeralayda iyada oo loo marayo booqashooyinka beerta, bandhigyada, iyo kalfadhiyada tababarka. Waxaan ka caawinnaa beeralayda inay fuliyaan hab-dhaqannada ugu wanaagsan ee wax soo saarka dalagga oo ay wax ka qabtaan caqabadaha ay kala kulmaan hawlahooda beerashada.",
      director: "Agaasime",
      directorName: "Axmed Xasan",
      email: "Iimaylka",
      phone: "Telefoonka",
      office: "Xafiiska",
      programs: "Barnaamijyada",
      program1: "Soo-bandhigidda Dalagga Adkeysi u leh Abaaraha",
      program2: "Maaraynta Isku dhafan ee Cayayaanka",
      program3: "Xoojinta Bacriminta Ciidda",
      program4: "Yareynta Khasaaraha Ka-dib Goosashada",
      program5: "Dugsiyada Beerta ee Beeralayda",
      relatedResources: "Ilaha La Xiriira",
      resource1: "Hagaha Wax Soo Saarka Dalagga ee Gobolka Soomaalida",
      resource2: "Buugga Aqoonsiga Cayayaanka iyo Cudurrada",
      resource3: "Jadwalka Beerista Xilliga",
      resource4: "Tilmaamaha Isticmaalka Bacrimiyaha",
      contactDirectorate: "La Xiriir Agaasimkan",
    },
    am: {
      title: "የግብርና ምርት እና የሰብል ጥበቃ ዳይሬክቶሬት",
      backToDirectorates: "ወደ ዳይሬክቶሬቶች ተመለስ",
      description: "ይህ ዳይሬክቶሬት የግብርና ምርታማነትን በማሻሻል እና ሰብሎችን ከተባዮች እና ከበሽታዎች በመጠበቅ ላይ ያተኩራል።",
      overview: "አጠቃላይ እይታ",
      overviewText1:
        "የግብርና ምርት እና የሰብል ጥበቃ ዳይሬክቶሬት በሶማሌ ክልል ሁሉም አካባቢ የሰብል ምርታማነትን ለማሻሻል እና የሰብል ጤንነትን ለማረጋገጥ ኃላፊነት አለው። የተሻሻሉ የግብርና ልምዶችን ለማስተዋወቅ፣ ጥራት ያላቸውን ግብዓቶችን ለመስጠት እና ውጤታማ የተባይ እና የበሽታ አስተዳደር ስልቶችን ለመተግበር ከአርሶ አደሮች ጋር በቅርበት እንሰራለን።",
      overviewText2:
        "የግብርና ባለሙያዎች ቡድናችን ምርቶችን ለማሳደግ እና ኪሳራዎችን ለመቀነስ የሰብል ምርጫ፣ የመሬት ዝግጅት፣ የመትከል ቴክኒኮች እና ከምርት በኋላ አያያዝ ላይ ለአርሶ አደሮች ቴክኒካዊ መመሪያ ይሰጣል።",
      keyServices: "ዋና አገልግሎቶች",
      service1Title: "የተመረተ መሬት ማስፋፋት",
      service1Text:
        "አርሶ አደሮች የተመረተ መሬታቸውን በመሬት ማጽዳት፣ በአፈር ዝግጅት እና ዘላቂ የመሬት አጠቃቀም ልምዶች ላይ መመሪያ በመስጠት እንዲያስፋፉ እንደግፋለን። ዓላማችን የአካባቢ ዘላቂነትን በማረጋገጥ የመሬት ልማት ስፋትን ማሳደግ ነው።",
      service2Title: "ጥራት ያላቸው ግብዓቶች ስርጭት",
      service2Text:
        "አርሶ አደሮች ጥራት ያላቸው ዘሮችን፣ ማዳበሪያዎችን እና ሌሎች የግብርና ግብዓቶችን እንዲያገኙ እናረጋግጣለን። ለአካባቢው ሁኔታዎች ተስማሚ የሆኑ እና የሰብል ምርትን ማሻሻል የሚችሉ ግብዓቶችን ለመለየት እና ለማሰራጨት ከአቅራቢዎች እና ከምርምር ተቋማት ጋር እንሰራለን።",
      service3Title: "የተባይ እና የበሽታ ቁጥጥር",
      service3Text:
        "ሰብሎችን ከጉዳት ለመጠበቅ የተቀናጀ የተባይ እና የበሽታ አስተዳደር ስልቶችን እንተገብራለን። ይህ ቀደም ሲል የማግኘት ስርዓቶችን፣ የባዮሎጂካል ቁጥጥር ዘዴዎችን እና አስፈላጊ ሲሆን የተባይ መድሃኒቶችን በጥንቃቄ መጠቀምን ያካትታል። እንዲሁም አርሶ አደሮችን የግብርና ኬሚካሎችን በደህንነት መያዝ ላይ እናሰለጥናለን።",
      service4Title: "ምርምር እና ልማት",
      service4Text:
        "ለሶማሌ ክልል የአየር ንብረት እና የአፈር ሁኔታዎች ተስማሚ የሆኑ የተሻሻሉ የግብርና ቴክኒኮችን ለማዳበር እና ለመሞከር ከምርምር ተቋማት ጋር እንተባበራለን። ይህ ድርቅን የሚቋቋሙ የሰብል ዝርያዎችን፣ የአፈር ጥበቃ ግብርናን እና የአየር ንብረት-ብልህ የግብርና ልምዶችን ያካትታል።",
      service5Title: "ቴክኒካዊ ድጋፍ",
      service5Text:
        "ቡድናችን በመስክ ጉብኝቶች፣ በማሳያዎች እና በስልጠና ክፍለ ጊዜዎች አማካኝነት ለአርሶ አደሮች ተግባራዊ ቴክኒካዊ ድጋፍ ይሰጣል። አርሶ አደሮች በሰብል ምርት ውስጥ ምርጥ ልምዶችን እንዲተገብሩ እና በእርሻ ሥራቸው ውስጥ የሚያጋጥሟቸውን ተግዳሮቶች እንዲቋቋሙ እንረዳለን።",
      director: "ዳይሬክተር",
      directorName: "አህመድ ሃሰን",
      email: "ኢሜይል",
      phone: "ስልክ",
      office: "ቢሮ",
      programs: "ፕሮግራሞች",
      program1: "ድርቅን የሚቋቋሙ ሰብሎችን ማስተዋወቅ",
      program2: "የተቀናጀ የተባይ አስተዳደር",
      program3: "የአፈር ለምነት ማሻሻል",
      program4: "ከምርት በኋላ የሚደርሰውን ኪሳራ መቀነስ",
      program5: "የአርሶ አደር የመስክ ትምህርት ቤቶች",
      relatedResources: "ተዛማጅ ሀብቶች",
      resource1: "ለሶማሌ ክልል የሰብል ምርት መመሪያ",
      resource2: "የተባይ እና የበሽታ መለያ መመሪያ",
      resource3: "የወቅታዊ ምርት መርሃ ግብር",
      resource4: "የማዳበሪያ አጠቃቀም መመሪያዎች",
      contactDirectorate: "ይህን ዳይሬክቶሬት ያግኙ",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {currentTranslations.backToDirectorates}
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="mt-4 text-muted-foreground">{currentTranslations.description}</p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Agricultural+Production"
              alt="Agricultural Production"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">{currentTranslations.overview}</h2>
              <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText1}</p>
              <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText2}</p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">{currentTranslations.keyServices}</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{currentTranslations.service1Title}</h3>
                    <p className="mt-2 text-muted-foreground">{currentTranslations.service1Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{currentTranslations.service2Title}</h3>
                    <p className="mt-2 text-muted-foreground">{currentTranslations.service2Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{currentTranslations.service3Title}</h3>
                    <p className="mt-2 text-muted-foreground">{currentTranslations.service3Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{currentTranslations.service4Title}</h3>
                    <p className="mt-2 text-muted-foreground">{currentTranslations.service4Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">{currentTranslations.service5Title}</h3>
                    <p className="mt-2 text-muted-foreground">{currentTranslations.service5Text}</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <Leaf className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">{currentTranslations.director}</h3>
                  <p className="text-muted-foreground">{currentTranslations.directorName}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">{currentTranslations.email}:</span> ahmed.hassan@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">{currentTranslations.phone}:</span> +251-257753584 Ext. 101
                </p>
                <p className="text-sm">
                  <span className="font-medium">{currentTranslations.office}:</span> JigJiga, Main Bureau Building, 2nd
                  Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{currentTranslations.programs}</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>{currentTranslations.program1}</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>{currentTranslations.program2}</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>{currentTranslations.program3}</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>{currentTranslations.program4}</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>{currentTranslations.program5}</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{currentTranslations.relatedResources}</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    {currentTranslations.resource1}
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    {currentTranslations.resource2}
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    {currentTranslations.resource3}
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    {currentTranslations.resource4}
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">{currentTranslations.contactDirectorate}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

