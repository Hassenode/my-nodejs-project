"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, BarChart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

export default function MarketingPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t("back.to.directorates")}
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">Marketing and Cooperative Development Directorate</h1>
        <p className="mt-4 text-muted-foreground">
          This directorate strengthens agricultural markets and farmer cooperatives for better economic opportunities.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Marketing+and+Cooperatives"
              alt="Marketing and Cooperatives"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">{t("overview")}</h2>
              <p className="mt-4 text-muted-foreground">
                The Marketing and Cooperative Development Directorate works to improve market access and strengthen
                farmer organizations in the Somali Region. We focus on developing efficient agricultural marketing
                systems and building the capacity of cooperatives to enhance farmers' bargaining power and income.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our team supports the entire agricultural value chain, from production to consumption, with emphasis on
                market linkages, value addition, and cooperative development. We work to create an enabling environment
                for agricultural marketing and cooperative growth.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">{t("keyServices")}</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Market Access Facilitation</h3>
                    <p className="mt-2 text-muted-foreground">
                      We facilitate access to agricultural markets through market information systems, market linkages,
                      and development of market infrastructure. This includes establishing market centers, storage
                      facilities, and transportation networks to connect farmers with buyers.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Cooperative Formation and Strengthening</h3>
                    <p className="mt-2 text-muted-foreground">
                      We support the formation and strengthening of agricultural cooperatives, including producer
                      groups, marketing cooperatives, and multipurpose cooperatives. This involves training on
                      cooperative principles, governance, financial management, and business planning.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Agricultural Input Supply</h3>
                    <p className="mt-2 text-muted-foreground">
                      We regulate the supply and distribution of agricultural inputs such as seeds, fertilizers, and
                      pesticides. This includes quality control, price monitoring, and ensuring timely availability of
                      inputs to farmers through cooperatives and other channels.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Market Information and Analysis</h3>
                    <p className="mt-2 text-muted-foreground">
                      We collect, analyze, and disseminate market information on prices, demand, supply, and trends for
                      agricultural products. This information helps farmers make informed decisions about what to
                      produce, when to sell, and where to market their products.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Value Addition and Agribusiness</h3>
                    <p className="mt-2 text-muted-foreground">
                      We promote value addition and agribusiness development to increase the value of agricultural
                      products and create employment opportunities. This includes support for processing, packaging,
                      branding, and marketing of value-added products.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <BarChart className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">{t("director")}</h3>
                  <p className="text-muted-foreground">Zahra Ahmed</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">{t("email")}:</span> zahra.ahmed@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("phone")}:</span> +251-257753584 Ext. 106
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("office")}:</span> JigJiga, Main Bureau Building, 3rd Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("programs")}</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Cooperative Development Program</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Market Information System</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Value Chain Development</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Agricultural Input Supply Chain</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Market Infrastructure Development</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("relatedResources")}</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Cooperative Formation Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Agricultural Marketing Manual
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Market Price Bulletin
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Value Addition Techniques
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">{t("contactDirectorate")}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

