"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

export default function FoodSecurityPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t("back.to.directorates")}
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">Food Security and Nutrition Directorate</h1>
        <p className="mt-4 text-muted-foreground">
          This directorate is responsible for ensuring food security and promoting better nutrition within communities.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Food+Security"
              alt="Food Security"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">{t("overview")}</h2>
              <p className="mt-4 text-muted-foreground">
                The Food Security and Nutrition Directorate works to ensure that all residents of the Somali Region have
                access to sufficient, safe, and nutritious food that meets their dietary needs and food preferences for
                an active and healthy life. We focus on both immediate food security needs and long-term strategies to
                build resilience against food insecurity.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our team implements programs that address the four dimensions of food security: availability, access,
                utilization, and stability. We work closely with other directorates, government agencies, and
                development partners to coordinate food security interventions and promote nutrition-sensitive
                agriculture.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">{t("keyServices")}</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Food Security Programs</h3>
                    <p className="mt-2 text-muted-foreground">
                      We implement food security programs to support vulnerable households, including the Productive
                      Safety Net Program (PSNP), emergency food assistance, and food-for-work initiatives. These
                      programs provide immediate food support while also building community assets that enhance
                      long-term food security.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Community Resilience Building</h3>
                    <p className="mt-2 text-muted-foreground">
                      We work to enhance community resilience against food crises through diversification of
                      livelihoods, establishment of community grain banks, early warning systems, and contingency
                      planning. These measures help communities better prepare for and respond to food security
                      challenges.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Nutrition Education and Awareness</h3>
                    <p className="mt-2 text-muted-foreground">
                      We conduct nutrition education and awareness programs to improve dietary practices and nutritional
                      outcomes. This includes cooking demonstrations, nutrition counseling, and promotion of dietary
                      diversity to address malnutrition, particularly among women and children.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Food Security Monitoring</h3>
                    <p className="mt-2 text-muted-foreground">
                      We monitor food security conditions throughout the region, collecting and analyzing data on food
                      availability, access, prices, and nutritional status. This information helps in early
                      identification of food security challenges and informs appropriate responses.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Nutrition-Sensitive Agriculture</h3>
                    <p className="mt-2 text-muted-foreground">
                      We promote agricultural projects that enhance food availability and diversity, including home
                      gardens, poultry production, and cultivation of nutrient-rich crops. These initiatives aim to
                      improve both food security and nutritional outcomes for households.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">{t("director")}</h3>
                  <p className="text-muted-foreground">Hassan Ibrahim</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">{t("email")}:</span> hassan.ibrahim@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("phone")}:</span> +251-257753584 Ext. 105
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("office")}:</span> JigJiga, Main Bureau Building, 3rd Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("programs")}</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Productive Safety Net Program (PSNP)</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Emergency Food Assistance</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Nutrition Education Campaign</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Home Garden Initiative</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Food Security Early Warning System</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("relatedResources")}</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Food Security Assessment Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Nutrition Education Materials
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    PSNP Implementation Manual
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Home Garden Technical Guide
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">{t("contactDirectorate")}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

