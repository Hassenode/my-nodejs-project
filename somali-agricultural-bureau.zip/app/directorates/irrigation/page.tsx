"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Droplets } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

export default function IrrigationPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t("back.to.directorates")}
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">Small-Scale Irrigation Development Directorate</h1>
        <p className="mt-4 text-muted-foreground">
          This directorate works to improve irrigation infrastructure and ensure efficient water use for agriculture.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Irrigation+Development"
              alt="Irrigation Development"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">{t("overview")}</h2>
              <p className="mt-4 text-muted-foreground">
                The Small-Scale Irrigation Development Directorate is responsible for expanding and improving irrigation
                infrastructure to enhance agricultural productivity and water use efficiency in the Somali Region. We
                focus on developing sustainable irrigation systems that can withstand climate variability and support
                year-round agricultural production.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our team works with farmers and communities to design, implement, and manage irrigation schemes that are
                appropriate for local conditions and can be maintained by local institutions. We emphasize participatory
                approaches and capacity building to ensure the sustainability of irrigation investments.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">{t("keyServices")}</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Irrigation Infrastructure Development</h3>
                    <p className="mt-2 text-muted-foreground">
                      We design and construct small-scale irrigation schemes, including diversion structures, canals,
                      and water distribution systems. Our focus is on developing infrastructure that is appropriate for
                      local conditions, cost-effective, and can be maintained by local communities.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Water Harvesting and Storage</h3>
                    <p className="mt-2 text-muted-foreground">
                      We implement water harvesting and storage structures to capture and store rainwater for
                      agricultural use. This includes the construction of small dams, ponds, and underground cisterns
                      that can provide water during dry periods and extend the growing season.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Efficient Irrigation Technologies</h3>
                    <p className="mt-2 text-muted-foreground">
                      We promote the adoption of water-efficient irrigation technologies such as drip irrigation,
                      sprinkler systems, and improved surface irrigation methods. These technologies help farmers
                      maximize crop production while minimizing water use.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Irrigation Management Training</h3>
                    <p className="mt-2 text-muted-foreground">
                      We provide training to farmers and water user associations on irrigation system operation,
                      maintenance, and management. This includes water scheduling, system maintenance, conflict
                      resolution, and financial management to ensure the sustainability of irrigation schemes.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Groundwater Development</h3>
                    <p className="mt-2 text-muted-foreground">
                      We assess groundwater potential and develop groundwater resources for irrigation through the
                      construction of shallow wells, boreholes, and pumping systems. We emphasize sustainable
                      groundwater management to prevent overexploitation and ensure long-term availability.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <Droplets className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">{t("director")}</h3>
                  <p className="text-muted-foreground">Amina Omar</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">{t("email")}:</span> amina.omar@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("phone")}:</span> +251-257753584 Ext. 104
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("office")}:</span> JigJiga, Main Bureau Building, 2nd Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("programs")}</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Small-Scale Irrigation Development Program</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Water Harvesting Initiative</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Drip Irrigation Promotion</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Groundwater Development Project</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Water User Association Support</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("relatedResources")}</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Small-Scale Irrigation Design Manual
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Water Harvesting Techniques Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Irrigation Water Management Handbook
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Water User Association Formation Guide
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">{t("contactDirectorate")}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

