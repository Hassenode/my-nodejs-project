"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

export default function ExtensionPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Directorates
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">Agricultural Extension and Technology Transfer Directorate</h1>
        <p className="mt-4 text-muted-foreground">
          This directorate is responsible for promoting modern farming techniques and technology adoption among farmers.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Agricultural+Extension"
              alt="Agricultural Extension"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Overview</h2>
              <p className="mt-4 text-muted-foreground">
                The Agricultural Extension and Technology Transfer Directorate serves as the bridge between agricultural
                research and farmers in the Somali Region. We work to ensure that new agricultural technologies,
                practices, and knowledge reach farmers and are adopted to improve productivity and livelihoods.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our extension agents work directly with farming communities to provide training, demonstrations, and
                ongoing support to help farmers implement improved agricultural practices and technologies.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">Key Services</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Farmer Training</h3>
                    <p className="mt-2 text-muted-foreground">
                      We conduct regular training sessions for farmers on advanced agricultural methods, including crop
                      management, soil fertility, water conservation, and post-harvest handling. These trainings are
                      designed to be practical and relevant to the local farming context.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Technology Adoption</h3>
                    <p className="mt-2 text-muted-foreground">
                      We facilitate the adoption of modern farming equipment and technologies by providing
                      demonstrations, technical guidance, and sometimes support in accessing these technologies. This
                      includes improved plows, irrigation equipment, and post-harvest processing tools.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Cooperative Support</h3>
                    <p className="mt-2 text-muted-foreground">
                      We provide technical and organizational support to agricultural cooperatives and farmer
                      organizations to enhance their effectiveness in serving their members. This includes training on
                      cooperative management, record keeping, and collective marketing.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Knowledge Networks</h3>
                    <p className="mt-2 text-muted-foreground">
                      We establish and strengthen farmer networks for knowledge sharing and peer learning. This includes
                      farmer field schools, demonstration plots, and farmer-to-farmer extension approaches that enable
                      farmers to learn from each other's experiences.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Climate-Smart Agriculture</h3>
                    <p className="mt-2 text-muted-foreground">
                      We promote climate-smart agricultural practices that help farmers adapt to changing climate
                      conditions while also reducing greenhouse gas emissions where possible. This includes conservation
                      agriculture, agroforestry, and efficient water use techniques.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <FileText className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">Director</h3>
                  <p className="text-muted-foreground">Mohamed Ali</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">Email:</span> mohamed.ali@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">Phone:</span> +251-XXX-XXX
                </p>
                <p className="text-sm">
                  <span className="font-medium">Office:</span> Jijiga, Main Bureau Building, 2nd Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">Programs</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Farmer Field Schools</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Agricultural Technology Demonstrations</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Extension Agent Training</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Farmer-to-Farmer Knowledge Exchange</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Digital Extension Services</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">Related Resources</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Farmer Training Manual
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Agricultural Technology Catalog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Cooperative Formation Guide
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Climate-Smart Agriculture Handbook
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">Contact This Directorate</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

