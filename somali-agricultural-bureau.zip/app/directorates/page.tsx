"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useTranslation } from "@/contexts/translation-context"
import { Leaf, Droplets, Users, FileText, BarChart, Shield } from "lucide-react"

const directorates = [
  {
    id: "crop-production",
    title: "Agricultural Production and Crop Protection",
    description: "Focuses on increasing agricultural productivity and protecting crops from pests and diseases.",
    director: "Ahmed Hassan",
    image: "/placeholder.svg?height=300&width=500&text=Crop+Production",
    icon: <Leaf className="h-6 w-6" />,
    responsibilities: [
      "Expansion of cultivated land and improvement of farming practices",
      "Distribution of high-quality seeds and fertilizers",
      "Implementation of pest and disease control measures",
      "Research and development of improved farming techniques",
      "Providing technical assistance and guidance to farmers",
    ],
  },
  {
    id: "extension",
    title: "Agricultural Extension and Technology Transfer",
    description: "Responsible for promoting modern farming techniques and technology adoption among farmers.",
    director: "Mohamed Ali",
    image: "/placeholder.svg?height=300&width=500&text=Extension",
    icon: <FileText className="h-6 w-6" />,
    responsibilities: [
      "Training farmers on advanced agricultural methods",
      "Facilitating the adoption of modern farming equipment",
      "Supporting agricultural cooperatives and farmer organizations",
      "Strengthening farmer networks for knowledge sharing",
      "Encouraging climate-smart agricultural practices",
    ],
  },
  {
    id: "natural-resources",
    title: "Natural Resources Development and Management",
    description:
      "Prioritizes the sustainable management and conservation of natural resources to ensure long-term agricultural viability.",
    director: "Fatima Hussein",
    image: "/placeholder.svg?height=300&width=500&text=Natural+Resources",
    icon: <Shield className="h-6 w-6" />,
    responsibilities: [
      "Soil and water conservation programs",
      "Reforestation and afforestation initiatives",
      "Sustainable land use planning and management",
      "Rehabilitation of degraded lands",
      "Construction of water harvesting structures for irrigation",
    ],
  },
  {
    id: "irrigation",
    title: "Small-Scale Irrigation Development",
    description: "Works to improve irrigation infrastructure and ensure efficient water use for agriculture.",
    director: "Amina Omar",
    image: "/placeholder.svg?height=300&width=500&text=Irrigation",
    icon: <Droplets className="h-6 w-6" />,
    responsibilities: [
      "Development and maintenance of small-scale irrigation systems",
      "Training farmers on irrigation management and water conservation",
      "Construction of irrigation canals and related structures",
      "Promoting efficient and sustainable water utilization for farming",
    ],
  },
  {
    id: "food-security",
    title: "Food Security and Nutrition",
    description: "Responsible for ensuring food security and promoting better nutrition within communities.",
    director: "Hassan Ibrahim",
    image: "/placeholder.svg?height=300&width=500&text=Food+Security",
    icon: <Users className="h-6 w-6" />,
    responsibilities: [
      "Implementation of food security programs to support vulnerable households",
      "Enhancing community resilience against food crises",
      "Nutrition education and awareness programs",
      "Supporting agricultural projects that enhance food availability and diversity",
    ],
  },
  {
    id: "marketing",
    title: "Marketing and Cooperative Development",
    description: "Strengthens agricultural markets and farmer cooperatives for better economic opportunities.",
    director: "Zahra Ahmed",
    image: "/placeholder.svg?height=300&width=500&text=Marketing",
    icon: <BarChart className="h-6 w-6" />,
    responsibilities: [
      "Facilitating access to agricultural markets",
      "Supporting the formation and strengthening of agricultural cooperatives",
      "Regulating the supply and distribution of agricultural inputs",
      "Monitoring market trends and price stability",
      "Promoting value-added agricultural products and agribusiness",
    ],
  },
]

export default function DirectoratesPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">{t("directorates.title")}</h1>

      <p className="mb-8 text-lg text-muted-foreground">{t("directorates.intro")}</p>

      <Tabs defaultValue="crop-production" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
          {directorates.map((directorate) => (
            <TabsTrigger key={directorate.id} value={directorate.id} className="text-xs md:text-sm">
              <span className="hidden md:inline">{directorate.title.split(" ")[0]}</span>
              <span className="md:hidden">{directorate.icon}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {directorates.map((directorate) => (
          <TabsContent key={directorate.id} value={directorate.id} className="mt-6">
            <Card>
              <div className="relative h-64 w-full overflow-hidden md:h-80">
                <Image
                  src={directorate.image || "/placeholder.svg"}
                  alt={directorate.title}
                  fill
                  className="object-cover"
                />
              </div>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle className="text-2xl">{directorate.title} Directorate</CardTitle>
                    <CardDescription className="mt-1">Director: {directorate.director}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-muted-foreground">{directorate.description}</p>

                <h3 className="mb-2 font-medium">{t("directorates.keyservices")}</h3>
                <ul className="ml-6 list-disc space-y-1">
                  {directorate.responsibilities.map((responsibility, index) => (
                    <li key={index} className="text-muted-foreground">
                      {responsibility}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href={`/directorates/${directorate.id}`}>{t("directorates.learnmore")}</Link>
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-12 rounded-lg bg-turquoise p-6 text-white">
        <h2 className="text-xl font-bold mb-2">{t("directorates.collaboration.title")}</h2>
        <p>{t("directorates.collaboration.text")}</p>
      </div>
    </div>
  )
}

