import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Directorates | Somali Regional State Agricultural Bureau",
  description: "Specialized directorates of the Somali Regional State Agricultural Bureau",
}

export default function DirectoratesLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return <>{children}</>
}

