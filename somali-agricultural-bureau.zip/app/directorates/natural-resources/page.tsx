"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTranslation } from "@/contexts/translation-context"

export default function NaturalResourcesPage() {
  const { t } = useTranslation()

  return (
    <div className="container py-12">
      <div className="mb-8">
        <Link href="/directorates" className="flex items-center text-turquoise hover:underline mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          {t("back.to.directorates")}
        </Link>
        <h1 className="text-3xl font-bold md:text-4xl">Natural Resources Development and Management Directorate</h1>
        <p className="mt-4 text-muted-foreground">
          This directorate prioritizes the sustainable management and conservation of natural resources to ensure
          long-term agricultural viability.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=Natural+Resources"
              alt="Natural Resources"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">{t("overview")}</h2>
              <p className="mt-4 text-muted-foreground">
                The Natural Resources Development and Management Directorate is responsible for ensuring the sustainable
                use and conservation of natural resources throughout the Somali Region. We work to protect and enhance
                soil, water, forest, and rangeland resources to support agricultural productivity and environmental
                health.
              </p>
              <p className="mt-4 text-muted-foreground">
                Our team implements programs that balance resource utilization with conservation, ensuring that natural
                resources can continue to support livelihoods for generations to come. We work closely with communities
                to develop participatory approaches to natural resource management.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold">{t("keyServices")}</h2>
              <div className="mt-4 space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Soil and Water Conservation</h3>
                    <p className="mt-2 text-muted-foreground">
                      We implement soil and water conservation measures to prevent erosion, improve soil fertility, and
                      enhance water infiltration. This includes the construction of physical structures like terraces,
                      check dams, and water harvesting structures, as well as biological measures like vegetative
                      barriers and area closures.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Reforestation and Afforestation</h3>
                    <p className="mt-2 text-muted-foreground">
                      We promote tree planting and forest management to increase forest cover, provide ecosystem
                      services, and support livelihoods. Our programs include community nurseries, woodlot
                      establishment, and agroforestry systems that integrate trees with agricultural production.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Sustainable Land Use Planning</h3>
                    <p className="mt-2 text-muted-foreground">
                      We develop and implement land use plans that optimize the use of land resources while ensuring
                      sustainability. This includes participatory land use planning with communities, watershed
                      management approaches, and integration of climate-smart practices into land management.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Rehabilitation of Degraded Lands</h3>
                    <p className="mt-2 text-muted-foreground">
                      We work to restore degraded lands through a combination of physical, biological, and management
                      interventions. This includes gully treatment, area enclosure, revegetation, and improved
                      management practices to allow natural regeneration.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium">Community-Based Natural Resource Management</h3>
                    <p className="mt-2 text-muted-foreground">
                      We support the establishment and strengthening of community-based natural resource management
                      systems. This includes building the capacity of community institutions, developing bylaws and
                      management plans, and facilitating benefit-sharing mechanisms.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-full bg-turquoise p-3 text-white">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">{t("director")}</h3>
                  <p className="text-muted-foreground">Fatima Hussein</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <p className="text-sm">
                  <span className="font-medium">{t("email")}:</span> fatima.hussein@srs-banr.gov.et
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("phone")}:</span> +251-257753584 Ext. 103
                </p>
                <p className="text-sm">
                  <span className="font-medium">{t("office")}:</span> JigJiga, Main Bureau Building, 2nd Floor
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("programs")}</h3>
              <ul className="mt-4 space-y-2">
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Watershed Management Program</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Community Forestry Initiative</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Land Rehabilitation Project</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Climate Resilience and Adaptation</span>
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-turquoise"></div>
                  <span>Sustainable Rangeland Management</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-medium">{t("relatedResources")}</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Natural Resource Management Guidelines
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Soil and Water Conservation Manual
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Community Forestry Handbook
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-turquoise hover:underline">
                    Land Rehabilitation Techniques
                  </Link>
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="mt-6">
            <Button asChild className="w-full">
              <Link href="/contact">{t("contactDirectorate")}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

