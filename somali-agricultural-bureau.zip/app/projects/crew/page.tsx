"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Users, Target, Clock, FileText } from "lucide-react"

export default function CREWPage() {
  const { t, language } = useTranslation()

  // Translation keys for CREW page
  const translations = {
    en: {
      title: "Climate Resilience and Economic Wellbeing (CREW) Program",
      breadcrumb: "Programs & Projects",
      overview: "Program Overview",
      overviewText1:
        "The Climate Resilience and Economic Wellbeing (CREW) Program is an innovative initiative that aims to build climate resilience while simultaneously enhancing economic opportunities for vulnerable communities in the Somali Region. The program takes an integrated approach to addressing climate change impacts, focusing on both adaptation and mitigation strategies that contribute to sustainable economic development.",
      overviewText2:
        "In the Somali Region, CREW works with communities that are particularly vulnerable to climate shocks, including drought, floods, and land degradation. The program is implemented by the Somali Regional State Agricultural Bureau in partnership with international donors and technical partners.",
      components: "Components",
      achievements: "Achievements",
      programDuration: "Program Duration",
      durationValue: "2023 - 2027",
      coverageArea: "Coverage Area",
      coverageValue: "Selected woredas in Sitti, Fafan, and Jarar zones",
      beneficiaries: "Beneficiaries",
      beneficiariesValue: "150,000 people in climate-vulnerable communities",
      fundingPartners: "Funding Partners",
      fundingValue: "USAID, EU, Government of Ethiopia",
      component1Title: "Climate-Smart Agriculture and Livelihoods",
      component1Text:
        "Promotes climate-smart agricultural practices and livelihood strategies that are resilient to climate shocks. This includes drought-resistant crop varieties, conservation agriculture, and efficient irrigation technologies.",
      component2Title: "Ecosystem-Based Adaptation",
      component2Text:
        "Implements ecosystem-based adaptation approaches that restore and protect natural ecosystems to enhance their resilience and the services they provide to communities. This includes watershed management, reforestation, and soil conservation.",
      component3Title: "Climate-Resilient Infrastructure",
      component3Text:
        "Develops climate-resilient infrastructure that can withstand climate impacts while supporting economic activities. This includes water harvesting structures, flood protection measures, and climate-proofed roads and markets.",
      component4Title: "Climate Finance and Market Access",
      component4Text:
        "Enhances access to climate finance and markets for climate-vulnerable communities. This includes climate-smart value chains, weather index insurance, and linkages to carbon markets and other climate finance mechanisms.",
      component5Title: "Climate Governance and Capacity Building",
      component5Text:
        "Strengthens climate governance and builds the capacity of local institutions and communities to plan for and respond to climate change. This includes climate-integrated development planning, early warning systems, and community-based adaptation.",
      achievementsTitle: "Key Achievements",
      achievementsText:
        "Since its implementation in the Somali Region, CREW has achieved significant results in building climate resilience and economic wellbeing.",
      climateSmartAgriculture: "Climate-Smart Agriculture",
      climateSmartAgriculture1: "Introduced drought-resistant crop varieties to 10,000 farmers",
      climateSmartAgriculture2: "Established 50 farmer field schools for climate-smart agriculture",
      climateSmartAgriculture3: "Developed 30 small-scale irrigation schemes covering 500 hectares",
      climateSmartAgriculture4: "Trained 5,000 farmers in conservation agriculture techniques",
      ecosystemRestoration: "Ecosystem Restoration",
      ecosystemRestoration1: "Rehabilitated 3,000 hectares of degraded land",
      ecosystemRestoration2: "Planted 500,000 trees in critical watersheds",
      ecosystemRestoration3: "Constructed 200 soil and water conservation structures",
      ecosystemRestoration4: "Established 20 community-managed protected areas",
      economicWellbeing: "Economic Wellbeing",
      economicWellbeing1: "Provided climate-resilient livelihood grants to 5,000 households",
      economicWellbeing2: "Established 30 climate-smart value chains",
      economicWellbeing3: "Enrolled 2,000 households in weather index insurance",
      economicWellbeing4: "Developed 10 climate-resilient market centers",
      contactInfo: "Contact Information",
      programCoordinator: "Program Coordinator",
      coordinatorName: "Amina Yusuf",
      email: "Email",
      emailValue: "crew@srs-banr.gov.et",
      phone: "Phone",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Contact Us",
      relatedResources: "Related Resources",
      resource1: "CREW Program Overview",
      resource2: "Climate Vulnerability Assessment",
      resource3: "Community Adaptation Guide",
      viewAllResources: "View All Resources",
      otherPrograms: "Other Programs",
    },
    so: {
      title: "Barnaamijka Adkeysiga Cimilada iyo Fayo-qabka Dhaqaalaha (CREW)",
      breadcrumb: "Barnaamijyada & Mashaariicda",
      overview: "Guudmarka Barnaamijka",
      overviewText1:
        "Barnaamijka Adkeysiga Cimilada iyo Fayo-qabka Dhaqaalaha (CREW) waa hindise hal-abuur ah oo ujeedadiisu tahay dhisidda adkeysiga cimilada iyada oo si waqti isku mid ah kor loogu qaadayo fursadaha dhaqaale ee bulshooyinka nugul ee Gobolka Soomaalida. Barnaamijku wuxuu qaataa hab isku dhafan oo wax looga qabanayo saamaynta isbeddelka cimilada, iyada oo diiradda la saarayo labadaba xeeladaha la qabsiga iyo yaraynta ee gacan ka geysanaya horumarinta dhaqaale ee waara.",
      overviewText2:
        "Gobolka Soomaalida, CREW wuxuu la shaqeeyaa bulshooyinka si gaar ah ugu nugul dhibaatooyinka cimilada, oo ay ku jiraan abaaraha, daadadka, iyo hoos u dhaca dhulka. Barnaamijka waxaa fuliya Xafiiska Beeraha ee Gobolka Soomaalida oo kaashanaya deeq-bixiyeyaasha caalamiga ah iyo lammaanayaasha farsamo.",
      components: "Qaybaha",
      achievements: "Guulaha",
      programDuration: "Muddada Barnaamijka",
      durationValue: "2023 - 2027",
      coverageArea: "Aagga Daboolka",
      coverageValue: "Degmooyinka la doortay ee degmooyinka Sitti, Fafan, iyo Jarar",
      beneficiaries: "Ka-faa'iideystayaasha",
      beneficiariesValue: "150,000 oo qof oo ka tirsan bulshooyinka nugul ee cimilada",
      fundingPartners: "Lammaanayaasha Maalgelinta",
      fundingValue: "USAID, EU, Dowladda Itoobiya",
      component1Title: "Beeraha Cimilada-Caqliga leh iyo Hab-nololeedyada",
      component1Text:
        "Waxay horumarisaa hab-dhaqannada beeraha cimilada-caqliga leh iyo xeeladaha hab-nololeed ee adkeysi u leh dhibaatooyinka cimilada. Tan waxaa ka mid ah noocyada dalagga ee adkeysi u leh abaaraha, beerashada ilaalinta, iyo tignoolajiyada waraabka hufan.",
      component2Title: "La qabsiga Ku salaysan Deegaanka",
      component2Text:
        "Waxay fulisaa hab-dhaqannada la qabsiga ku salaysan deegaanka ee soo celiya oo ilaaliya deegaannada dabiiciga ah si loo xoojiyo adkeysigooda iyo adeegyada ay siiyaan bulshooyinka. Tan waxaa ka mid ah maaraynta biyo-mareenka, dib-u-dhirinta, iyo ilaalinta ciidda.",
      component3Title: "Kaabayaasha Adkeysi u leh Cimilada",
      component3Text:
        "Waxay horumarisaa kaabayaasha adkeysi u leh cimilada ee adkeysan kara saamaynta cimilada iyada oo taageerto hawlaha dhaqaale. Tan waxaa ka mid ah dhismayaasha biyaha lagu keydiyo, tallaabooyinka ka hortagga daadka, iyo waddooyinka iyo suuqyada cimilada-la ilaaliyay.",
      component4Title: "Maalgashiga Cimilada iyo Helitaanka Suuqa",
      component4Text:
        "Waxay xoojisaa helitaanka maalgashiga cimilada iyo suuqyada ee bulshooyinka nugul ee cimilada. Tan waxaa ka mid ah silsiladaha qiimaha cimilada-caqliga leh, caymiska tusaha cimilada, iyo xiriirka suuqyada kaarboonka iyo habdhismeedyada kale ee maalgashiga cimilada.",
      component5Title: "Maamulka Cimilada iyo Dhisidda Awoodda",
      component5Text:
        "Waxay xoojisaa maamulka cimilada waxayna dhisaa awoodda hay'adaha maxalliga ah iyo bulshooyinka si ay u qorsheeyaan oo ay uga jawaabaan isbeddelka cimilada. Tan waxaa ka mid ah qorshaynta horumarinta isku dhafan ee cimilada, nidaamyada digniinta hore, iyo la qabsiga ku salaysan bulshada.",
      achievementsTitle: "Guulaha Muhiimka ah",
      achievementsText:
        "Tan iyo hirgelintii Gobolka Soomaalida, CREW waxay gaadhay natiijooyin muhiim ah oo lagu dhisayo adkeysiga cimilada iyo fayo-qabka dhaqaalaha.",
      climateSmartAgriculture: "Beeraha Cimilada-Caqliga leh",
      climateSmartAgriculture1: "Waxay soo bandhigtay noocyada dalagga ee adkeysi u leh abaaraha 10,000 oo beeraley ah",
      climateSmartAgriculture2:
        "Waxay samaysay 50 dugsi beerta oo beeraley ah oo loogu talagalay beeraha cimilada-caqliga leh",
      climateSmartAgriculture3: "Waxay horumarisay 30 qorshe oo waraab yar oo daboolaya 500 hektar",
      climateSmartAgriculture4: "Waxay tababartay 5,000 oo beeraley ah farsamooyinka beerashada ilaalinta",
      ecosystemRestoration: "Dib-u-soo-celinta Deegaanka",
      ecosystemRestoration1: "Waxay dib u soo celisay 3,000 hektar oo dhul hoos u dhacay",
      ecosystemRestoration2: "Waxay beeray 500,000 oo geed ah biyo-mareenada muhiimka ah",
      ecosystemRestoration3: "Waxay dhisay 200 dhisme oo ilaalinta ciidda iyo biyaha ah",
      ecosystemRestoration4: "Waxay samaysay 20 aag oo la ilaaliyo oo bulshada maamusho",
      economicWellbeing: "Fayo-qabka Dhaqaalaha",
      economicWellbeing1: "Waxay siisay deeqo hab-nololeed oo adkeysi u leh cimilada 5,000 qoys",
      economicWellbeing2: "Waxay samaysay 30 silsiladood oo qiimo oo cimilada-caqliga leh",
      economicWellbeing3: "Waxay diiwaangelisay 2,000 qoys oo caymiska tusaha cimilada ah",
      economicWellbeing4: "Waxay horumarisay 10 xarun suuq oo adkeysi u leh cimilada",
      contactInfo: "Macluumaadka Xiriirka",
      programCoordinator: "Isku-duwaha Barnaamijka",
      coordinatorName: "Aamina Yuusuf",
      email: "Iimaylka",
      emailValue: "crew@srs-banr.gov.et",
      phone: "Telefoonka",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Nala Soo Xiriir",
      relatedResources: "Ilaha La Xiriira",
      resource1: "Guudmarka Barnaamijka CREW",
      resource2: "Qiimaynta Nuglaanshaha Cimilada",
      resource3: "Hagaha La qabsiga Bulshada",
      viewAllResources: "Arag Dhammaan Ilaha",
      otherPrograms: "Barnaamijyada Kale",
    },
    am: {
      title: "የአየር ንብረት መቋቋም እና ኢኮኖሚያዊ ደህንነት (CREW) ፕሮግራም",
      breadcrumb: "ፕሮግራሞች እና ፕሮጀክቶች",
      overview: "የፕሮግራሙ አጠቃላይ እይታ",
      overviewText1:
        "የአየር ንብረት መቋቋም እና ኢኮኖሚያዊ ደህንነት (CREW) ፕሮግራም በሶማሌ ክልል ለተጋላጭ ማህበረሰቦች የአየር ንብረት መቋቋም አቅምን በመገንባት እና በተመሳሳይ ጊዜ የኢኮኖሚ እድሎችን በማሻሻል ላይ ያተኮረ አዲስ ተነሳሽነት ነው። ፕሮግራሙ ለዘላቂ የኢኮኖሚ ልማት አስተዋጽኦ የሚያደርጉ የመላመድ እና የማቅለል ስልቶችን በማተኮር የአየር ንብረት ለውጥ ተጽዕኖዎችን ለመቅረፍ ተቀናጀ አቀራረብ ይጠቀማል።",
      overviewText2:
        "በሶማሌ ክልል፣ CREW ድርቅ፣ ጎርፍ እና የመሬት መራቆትን ጨምሮ ለአየር ንብረት ድንገተኛ ለውጦች በተለይ ተጋላጭ ከሆኑ ማህበረሰቦች ጋር ይሰራል። ፕሮግራሙ በሶማሌ ክልል የግብርና ቢሮ ከዓለም አቀፍ ለጋሾች እና ከቴክኒክ አጋሮች ጋር በመተባበር ይተገበራል።",
      components: "ክፍሎች",
      achievements: "ውጤቶች",
      programDuration: "የፕሮግራም ጊዜ",
      durationValue: "2023 - 2027",
      coverageArea: "የሽፋን አካባቢ",
      coverageValue: "በሲቲ፣ ፋፋን እና ጃራር ዞኖች ውስጥ የተመረጡ ወረዳዎች",
      beneficiaries: "ተጠቃሚዎች",
      beneficiariesValue: "በአየር ንብረት-ተጋላጭ ማህበረሰቦች ውስጥ 150,000 ሰዎች",
      fundingPartners: "የገንዘብ አጋሮች",
      fundingValue: "USAID፣ EU፣ የኢትዮጵያ መንግስት",
      component1Title: "የአየር ንብረት-ብልህ ግብርና እና ኑሮ ዘይቤዎች",
      component1Text:
        "ለአየር ንብረት ድንገተኛ ለውጦች የሚቋቋሙ የአየር ንብረት-ብልህ የግብርና ልምዶችን እና የኑሮ ዘይቤ ስልቶችን ያስፋፋል። ይህ ድርቅን የሚቋቋሙ የሰብል ዝርያዎችን፣ የአፈር ጥበቃ ግብርናን እና ውጤታማ የመስኖ ቴክኖሎጂዎችን ያካትታል።",
      component2Title: "በስነ-ምህዳር ላይ የተመሰረተ መላመድ",
      component2Text:
        "የተፈጥሮ ስነ-ምህዳሮችን ለማደስ እና ለመጠበቅ የሚያስችሉ በስነ-ምህዳር ላይ የተመሰረቱ የመላመድ አቀራረቦችን ይተገብራል፣ ይህም የመቋቋም አቅማቸውን እና ለማህበረሰቦች የሚሰጧቸውን አገልግሎቶች ያሻሽላል። ይህ የተፋሰስ አስተዳደር፣ ደን ማልማት እና የአፈር ጥበቃን ያካትታል።",
      component3Title: "የአየር ንብረት-ለውጥ የሚቋቋም መሰረተ ልማት",
      component3Text:
        "የኢኮኖሚ እንቅስቃሴዎችን በመደገፍ የአየር ንብረት ተጽዕኖዎችን መቋቋም የሚችል የአየር ንብረት-ለውጥ የሚቋቋም መሰረተ ልማትን ያዳብራል። ይህ የውሃ ማሰባሰቢያ መዋቅሮችን፣ ከጎርፍ መከላከያ እርምጃዎችን እና የአየር ንብረት-ለውጥ የሚቋቋሙ መንገዶችን እና ገበያዎችን ያካትታል።",
      component4Title: "የአየር ንብረት ፋይናንስ እና የገበያ ተደራሽነት",
      component4Text:
        "ለአየር ንብረት-ተጋላጭ ማህበረሰቦች የአየር ንብረት ፋይናንስ እና ገበያዎች ተደራሽነትን ያሻሽላል። ይህ የአየር ንብረት-ብልህ የዋጋ ሰንሰለቶችን፣ የአየር ንብረት ኢንዴክስ ኢንሹራንስን እና ከካርቦን ገበያዎች እና ሌሎች የአየር ንብረት ፋይናንስ ዘዴዎች ጋር ግንኙነቶችን ያካትታል።",
      component5Title: "የአየር ንብረት አስተዳደር እና የአቅም ግንባታ",
      component5Text:
        "የአየር ንብረት አስተዳደርን ያጠናክራል እና የአካባቢ ተቋማት እና ማህበረሰቦች የአየር ንብረት ለውጥን ለማቀድ እና ምላሽ ለመስጠት ያላቸውን አቅም ይገነባል። ይህ የአየር ንብረት-ተቀናጀ የልማት ዕቅድ፣ ቀደም ሲል ማስጠንቀቂያ ስርዓቶች እና በማህበረሰብ ላይ የተመሰረተ መላመድን ያካትታል።",
      achievementsTitle: "ዋና ዋና ውጤቶች",
      achievementsText:
        "በሶማሌ ክልል ከተተገበረበት ጊዜ ጀምሮ፣ CREW የአየር ንብረት መቋቋም አቅም እና ኢኮኖሚያዊ ደህንነትን በመገንባት ረገድ ጉልህ ውጤቶችን አስመዝግቧል።",
      climateSmartAgriculture: "የአየር ንብረት-ብልህ ግብርና",
      climateSmartAgriculture1: "ለ10,000 አርሶ አደሮች ድርቅን የሚቋቋሙ የሰብል ዝርያዎችን አስተዋውቋል",
      climateSmartAgriculture2: "ለአየር ንብረት-ብልህ ግብርና 50 የአርሶ አደር የመስክ ትምህርት ቤቶችን አቋቁሟል",
      climateSmartAgriculture3: "500 ሄክታር የሚሸፍኑ 30 አነስተኛ የመስኖ ስርዓቶችን አዳብሯል",
      climateSmartAgriculture4: "5,000 አርሶ አደሮችን በአፈር ጥበቃ የግብርና ቴክኒኮች አሰልጥኗል",
      ecosystemRestoration: "የስነ-ምህዳር ማደስ",
      ecosystemRestoration1: "3,000 ሄክታር የተራቆተ መሬት አድሷል",
      ecosystemRestoration2: "በወሳኝ ተፋሰሶች 500,000 ዛፎችን ተክሏል",
      ecosystemRestoration3: "200 የአፈር እና የውሃ ጥበቃ መዋቅሮችን ገንብቷል",
      ecosystemRestoration4: "20 በማህበረሰብ የሚተዳደሩ የተጠበቁ አካባቢዎችን አቋቁሟል",
      economicWellbeing: "ኢኮኖሚያዊ ደህንነት",
      economicWellbeing1: "ለ5,000 ቤተሰቦች የአየር ንብረት-ለውጥ የሚቋቋሙ የኑሮ ዘይቤ ድጋፎችን ሰጥቷል",
      economicWellbeing2: "30 የአየር ንብረት-ብልህ የዋጋ ሰንሰለቶችን አቋቁሟል",
      economicWellbeing3: "2,000 ቤተሰቦችን በአየር ንብረት ኢንዴክስ ኢንሹራንስ ውስጥ አስመዝግቧል",
      economicWellbeing4: "10 የአየር ንብረት-ለውጥ የሚቋቋሙ የገበያ ማዕከላትን አዳብሯል",
      contactInfo: "የመገኛ መረጃ",
      programCoordinator: "የፕሮግራም አስተባባሪ",
      coordinatorName: "አሚና ዩሱፍ",
      email: "ኢሜይል",
      emailValue: "crew@srs-banr.gov.et",
      phone: "ስልክ",
      phoneValue: "+251-XXX-XXX",
      contactUs: "ያግኙን",
      relatedResources: "ተዛማጅ ሀብቶች",
      resource1: "የCREW ፕሮግራም አጠቃላይ እይታ",
      resource2: "የአየር ንብረት ተጋላጭነት ግምገማ",
      resource3: "የማህበረሰብ መላመድ መመሪያ",
      viewAllResources: "ሁሉንም ሀብቶች ይመልከቱ",
      otherPrograms: "ሌሎች ፕሮግራሞች",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground">
          <Link href="/projects" className="text-turquoise hover:underline">
            {currentTranslations.breadcrumb}
          </Link>{" "}
          / CREW
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=CREW+Program"
              alt="CREW Program"
              fill
              className="object-cover"
            />
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">{currentTranslations.overview}</TabsTrigger>
              <TabsTrigger value="components">{currentTranslations.components}</TabsTrigger>
              <TabsTrigger value="achievements">{currentTranslations.achievements}</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6 space-y-4">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.overview}</h2>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText1}</p>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText2}</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-turquoise" />
                      {currentTranslations.programDuration}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.durationValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-turquoise" />
                      {currentTranslations.coverageArea}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.coverageValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.beneficiaries}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.beneficiariesValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.fundingPartners}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.fundingValue}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="components" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.components}</h2>
                <p className="mt-2 text-muted-foreground">
                  CREW consists of several integrated components designed to build climate resilience and economic
                  wellbeing.
                </p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component1Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component1Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component2Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component2Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component3Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component3Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component4Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component4Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component5Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component5Text}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.achievementsTitle}</h2>
                <p className="mt-2 text-muted-foreground">{currentTranslations.achievementsText}</p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.climateSmartAgriculture}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.climateSmartAgriculture1}</li>
                      <li>{currentTranslations.climateSmartAgriculture2}</li>
                      <li>{currentTranslations.climateSmartAgriculture3}</li>
                      <li>{currentTranslations.climateSmartAgriculture4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.ecosystemRestoration}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.ecosystemRestoration1}</li>
                      <li>{currentTranslations.ecosystemRestoration2}</li>
                      <li>{currentTranslations.ecosystemRestoration3}</li>
                      <li>{currentTranslations.ecosystemRestoration4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-turquoise" />
                      {currentTranslations.economicWellbeing}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.economicWellbeing1}</li>
                      <li>{currentTranslations.economicWellbeing2}</li>
                      <li>{currentTranslations.economicWellbeing3}</li>
                      <li>{currentTranslations.economicWellbeing4}</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.contactInfo}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium">{currentTranslations.programCoordinator}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.coordinatorName}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.email}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.emailValue}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.phone}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.phoneValue}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/contact">{currentTranslations.contactUs}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.relatedResources}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource1}</p>
                  <p className="text-xs text-muted-foreground">PDF • 2.8 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource2}</p>
                  <p className="text-xs text-muted-foreground">PDF • 3.2 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource3}</p>
                  <p className="text-xs text-muted-foreground">PDF • 1.9 MB</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/resources">{currentTranslations.viewAllResources}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.otherPrograms}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/projects/psnp-5" className="block text-sm text-turquoise hover:underline">
                PSNP-5 Program
              </Link>
              <Link href="/projects/drdip-ii" className="block text-sm text-turquoise hover:underline">
                DRDIP-II
              </Link>
              <Link href="/projects/pact" className="block text-sm text-turquoise hover:underline">
                PACT
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

