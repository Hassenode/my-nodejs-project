"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Users, Target, Clock, FileText } from "lucide-react"

export default function PACTPage() {
  const { t, language } = useTranslation()

  // Translation keys for PACT page
  const translations = {
    en: {
      title: "Pastoral Areas Climate Transformation (PACT) Program",
      breadcrumb: "Programs & Projects",
      overview: "Program Overview",
      overviewText1:
        "The Pastoral Areas Climate Transformation (PACT) Program is a comprehensive initiative designed to enhance climate resilience and sustainable development in pastoral areas of Ethiopia, with a significant focus on the Somali Region. The program aims to transform pastoral livelihoods by improving rangeland management, water resources, and market access while building adaptive capacity to climate change.",
      overviewText2:
        "In the Somali Region, PACT works with pastoral and agro-pastoral communities to implement climate-smart practices, strengthen natural resource management, and diversify livelihoods. The program is implemented by the Somali Regional State Agricultural Bureau in partnership with the Ministry of Agriculture, the World Bank, and other development partners.",
      components: "Components",
      targeting: "Targeting",
      achievements: "Achievements",
      programDuration: "Program Duration",
      durationValue: "2023 - 2028",
      coverageArea: "Coverage Area",
      coverageValue: "All pastoral and agro-pastoral zones of Somali Region",
      beneficiaries: "Beneficiaries",
      beneficiariesValue: "Over 250,000 pastoral and agro-pastoral households",
      fundingPartners: "Funding Partners",
      fundingValue: "World Bank, Green Climate Fund, Government of Ethiopia",
      component1Title: "Climate-Smart Rangeland Management",
      component1Text:
        "Supports sustainable rangeland management practices, including rotational grazing, invasive species control, and rangeland rehabilitation. This component works with traditional rangeland management systems to enhance their effectiveness in the face of climate change.",
      component2Title: "Water Resource Development",
      component2Text:
        "Improves access to water for both human and livestock consumption through the development of climate-resilient water infrastructure, including water harvesting structures, shallow wells, and small-scale irrigation systems.",
      component3Title: "Livelihood Diversification and Market Access",
      component3Text:
        "Supports the diversification of pastoral livelihoods through value chain development, market linkages, and the promotion of alternative income sources. This includes support for livestock value chains, dairy processing, and non-livestock livelihoods.",
      component4Title: "Climate Information Services and Early Warning",
      component4Text:
        "Strengthens climate information services and early warning systems to help pastoral communities make informed decisions about herd management, migration, and resource use in response to changing climate conditions.",
      component5Title: "Institutional Strengthening and Knowledge Management",
      component5Text:
        "Enhances the capacity of government institutions, community organizations, and traditional governance structures to plan, implement, and monitor climate-resilient development interventions in pastoral areas.",
      targetingTitle: "Targeting, Gender, Youth and Disability Inclusion",
      targetingText:
        "PACT's primary target groups are the poorest and poor households, and vulnerable people who have little access to assets and economic opportunities due to social exclusion, marginalization and the negative impact of climate change. The program prioritizes:",
      targetingPoint1: "Women: Aiming for 50% participation in program activities.",
      targetingPoint2: "Youth: Targeting 40% participation, with a focus on both young women and men.",
      targetingPoint3: "Persons with Disabilities: Ensuring 5% participation and inclusion in program benefits.",
      targetingPoint4:
        "Pastoralists and agro-pastoralists: Addressing their specific vulnerabilities to poverty and food insecurity.",
      achievementsTitle: "Key Achievements",
      achievementsText:
        "Since its implementation in the Somali Region, PACT has achieved significant results in building climate resilience.",
      rangelandManagement: "Rangeland Management",
      rangelandManagement1: "Rehabilitated 20,000 hectares of degraded rangelands",
      rangelandManagement2: "Established 50 community rangeland management committees",
      rangelandManagement3: "Cleared invasive species from 5,000 hectares of grazing land",
      rangelandManagement4: "Developed 30 community grazing management plans",
      waterResources: "Water Resources",
      waterResources1: "Constructed 100 water harvesting structures",
      waterResources2: "Developed 50 shallow wells for human and livestock use",
      waterResources3: "Established 20 small-scale irrigation schemes",
      waterResources4: "Trained 200 water management committees",
      livelihoodDiversification: "Livelihood Diversification",
      livelihoodDiversification1: "Supported 5,000 households with livelihood diversification grants",
      livelihoodDiversification2: "Established 20 livestock market centers",
      livelihoodDiversification3: "Formed 100 producer groups for dairy and meat value chains",
      livelihoodDiversification4: "Provided business development services to 2,000 pastoral entrepreneurs",
      contactInfo: "Contact Information",
      programCoordinator: "Program Coordinator",
      coordinatorName: "Omar Abdi",
      email: "Email",
      emailValue: "pact@srs-banr.gov.et",
      phone: "Phone",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Contact Us",
      relatedResources: "Related Resources",
      resource1: "PACT Program Document",
      resource2: "Climate Adaptation Strategy",
      resource3: "Pastoral Community Guide",
      viewAllResources: "View All Resources",
      otherPrograms: "Other Programs",
      downloadManual: "Download PACT Programme Implementation Manual",
    },
    so: {
      title: "Barnaamijka Isbeddelka Cimilada ee Aagagga Xoolo-dhaqatada (PACT)",
      breadcrumb: "Barnaamijyada & Mashaariicda",
      overview: "Guudmarka Barnaamijka",
      overviewText1:
        "Barnaamijka Isbeddelka Cimilada ee Aagagga Xoolo-dhaqatada (PACT) waa hindise dhammaystiran oo loogu talagalay in lagu xoojiyo adkeysiga cimilada iyo horumarinta waara ee aagagga xoolo-dhaqatada ee Itoobiya, iyada oo diiradda la saarayo Gobolka Soomaalida. Barnaamijku wuxuu ujeedadiisu tahay in uu beddelo hab-nololeedka xoolo-dhaqatada iyada oo la hagaajinayo maaraynta dhul-daaqsimeedka, kheyraadka biyaha, iyo helitaanka suuqa iyada oo la dhisayo awood la qabsiga cimilada isbeddelka.",
      overviewText2:
        "Gobolka Soomaalida, PACT wuxuu la shaqeeyaa bulshooyinka xoolo-dhaqatada iyo beeraha-xoolo-dhaqatada si loo hirgeliyo hab-dhaqannada cimilada-caqliga leh, loo xoojiyo maaraynta kheyraadka dabiiciga ah, loona kala duwaynayo hab-nololeedyada. Barnaamijka waxaa fuliya Xafiiska Beeraha ee Gobolka Soomaalida oo kaashanaya Wasaaradda Beeraha, Bangiga Adduunka, iyo lammaanayaasha horumarinta kale.",
      components: "Qaybaha",
      targeting: "Bartilmaameedka",
      achievements: "Guulaha",
      programDuration: "Muddada Barnaamijka",
      durationValue: "2023 - 2028",
      coverageArea: "Aagga Daboolka",
      coverageValue: "Dhammaan aagagga xoolo-dhaqatada iyo beeraha-xoolo-dhaqatada ee Gobolka Soomaalida",
      beneficiaries: "Ka-faa'iideystayaasha",
      beneficiariesValue: "In ka badan 250,000 oo qoys oo xoolo-dhaqato iyo beeraha-xoolo-dhaqato ah",
      fundingPartners: "Lammaanayaasha Maalgelinta",
      fundingValue: "Bangiga Adduunka, Sanduuqa Cimilada Cagaaran, Dowladda Itoobiya",
      component1Title: "Maaraynta Dhul-daaqsimeedka Cimilada-Caqliga leh",
      component1Text:
        "Waxay taageertaa hab-dhaqannada maaraynta dhul-daaqsimeedka ee waara, oo ay ku jiraan daaqsinta wareegga, xakamaynta noocyada duugoobay, iyo dib-u-soo-celinta dhul-daaqsimeedka. Qaybtan waxay la shaqeysaa nidaamyada maaraynta dhul-daaqsimeedka ee dhaqanka si loo xoojiyo waxtar-u-yeelashadooda iyada oo la wajahayo isbeddelka cimilada.",
      component2Title: "Horumarinta Kheyraadka Biyaha",
      component2Text:
        "Waxay hagaajisaa helitaanka biyaha ee labadaba isticmaalka dadka iyo xoolaha iyada oo loo marayo horumarinta kaabayaasha biyaha ee adkeysi u leh cimilada, oo ay ku jiraan dhismayaasha biyaha lagu keydiyo, ceelasha dayacan, iyo nidaamyada waraabka yar.",
      component3Title: "Kala duwanaanshaha Hab-nololeedka iyo Helitaanka Suuqa",
      component3Text:
        "Waxay taageertaa kala duwanaanshaha hab-nololeedyada xoolo-dhaqatada iyada oo loo marayo horumarinta silsiladda qiimaha, xiriirka suuqa, iyo horumarinta ilaha dakhliga ee kale. Tan waxaa ka mid ah taageerada silsiladaha qiimaha xoolaha, habaynta caanaha, iyo hab-nololeedyada aan xoolaha ahayn.",
      component4Title: "Adeegyada Macluumaadka Cimilada iyo Digniinta Hore",
      component4Text:
        "Waxay xoojisaa adeegyada macluumaadka cimilada iyo nidaamyada digniinta hore si ay uga caawiso bulshooyinka xoolo-dhaqatada inay go'aano wax ku ool ah ka gaaraan maaraynta xoolaha, socdaalka, iyo isticmaalka kheyraadka iyada oo jawaab looga dhigayo xaaladaha cimilada ee isbeddelaya.",
      component5Title: "Xoojinta Hay'adaha iyo Maaraynta Aqoonta",
      component5Text:
        "Waxay xoojisaa awoodda hay'adaha dowladda, ururada bulshada, iyo qaab-dhismeedyada maamulka dhaqanka si ay u qorsheeyaan, u fuliyaan, oo ay ula socdaan faragelinta horumarinta adkeysiga cimilada ee aagagga xoolo-dhaqatada.",
      targetingTitle: "Bartilmaameedka, Jinsiga, Dhallinyarada iyo Ka-qaybgalka Naafada",
      targetingText:
        "Kooxaha bartilmaameedka koowaad ee PACT waa qoysaska ugu saboolsan iyo kuwa saboolka ah, iyo dadka nugul ee aan heli karin hantida iyo fursadaha dhaqaale sababo la xiriira ka-saaridda bulshada, faquuqa iyo saameynta xun ee isbeddelka cimilada. Barnaamijku mudnaanta siiyaa:",
      targetingPoint1: "Dumarka: Waxay ku taameynayaan 50% ka-qaybgalka hawlaha barnaamijka.",
      targetingPoint2:
        "Dhallinyarada: Waxay bartilmaameedsanayaan 40% ka-qaybgalka, iyada oo diiradda la saarayo labadaba haweenka iyo ragga da'da yar.",
      targetingPoint3:
        "Dadka Naafada ah: Waxay hubinayaan 5% ka-qaybgalka iyo ka-mid-noqoshada faa'iidooyinka barnaamijka.",
      targetingPoint4:
        "Xoolo-dhaqatada iyo beeraha-xoolo-dhaqatada: Waxay wax ka qabanayaan nuglaanshahooda gaarka ah ee saboolnimada iyo amni-darrada cuntada.",
      achievementsTitle: "Guulaha Muhiimka ah",
      achievementsText:
        "Tan iyo hirgelintii Gobolka Soomaalida, PACT waxay gaadhay natiijooyin muhiim ah oo lagu dhisayo adkeysiga cimilada.",
      rangelandManagement: "Maaraynta Dhul-daaqsimeedka",
      rangelandManagement1: "Waxay dib u soo celisay 20,000 hektar oo dhul-daaqsimeed hoos u dhacay",
      rangelandManagement2: "Waxay samaysay 50 guddi oo maaraynta dhul-daaqsimeedka bulshada ah",
      rangelandManagement3: "Waxay ka nadiifisay noocyada duugoobay 5,000 hektar oo dhul daaqsimeed ah",
      rangelandManagement4: "Waxay horumarisay 30 qorshe oo maaraynta daaqsinta bulshada ah",
      waterResources: "Kheyraadka Biyaha",
      waterResources1: "Waxay dhisay 100 dhisme oo biyaha lagu keydiyo",
      waterResources2: "Waxay horumarisay 50 ceel oo dayacan oo loogu talagalay isticmaalka dadka iyo xoolaha",
      waterResources3: "Waxay samaysay 20 qorshe oo waraab yar",
      waterResources4: "Waxay tababartay 200 guddi oo maaraynta biyaha ah",
      livelihoodDiversification: "Kala duwanaanshaha Hab-nololeedka",
      livelihoodDiversification1: "Waxay taageertay 5,000 qoys oo deeqo kala duwanaansho hab-nololeed ah",
      livelihoodDiversification2: "Waxay samaysay 20 xarun suuq oo xoolo ah",
      livelihoodDiversification3: "Waxay samaysay 100 kooxood oo wax soo saara silsiladaha qiimaha caanaha iyo hilibka",
      livelihoodDiversification4: "Waxay siisay adeegyada horumarinta ganacsiga 2,000 ganacsi-yahan xoolo-dhaqato ah",
      contactInfo: "Macluumaadka Xiriirka",
      programCoordinator: "Isku-duwaha Barnaamijka",
      coordinatorName: "Cumar Cabdi",
      email: "Iimaylka",
      emailValue: "pact@srs-banr.gov.et",
      phone: "Telefoonka",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Nala Soo Xiriir",
      relatedResources: "Ilaha La Xiriira",
      resource1: "Dukumentiga Barnaamijka PACT",
      resource2: "Istiraatiijiyada La qabsiga Cimilada",
      resource3: "Hagaha Bulshada Xoolo-dhaqatada",
      viewAllResources: "Arag Dhammaan Ilaha",
      otherPrograms: "Barnaamijyada Kale",
      downloadManual: "Soo Dejiso Buugga Hirgelinta Barnaamijka PACT",
    },
    am: {
      title: "የአርብቶ አደር አካባቢዎች የአየር ንብረት ለውጥ (PACT) ፕሮግራም",
      breadcrumb: "ፕሮግራሞች እና ፕሮጀክቶች",
      overview: "የፕሮግራሙ አጠቃላይ እይታ",
      overviewText1:
        "የአርብቶ አደር አካባቢዎች የአየር ንብረት ለውጥ (PACT) ፕሮግራም በኢትዮጵያ የአርብቶ አደር አካባቢዎች የአየር ንብረት ለውጥ መቋቋም እና ዘላቂ ልማትን ለማሻሻል የተነደፈ ሁለገብ ተነሳሽነት ሲሆን በሶማሌ ክልል ላይ ትኩረት ያደረገ ነው። ፕሮግራሙ የግጦሽ መሬት አስተዳደርን፣ የውሃ ሀብቶችን እና የገበያ ተደራሽነትን በማሻሻል እና የአየር ንብረት ለውጥን የመላመድ አቅምን በመገንባት የአርብቶ አደር ኑሮን ለመለወጥ ያለመ ነው።",
      overviewText2:
        "በሶማሌ ክልል፣ PACT ከአርብቶ አደር እና ከግብርና-አርብቶ አደር ማህበረሰቦች ጋር በመሆን የአየር ንብረት-ብልህ ልምዶችን ለመተግበር፣ የተፈጥሮ ሀብት አስተዳደርን ለማጠናከር እና የኑሮ መንገዶችን ለማዳበር ይሰራል። ፕሮግራሙ በሶማሌ ክልል የግብርና ቢሮ በግብርና ሚኒስቴር፣ በዓለም ባንክ እና በሌሎች የልማት አጋሮች ትብብር ይተገበራል።",
      components: "ክፍሎች",
      targeting: "ዒላማ ማድረግ",
      achievements: "ውጤቶች",
      programDuration: "የፕሮግራም ጊዜ",
      durationValue: "2023 - 2028",
      coverageArea: "የሽፋን አካባቢ",
      coverageValue: "የሶማሌ ክልል ሁሉም የአርብቶ አደር እና የግብርና-አርብቶ አደር ዞኖች",
      beneficiaries: "ተጠቃሚዎች",
      beneficiariesValue: "ከ250,000 በላይ የአርብቶ አደር እና የግብርና-አርብቶ አደር ቤተሰቦች",
      fundingPartners: "የገንዘብ አጋሮች",
      fundingValue: "የዓለም ባንክ፣ የአረንጓዴ አየር ንብረት ፈንድ፣ የኢትዮጵያ መንግስት",
      component1Title: "የአየር ንብረት-ብልህ የግጦሽ መሬት አስተዳደር",
      component1Text:
        "የዘወትር ግጦሽ፣ የወራሪ ዝርያዎች ቁጥጥር እና የግጦሽ መሬት ማደስን ጨምሮ ዘላቂ የግጦሽ መሬት አስተዳደር ልምዶችን ይደግፋል። ይህ ክፍል በአየር ንብረት ለውጥ ፊት ውጤታማነታቸውን ለማሻሻል ከባህላዊ የግጦሽ መሬት አስተዳደር ስርዓቶች ጋር ይሰራል።",
      component2Title: "የውሃ ሀብት ልማት",
      component2Text:
        "የውሃ ማሰባሰቢያ መዋቅሮችን፣ ጥልቀታቸው ትንሽ የሆኑ ጉድጓዶችን እና አነስተኛ የመስኖ ስርዓቶችን ጨምሮ የአየር ንብረት-ለውጥ የሚቋቋሙ የውሃ መሰረተ ልማቶችን በማዳበር ለሰው እና ለእንስሳት ፍጆታ የውሃ ተደራሽነትን ያሻሽላል።",
      component3Title: "የኑሮ ዘይቤ ብዝሃነት እና የገበያ ተደራሽነት",
      component3Text:
        "የዋጋ ሰንሰለት ልማት፣ የገበያ ግንኙነቶች እና አማራጭ የገቢ ምንጮችን በማስፋፋት አማካኝነት የአርብቶ አደር ኑሮ ዘይቤዎችን ብዝሃነት ይደግፋል። ይህ የእንስሳት ዋጋ ሰንሰለቶች፣ የወተት ማቀነባበሪያ እና ከእንስሳት ውጪ የሆኑ ኑሮ ዘይቤዎችን ድጋፍ ያካትታል።",
      component4Title: "የአየር ንብረት መረጃ አገልግሎቶች እና ቀደም ሲል ማስጠንቀቂያ",
      component4Text:
        "የአርብቶ አደር ማህበረሰቦች ስለ መንጋ አስተዳደር፣ ስደት እና ለተለዋዋጭ የአየር ንብረት ሁኔታዎች ምላሽ ለመስጠት የሀብት አጠቃቀም ላይ መረጃ ላይ የተመሰረተ ውሳኔ እንዲወስኑ ለመርዳት የአየር ንብረት መረጃ አገልግሎቶችን እና ቀደም ሲል ማስጠንቀቂያ ስርዓቶችን ያጠናክራል።",
      component5Title: "ተቋማዊ ማጠናከር እና የእውቀት አስተዳደር",
      component5Text:
        "በአርብቶ አደር አካባቢዎች የአየር ንብረት-ለውጥ የሚቋቋሙ የልማት ጣልቃ ገብነቶችን ለማቀድ፣ ለመተግበር እና ለመከታተል የመንግስት ተቋማት፣ የማህበረሰብ ድርጅቶች እና ባህላዊ የአስተዳደር መዋቅሮች አቅምን ያሻሽላል።",
      targetingTitle: "ዒላማ ማድረግ፣ ፆታ፣ ወጣቶች እና የአካል ጉዳተኞች ተሳትፎ",
      targetingText:
        "የPACT ዋና ዒላማ ቡድኖች በማህበራዊ ገለልተኝነት፣ ጥቃት እና በአየር ንብረት ለውጥ አሉታዊ ተጽዕኖ ምክንያት ንብረቶችን እና የኢኮኖሚ እድሎችን ለማግኘት ትንሽ ተደራሽነት ያላቸው በጣም ድሆች እና ድሆች ቤተሰቦች እና ተጋላጭ ሰዎች ናቸው። ፕሮግራሙ ቅድሚያ የሚሰጣቸው፡-",
      targetingPoint1: "ሴቶች፡ በፕሮግራም እንቅስቃሴዎች ውስጥ 50% ተሳትፎ ለማግኘት ዒላማ ማድረግ።",
      targetingPoint2: "ወጣቶች፡ በወጣት ሴቶች እና ወንዶች ላይ ትኩረት በማድረግ 40% ተሳትፎን ዒላማ ማድረግ።",
      targetingPoint3: "የአካል ጉዳተኞች፡ በፕሮግራም ጥቅሞች ውስጥ 5% ተሳትፎ እና ተሳትፎን ማረጋገጥ።",
      targetingPoint4: "አርብቶ አደሮች እና ግብርና-አርብቶ አደሮች፡ ለድህነት እና ለምግብ ዋስትና እጥረት ያላቸውን ልዩ ተጋላጭነት መቅረፍ።",
      achievementsTitle: "ዋና ዋና ውጤቶች",
      achievementsText: "በሶማሌ ክልል ከተተገበረበት ጊዜ ጀምሮ፣ PACT የአየር ንብረት ለውጥ መቋቋም አቅምን በመገንባት ረገድ ጉልህ ውጤቶችን አስመዝግቧል።",
      rangelandManagement: "የግጦሽ መሬት አስተዳደር",
      rangelandManagement1: "20,000 ሄክታር የተራቆተ የግጦሽ መሬት አድሷል",
      rangelandManagement2: "50 የማህበረሰብ የግጦሽ መሬት አስተዳደር ኮሚቴዎችን አቋቁሟል",
      rangelandManagement3: "ከ5,000 ሄክታር የግጦሽ መሬት ወራሪ ዝርያዎችን አጽድቷል",
      rangelandManagement4: "30 የማህበረሰብ የግጦሽ አስተዳደር ዕቅዶችን አዳብሯል",
      waterResources: "የውሃ ሀብቶች",
      waterResources1: "100 የውሃ ማሰባሰቢያ መዋቅሮችን ገንብቷል",
      waterResources2: "ለሰው እና ለእንስሳት አጠቃቀም 50 ጥልቀታቸው ትንሽ የሆኑ ጉድጓዶችን አዳብሯል",
      waterResources3: "20 አነስተኛ የመስኖ ስርዓቶችን አቋቁሟል",
      waterResources4: "200 የውሃ አስተዳደር ኮሚቴዎችን አሰልጥኗል",
      livelihoodDiversification: "የኑሮ ዘይቤ ብዝሃነት",
      livelihoodDiversification1: "ለ5,000 ቤተሰቦች የኑሮ ዘይቤ ብዝሃነት ድጋፎችን ሰጥቷል",
      livelihoodDiversification2: "20 የእንስሳት ገበያ ማዕከላትን አቋቁሟል",
      livelihoodDiversification3: "ለወተት እና ለስጋ ዋጋ ሰንሰለቶች 100 የአምራች ቡድኖችን አዋቅሯል",
      livelihoodDiversification4: "ለ2,000 የአርብቶ አደር ነጋዴዎች የንግድ ልማት አገልግሎቶችን ሰጥቷል",
      contactInfo: "የመገኛ መረጃ",
      programCoordinator: "የፕሮግራም አስተባባሪ",
      coordinatorName: "ኦማር አብዲ",
      email: "ኢሜይል",
      emailValue: "pact@srs-banr.gov.et",
      phone: "ስልክ",
      phoneValue: "+251-XXX-XXX",
      contactUs: "ያግኙን",
      relatedResources: "ተዛማጅ ሀብቶች",
      resource1: "የPACT ፕሮግራም ሰነድ",
      resource2: "የአየር ንብረት ለውጥ መላመድ ስትራቴጂ",
      resource3: "የአርብቶ አደር ማህበረሰብ መመሪያ",
      viewAllResources: "ሁሉንም ሀብቶች ይመልከቱ",
      otherPrograms: "ሌሎች ፕሮግራሞች",
      downloadManual: "የPACT ፕሮግራም አተገባበር መመሪያን ያውርዱ",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground">
          <Link href="/projects" className="text-turquoise hover:underline">
            {currentTranslations.breadcrumb}
          </Link>{" "}
          / PACT
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=PACT+Program"
              alt="PACT Program"
              fill
              className="object-cover"
            />
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">{currentTranslations.overview}</TabsTrigger>
              <TabsTrigger value="components">{currentTranslations.components}</TabsTrigger>
              <TabsTrigger value="targeting">{currentTranslations.targeting}</TabsTrigger>
              <TabsTrigger value="achievements">{currentTranslations.achievements}</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6 space-y-4">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.overview}</h2>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText1}</p>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText2}</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-turquoise" />
                      {currentTranslations.programDuration}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.durationValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-turquoise" />
                      {currentTranslations.coverageArea}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.coverageValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.beneficiaries}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.beneficiariesValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.fundingPartners}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.fundingValue}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="components" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.components}</h2>
                <p className="mt-2 text-muted-foreground">
                  PACT consists of several integrated components designed to build climate resilience and economic
                  wellbeing.
                </p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component1Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component1Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component2Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component2Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component3Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component3Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component4Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component4Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component5Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component5Text}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="targeting" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.targetingTitle}</h2>
                <p className="mt-2 text-muted-foreground">{currentTranslations.targetingText}</p>
                <ul className="list-disc ml-6 space-y-2 text-muted-foreground">
                  <li>{currentTranslations.targetingPoint1}</li>
                  <li>{currentTranslations.targetingPoint2}</li>
                  <li>{currentTranslations.targetingPoint3}</li>
                  <li>{currentTranslations.targetingPoint4}</li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.achievementsTitle}</h2>
                <p className="mt-2 text-muted-foreground">{currentTranslations.achievementsText}</p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.rangelandManagement}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.rangelandManagement1}</li>
                      <li>{currentTranslations.rangelandManagement2}</li>
                      <li>{currentTranslations.rangelandManagement3}</li>
                      <li>{currentTranslations.rangelandManagement4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.waterResources}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.waterResources1}</li>
                      <li>{currentTranslations.waterResources2}</li>
                      <li>{currentTranslations.waterResources3}</li>
                      <li>{currentTranslations.waterResources4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-turquoise" />
                      {currentTranslations.livelihoodDiversification}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.livelihoodDiversification1}</li>
                      <li>{currentTranslations.livelihoodDiversification2}</li>
                      <li>{currentTranslations.livelihoodDiversification3}</li>
                      <li>{currentTranslations.livelihoodDiversification4}</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.contactInfo}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium">{currentTranslations.programCoordinator}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.coordinatorName}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.email}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.emailValue}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.phone}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.phoneValue}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/contact">{currentTranslations.contactUs}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.relatedResources}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource1}</p>
                  <p className="text-xs text-muted-foreground">PDF • 3.5 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource2}</p>
                  <p className="text-xs text-muted-foreground">PDF • 2.3 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource3}</p>
                  <p className="text-xs text-muted-foreground">PDF • 1.7 MB</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/resources">{currentTranslations.viewAllResources}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.otherPrograms}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/projects/psnp-5" className="block text-sm text-turquoise hover:underline">
                PSNP-5 Program
              </Link>
              <Link href="/projects/drdip-ii" className="block text-sm text-turquoise hover:underline">
                DRDIP-II
              </Link>
              <Link href="/projects/crew" className="block text-sm text-turquoise hover:underline">
                CREW
              </Link>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="#">{currentTranslations.downloadManual}</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

