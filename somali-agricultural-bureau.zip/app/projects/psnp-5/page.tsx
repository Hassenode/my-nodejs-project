"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Users, Target, Clock, FileText } from "lucide-react"

export default function PSNP5Page() {
  const { t, language } = useTranslation()

  // Translation keys for PSNP-5 page
  const translations = {
    en: {
      title: "Productive Safety Net Program (PSNP-5)",
      breadcrumb: "Programs & Projects",
      overview: "Program Overview",
      overviewText1:
        "The Productive Safety Net Program (PSNP-5) is Ethiopia's flagship social protection program aimed at improving food security and resilience among vulnerable households in rural areas. The program provides cash and food transfers to chronically food-insecure households in exchange for their participation in public works activities that build community assets.",
      overviewText2:
        "In the Somali Region, PSNP-5 focuses on building resilience against drought, improving agricultural productivity, and enhancing livelihood opportunities for pastoralist and agro-pastoralist communities. The program is implemented by the Somali Regional State Agricultural Bureau in collaboration with the Ministry of Agriculture and international partners.",
      components: "Components",
      achievements: "Achievements",
      programDuration: "Program Duration",
      durationValue: "2021 - 2025",
      coverageArea: "Coverage Area",
      coverageValue: "All zones of Somali Regional State",
      beneficiaries: "Beneficiaries",
      beneficiariesValue: "Over 300,000 households in the Somali Region",
      fundingPartners: "Funding Partners",
      fundingValue: "World Bank, USAID, DFID, EU, and Government of Ethiopia",
      component1Title: "Safety Net Transfers",
      component1Text:
        "Provides predictable cash or food transfers to chronically food-insecure households. Transfers are provided in exchange for participation in public works for able-bodied members, while direct support is provided to labor-constrained households.",
      component2Title: "Livelihood Development",
      component2Text:
        "Supports households to increase and diversify their incomes through technical assistance, training, and access to financial services. This component includes support for climate-smart agriculture, livestock development, and off-farm income-generating activities.",
      component3Title: "Climate Resilience",
      component3Text:
        "Focuses on building community assets that enhance resilience to climate shocks, such as soil and water conservation structures, small-scale irrigation schemes, and rangeland management interventions.",
      component4Title: "Institutional Strengthening",
      component4Text:
        "Enhances the capacity of government institutions at regional, woreda, and kebele levels to effectively implement the program and respond to emergencies.",
      achievementsTitle: "Key Achievements",
      achievementsText:
        "Since its implementation in the Somali Region, PSNP-5 has achieved significant results in improving food security and building resilience.",
      householdImpact: "Household Impact",
      householdImpact1: "Improved food security for over 300,000 households",
      householdImpact2: "Reduced negative coping strategies during drought periods by 40%",
      householdImpact3: "Increased household asset ownership by 25% among beneficiaries",
      householdImpact4: "Enhanced dietary diversity for women and children",
      communityAssets: "Community Assets",
      communityAssets1: "Constructed 150 small-scale irrigation schemes",
      communityAssets2: "Rehabilitated over 10,000 hectares of degraded land",
      communityAssets3: "Developed 200 water harvesting structures",
      communityAssets4: "Improved 500 kilometers of rural roads",
      institutionalDev: "Institutional Development",
      institutionalDev1: "Strengthened early warning systems in all woredas",
      institutionalDev2: "Enhanced capacity of 500 agricultural extension workers",
      institutionalDev3: "Improved coordination between humanitarian and development interventions",
      institutionalDev4: "Established digital beneficiary registry and payment systems",
      contactInfo: "Contact Information",
      programCoordinator: "Program Coordinator",
      coordinatorName: "Ahmed Hassan",
      email: "Email",
      emailValue: "psnp5@srs-banr.gov.et",
      phone: "Phone",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Contact Us",
      relatedResources: "Related Resources",
      resource1: "PSNP-5 Implementation Manual",
      resource2: "Annual Progress Report 2024",
      resource3: "PSNP-5 Beneficiary Guide",
      viewAllResources: "View All Resources",
      otherPrograms: "Other Programs",
    },
    so: {
      title: "Barnaamijka Shabakadda Badbaadada Wax Soo Saarka (PSNP-5)",
      breadcrumb: "Barnaamijyada & Mashaariicda",
      overview: "Guudmarka Barnaamijka",
      overviewText1:
        "Barnaamijka Shabakadda Badbaadada Wax Soo Saarka (PSNP-5) waa barnaamijka ugu weyn ee ilaalinta bulshada ee Itoobiya oo loogu talagalay in lagu hagaajiyo amniga cuntada iyo adkeysiga qoysaska nugul ee miyiga. Barnaamijku wuxuu bixiyaa lacag iyo cunto loo wareejiyo qoysaska aan cuntada heli karin iyada oo beddelkeeda ay ka qaybqaadanayaan hawlaha shaqada dadweynaha ee dhisaya hantida bulshada.",
      overviewText2:
        "Gobolka Soomaalida, PSNP-5 wuxuu diiradda saaraa dhisidda adkeysiga ka soo horjeeda abaaraha, hagaajinta wax soo saarka beeraha, iyo xoojinta fursadaha nololeed ee bulshooyinka xoolo-dhaqatada iyo beeraha-xoolo-dhaqatada. Barnaamijka waxaa fuliya Xafiiska Beeraha ee Gobolka Soomaalida oo kaashanaya Wasaaradda Beeraha iyo lammaanayaasha caalamiga ah.",
      components: "Qaybaha",
      achievements: "Guulaha",
      programDuration: "Muddada Barnaamijka",
      durationValue: "2021 - 2025",
      coverageArea: "Aagga Daboolka",
      coverageValue: "Dhammaan degmooyinka Gobolka Soomaalida",
      beneficiaries: "Ka-faa'iideystayaasha",
      beneficiariesValue: "In ka badan 300,000 oo qoys oo Gobolka Soomaalida ah",
      fundingPartners: "Lammaanayaasha Maalgelinta",
      fundingValue: "Bangiga Adduunka, USAID, DFID, EU, iyo Dowladda Itoobiya",
      component1Title: "Wareejinta Shabakadda Badbaadada",
      component1Text:
        "Waxay bixisaa lacag ama cunto la saadaalin karo oo loo wareejiyo qoysaska aan cuntada heli karin. Wareejinada waxaa la bixiyaa iyada oo beddelkeeda ay ka qaybqaadanayaan shaqooyinka dadweynaha ee xubnaha jirka leh, halka taageerada tooska ah la siiyo qoysaska xaddidan ee shaqada.",
      component2Title: "Horumarinta Nololeed",
      component2Text:
        "Waxay taageertaa qoysaska si ay u kordhiyaan oo ay u kala duwanaadaan dakhligooda iyada oo loo marayo gargaar farsamo, tababar, iyo helitaanka adeegyada maaliyadeed. Qaybtan waxaa ka mid ah taageerada beeraha cimilada-caqliga leh, horumarinta xoolaha, iyo hawlaha dakhli soo saarka ee aan beeraha ahayn.",
      component3Title: "Adkeysiga Cimilada",
      component3Text:
        "Waxay diiradda saartaa dhisidda hantida bulshada ee xoojisa adkeysiga dhibaatooyinka cimilada, sida dhismayaasha ilaalinta ciidda iyo biyaha, qorshayaasha waraabka yar, iyo faragelinta maaraynta dhul-daaqsimeedka.",
      component4Title: "Xoojinta Hay'adaha",
      component4Text:
        "Waxay xoojisaa awoodda hay'adaha dowladda ee heerarka gobolka, degmada, iyo tuulada si ay si wax ku ool ah u fuliyaan barnaamijka oo ay uga jawaabaan xaaladaha degdegga ah.",
      achievementsTitle: "Guulaha Muhiimka ah",
      achievementsText:
        "Tan iyo hirgelintii Gobolka Soomaalida, PSNP-5 waxay gaadhay natiijooyin muhiim ah oo lagu hagaajinayo amniga cuntada iyo dhisidda adkeysiga.",
      householdImpact: "Saamaynta Qoyska",
      householdImpact1: "Waxay hagaajisay amniga cuntada in ka badan 300,000 oo qoys",
      householdImpact2: "Waxay yaraynaysaa xeeladaha la qabsiga xun inta lagu jiro xilliga abaaraha ilaa 40%",
      householdImpact3: "Waxay kordhisay lahaanshaha hantida qoyska ilaa 25% ka-faa'iideystayaasha dhexdooda",
      householdImpact4: "Waxay xoojisay kala duwanaanshaha cuntada ee dumarka iyo carruurta",
      communityAssets: "Hantida Bulshada",
      communityAssets1: "Waxay dhisay 150 qorshe oo waraab yar",
      communityAssets2: "Waxay dib u soo celisay in ka badan 10,000 oo hektar oo dhul hoos u dhacay",
      communityAssets3: "Waxay horumarisay 200 oo dhisme oo biyaha lagu keydiyo",
      communityAssets4: "Waxay hagaajisay 500 kiiloomitir oo waddooyin miyiga ah",
      institutionalDev: "Horumarinta Hay'adaha",
      institutionalDev1: "Waxay xoojisay nidaamyada digniinta hore ee dhammaan degmooyinka",
      institutionalDev2: "Waxay xoojisay awoodda 500 oo shaqaale fidinta beeraha ah",
      institutionalDev3: "Waxay hagaajisay isku dubaridka ka dhexeeya faragelinta bani'aadantinimada iyo horumarinta",
      institutionalDev4:
        "Waxay samaysay diiwaanka dhijitaalka ah ee ka-faa'iideystayaasha iyo nidaamyada lacag bixinta",
      contactInfo: "Macluumaadka Xiriirka",
      programCoordinator: "Isku-duwaha Barnaamijka",
      coordinatorName: "Axmed Xasan",
      email: "Iimaylka",
      emailValue: "psnp5@srs-banr.gov.et",
      phone: "Telefoonka",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Nala Soo Xiriir",
      relatedResources: "Ilaha La Xiriira",
      resource1: "Buugga Hirgelinta PSNP-5",
      resource2: "Warbixinta Horumarka Sanadlaha ah 2024",
      resource3: "Hagaha Ka-faa'iideystaha PSNP-5",
      viewAllResources: "Arag Dhammaan Ilaha",
      otherPrograms: "Barnaamijyada Kale",
    },
    am: {
      title: "ምርታማ ሴፍቲ ኔት ፕሮግራም (PSNP-5)",
      breadcrumb: "ፕሮግራሞች እና ፕሮጀክቶች",
      overview: "የፕሮግራሙ አጠቃላይ እይታ",
      overviewText1:
        "ምርታማ ሴፍቲ ኔት ፕሮግራም (PSNP-5) የኢትዮጵያ ዋነኛ የማህበራዊ ጥበቃ ፕሮግራም ሲሆን በገጠር አካባቢዎች ለሚገኙ ተጋላጭ ቤተሰቦች የምግብ ዋስትናን እና የመቋቋም አቅምን ለማሻሻል ያለመ ነው። ፕሮግራሙ ለአካባቢ ማህበረሰብ ንብረቶችን ለሚገነቡ የህዝብ ሥራዎች እንቅስቃሴዎች ተሳትፎአቸውን በመለወጥ ለስር የሰደደ የምግብ ዋስትና እጥረት ላለባቸው ቤተሰቦች የገንዘብ እና የምግብ ሽግግሮችን ይሰጣል።",
      overviewText2:
        "በሶማሌ ክልል፣ PSNP-5 በድርቅ ላይ የመቋቋም አቅምን በመገንባት፣ የግብርና ምርታማነትን በማሻሻል እና ለአርብቶ አደሮች እና ለግብርና-አርብቶ አደር ማህበረሰቦች የኑሮ ዕድሎችን በማሻሻል ላይ ያተኩራል። ፕሮግራሙ በሶማሌ ክልል የግብርና ቢሮ በግብርና ሚኒስቴር እና በዓለም አቀፍ አጋሮች ትብብር ይተገበራል።",
      components: "ክፍሎች",
      achievements: "ውጤቶች",
      programDuration: "የፕሮግራም ጊዜ",
      durationValue: "2021 - 2025",
      coverageArea: "የሽፋን አካባቢ",
      coverageValue: "የሶማሌ ክልል ሁሉም ዞኖች",
      beneficiaries: "ተጠቃሚዎች",
      beneficiariesValue: "በሶማሌ ክልል ከ300,000 በላይ ቤተሰቦች",
      fundingPartners: "የገንዘብ አጋሮች",
      fundingValue: "የዓለም ባንክ፣ USAID፣ DFID፣ EU እና የኢትዮጵያ መንግስት",
      component1Title: "የሴፍቲ ኔት ሽግግሮች",
      component1Text:
        "ለስር የሰደደ የምግብ ዋስትና እጥረት ላለባቸው ቤተሰቦች ሊተነበይ የሚችል የገንዘብ ወይም የምግብ ሽግግሮችን ይሰጣል። ሽግግሮቹ ለአካል ብቃት ላላቸው አባላት በህዝብ ሥራዎች ተሳትፎ ምትክ የሚሰጡ ሲሆን፣ ለሥራ ውስን ለሆኑ ቤተሰቦች ደግሞ ቀጥታ ድጋፍ ይሰጣል።",
      component2Title: "የኑሮ ልማት",
      component2Text:
        "ቤተሰቦች በቴክኒካዊ ድጋፍ፣ በሥልጠና እና በፋይናንስ አገልግሎቶች ተደራሽነት አማካኝነት ገቢያቸውን እንዲጨምሩ እና እንዲያዳብሩ ይደግፋል። ይህ ክፍል የአየር ንብረት-ብልህ ግብርና፣ የእንስሳት ልማት እና ከእርሻ ውጪ ገቢ የሚያስገኙ እንቅስቃሴዎችን ድጋፍ ያካትታል።",
      component3Title: "የአየር ንብረት መቋቋም",
      component3Text:
        "የአፈር እና የውሃ ጥበቃ መዋቅሮች፣ አነስተኛ የመስኖ ስርዓቶች እና የግጦሽ መሬት አስተዳደር ጣልቃ ገብነቶች ያሉ ለአየር ንብረት ድንገተኛ ለውጦች መቋቋም አቅምን የሚያሻሽሉ የማህበረሰብ ንብረቶችን መገንባት ላይ ያተኩራል።",
      component4Title: "ተቋማዊ ማጠናከር",
      component4Text:
        "በክልል፣ በወረዳ እና በቀበሌ ደረጃ ያሉ የመንግስት ተቋማት ፕሮግራሙን በውጤታማነት ለመተግበር እና ለአስቸኳይ ሁኔታዎች ምላሽ ለመስጠት ያላቸውን አቅም ያሻሽላል።",
      achievementsTitle: "ዋና ዋና ውጤቶች",
      achievementsText: "በሶማሌ ክልል ከተተገበረበት ጊዜ ጀምሮ፣ PSNP-5 የምግብ ዋስትናን በማሻሻል እና የመቋቋም አቅምን በመገንባት ረገድ ጉልህ ውጤቶችን አስመዝግቧል።",
      householdImpact: "የቤተሰብ ተጽዕኖ",
      householdImpact1: "ከ300,000 በላይ ቤተሰቦች የምግብ ዋስትና ተሻሽሏል",
      householdImpact2: "በድርቅ ወቅት አሉታዊ የመቋቋሚያ ስልቶች በ40% ቀንሷል",
      householdImpact3: "በተጠቃሚዎች መካከል የቤተሰብ ንብረት ባለቤትነት በ25% ጨምሯል",
      householdImpact4: "ለሴቶች እና ለህጻናት የምግብ ዓይነት ብዝሃነት ተሻሽሏል",
      communityAssets: "የማህበረሰብ ንብረቶች",
      communityAssets1: "150 አነስተኛ የመስኖ ስርዓቶች ተገንብተዋል",
      communityAssets2: "ከ10,000 ሄክታር በላይ የተራቆተ መሬት ተልምቷል",
      communityAssets3: "200 የውሃ ማሰባሰቢያ መዋቅሮች ተገንብተዋል",
      communityAssets4: "500 ኪሎሜትር የገጠር መንገዶች ተሻሽለዋል",
      institutionalDev: "ተቋማዊ ልማት",
      institutionalDev1: "በሁሉም ወረዳዎች የቀድሞ ማስጠንቀቂያ ስርዓቶች ተጠናክረዋል",
      institutionalDev2: "የ500 የግብርና ኤክስቴንሽን ሰራተኞች አቅም ተሻሽሏል",
      institutionalDev3: "በሰብዓዊ እና በልማት ጣልቃ ገብነቶች መካከል ያለው ቅንጅት ተሻሽሏል",
      institutionalDev4: "የዲጂታል ተጠቃሚዎች መዝገብ እና የክፍያ ስርዓቶች ተቋቁመዋል",
      contactInfo: "የመገኛ መረጃ",
      programCoordinator: "የፕሮግራም አስተባባሪ",
      coordinatorName: "አህመድ ሃሰን",
      email: "ኢሜይል",
      emailValue: "psnp5@srs-banr.gov.et",
      phone: "ስልክ",
      phoneValue: "+251-XXX-XXX",
      contactUs: "ያግኙን",
      relatedResources: "ተዛማጅ ሀብቶች",
      resource1: "የPSNP-5 አተገባበር መመሪያ",
      resource2: "የ2024 ዓመታዊ የሂደት ሪፖርት",
      resource3: "የPSNP-5 ተጠቃሚ መመሪያ",
      viewAllResources: "ሁሉንም ሀብቶች ይመልከቱ",
      otherPrograms: "ሌሎች ፕሮግራሞች",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground">
          <Link href="/projects" className="text-turquoise hover:underline">
            {currentTranslations.breadcrumb}
          </Link>{" "}
          / PSNP-5
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <Image
              src="/placeholder.svg?height=400&width=800&text=PSNP-5+Program"
              alt="PSNP-5 Program"
              fill
              className="object-cover"
            />
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">{currentTranslations.overview}</TabsTrigger>
              <TabsTrigger value="components">{currentTranslations.components}</TabsTrigger>
              <TabsTrigger value="achievements">{currentTranslations.achievements}</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6 space-y-4">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.overview}</h2>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText1}</p>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText2}</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-turquoise" />
                      {currentTranslations.programDuration}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.durationValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-turquoise" />
                      {currentTranslations.coverageArea}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.coverageValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.beneficiaries}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.beneficiariesValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.fundingPartners}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.fundingValue}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="components" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.components}</h2>
                <p className="mt-2 text-muted-foreground">
                  PSNP-5 consists of several integrated components designed to address food insecurity and build
                  resilience.
                </p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component1Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component1Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component2Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component2Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component3Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component3Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component4Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component4Text}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.achievementsTitle}</h2>
                <p className="mt-2 text-muted-foreground">{currentTranslations.achievementsText}</p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.householdImpact}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.householdImpact1}</li>
                      <li>{currentTranslations.householdImpact2}</li>
                      <li>{currentTranslations.householdImpact3}</li>
                      <li>{currentTranslations.householdImpact4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.communityAssets}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.communityAssets1}</li>
                      <li>{currentTranslations.communityAssets2}</li>
                      <li>{currentTranslations.communityAssets3}</li>
                      <li>{currentTranslations.communityAssets4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-turquoise" />
                      {currentTranslations.institutionalDev}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.institutionalDev1}</li>
                      <li>{currentTranslations.institutionalDev2}</li>
                      <li>{currentTranslations.institutionalDev3}</li>
                      <li>{currentTranslations.institutionalDev4}</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.contactInfo}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium">{currentTranslations.programCoordinator}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.coordinatorName}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.email}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.emailValue}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.phone}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.phoneValue}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/contact">{currentTranslations.contactUs}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.relatedResources}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource1}</p>
                  <p className="text-xs text-muted-foreground">PDF • 2.5 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource2}</p>
                  <p className="text-xs text-muted-foreground">PDF • 1.8 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource3}</p>
                  <p className="text-xs text-muted-foreground">PDF • 1.2 MB</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/resources">{currentTranslations.viewAllResources}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.otherPrograms}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/projects/drdip-ii" className="block text-sm text-turquoise hover:underline">
                DRDIP-II
              </Link>
              <Link href="/projects/pact" className="block text-sm text-turquoise hover:underline">
                PACT
              </Link>
              <Link href="/projects/crew" className="block text-sm text-turquoise hover:underline">
                CREW
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

