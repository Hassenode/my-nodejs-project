"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, MapPin, Users, Target, Clock, FileText } from "lucide-react"

export default function DRDIPPage() {
  const { t, language } = useTranslation()

  // Translation keys for DRDIP-II page
  const translations = {
    en: {
      title: "Development Response to Displacement Impacts Project (DRDIP-II)",
      breadcrumb: "Programs & Projects",
      overview: "Program Overview",
      overviewText1:
        "The Development Response to Displacement Impacts Project (DRDIP-II) is a regional initiative aimed at addressing the impacts of forced displacement on host communities in Ethiopia, particularly in the Somali Region. The project focuses on improving access to basic social services, expanding economic opportunities, and enhancing environmental management for communities hosting refugees.",
      overviewText2:
        "In the Somali Region, DRDIP-II works in woredas hosting refugees from Somalia, addressing the increased pressure on already scarce resources and limited infrastructure. The program is implemented by the Somali Regional State Agricultural Bureau in collaboration with the World Bank and other partners.",
      components: "Components",
      achievements: "Achievements",
      programDuration: "Program Duration",
      durationValue: "2022 - 2027",
      coverageArea: "Coverage Area",
      coverageValue: "Refugee-hosting woredas in Fafan, Jarar, and Doolo zones",
      beneficiaries: "Beneficiaries",
      beneficiariesValue: "Over 200,000 people in host communities",
      fundingPartners: "Funding Partners",
      fundingValue: "World Bank, Government of Ethiopia",
      component1Title: "Social and Economic Services and Infrastructure",
      component1Text:
        "Improves access to basic social services and economic infrastructure by constructing or rehabilitating schools, health facilities, water supply systems, and market infrastructure in host communities.",
      component2Title: "Sustainable Environmental Management",
      component2Text:
        "Addresses environmental degradation in areas hosting refugees through sustainable land management, rehabilitation of degraded lands, and promotion of alternative energy sources to reduce deforestation.",
      component3Title: "Livelihoods Program",
      component3Text:
        "Enhances traditional and non-traditional livelihoods through skills development, access to finance, and market linkages for both host communities and refugees, promoting economic integration and self-reliance.",
      component4Title: "Project Management and Institutional Support",
      component4Text:
        "Strengthens the capacity of regional and local institutions to plan, implement, and monitor displacement-responsive development interventions, ensuring sustainability beyond the project period.",
      achievementsTitle: "Key Achievements",
      achievementsText:
        "Since its implementation in the Somali Region, DRDIP-II has achieved significant results in improving conditions for host communities.",
      socialInfrastructure: "Social Infrastructure",
      socialInfrastructure1: "Constructed 15 new schools and rehabilitated 20 existing schools",
      socialInfrastructure2: "Built 10 health centers and upgraded 5 existing health facilities",
      socialInfrastructure3: "Developed 30 water supply systems benefiting over 100,000 people",
      socialInfrastructure4: "Constructed 5 market centers to enhance trade between host communities and refugees",
      environmentalManagement: "Environmental Management",
      environmentalManagement1: "Rehabilitated 5,000 hectares of degraded land",
      environmentalManagement2: "Distributed 10,000 improved cookstoves to reduce firewood consumption",
      environmentalManagement3: "Established 20 community tree nurseries",
      environmentalManagement4: "Installed 500 solar lighting systems in public facilities",
      livelihoodSupport: "Livelihood Support",
      livelihoodSupport1: "Provided vocational training to 5,000 youth from host communities",
      livelihoodSupport2: "Supported 300 community-based savings and loan groups",
      livelihoodSupport3: "Established 50 agricultural and livestock producer groups",
      livelihoodSupport4: "Provided startup grants to 1,000 micro-enterprises",
      contactInfo: "Contact Information",
      programCoordinator: "Program Coordinator",
      coordinatorName: "Fatima Hussein",
      email: "Email",
      emailValue: "drdip@srs-banr.gov.et",
      phone: "Phone",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Contact Us",
      relatedResources: "Related Resources",
      resource1: "DRDIP-II Project Document",
      resource2: "Annual Progress Report 2024",
      resource3: "Community Implementation Guide",
      viewAllResources: "View All Resources",
      otherPrograms: "Other Programs",
    },
    so: {
      title: "Mashruuca Jawaabta Horumarinta ee Saamaynta Barakaca (DRDIP-II)",
      breadcrumb: "Barnaamijyada & Mashaariicda",
      overview: "Guudmarka Barnaamijka",
      overviewText1:
        "Mashruuca Jawaabta Horumarinta ee Saamaynta Barakaca (DRDIP-II) waa hindise goboleed oo loogu talagalay in lagu wajaho saamaynta barakaca qasabka ah ee bulshooyinka martigeliya ee Itoobiya, gaar ahaan Gobolka Soomaalida. Mashruucu wuxuu diiradda saaraa hagaajinta helitaanka adeegyada aasaasiga ah ee bulshada, ballaarinta fursadaha dhaqaale, iyo xoojinta maaraynta deegaanka ee bulshooyinka martigeliya qaxootiga.",
      overviewText2:
        "Gobolka Soomaalida, DRDIP-II wuxuu ka shaqeeyaa degmooyinka martigeliya qaxootiga ka yimid Soomaaliya, wuxuuna wax ka qabtaa cadaadiska sii kordhaya ee kheyraadka horay u yaraa iyo kaabayaasha xaddidan. Barnaamijka waxaa fuliya Xafiiska Beeraha ee Gobolka Soomaalida oo kaashanaya Bangiga Adduunka iyo lammaanayaal kale.",
      components: "Qaybaha",
      achievements: "Guulaha",
      programDuration: "Muddada Barnaamijka",
      durationValue: "2022 - 2027",
      coverageArea: "Aagga Daboolka",
      coverageValue: "Degmooyinka martigeliya qaxootiga ee degmooyinka Fafan, Jarar, iyo Doolo",
      beneficiaries: "Ka-faa'iideystayaasha",
      beneficiariesValue: "In ka badan 200,000 oo qof oo ka tirsan bulshooyinka martigeliya",
      fundingPartners: "Lammaanayaasha Maalgelinta",
      fundingValue: "Bangiga Adduunka, Dowladda Itoobiya",
      component1Title: "Adeegyada Bulshada iyo Dhaqaalaha iyo Kaabayaasha",
      component1Text:
        "Waxay hagaajisaa helitaanka adeegyada aasaasiga ah ee bulshada iyo kaabayaasha dhaqaalaha iyada oo dhisaysa ama dib u soo celisa dugsiyada, xarumaha caafimaadka, nidaamyada biyaha, iyo kaabayaasha suuqa ee bulshooyinka martigeliya.",
      component2Title: "Maaraynta Deegaanka ee Waara",
      component2Text:
        "Waxay wax ka qabataa hoos u dhaca deegaanka ee aagagga martigeliya qaxootiga iyada oo loo marayo maaraynta dhulka ee waara, dib u soo celinta dhulalka hoos u dhacay, iyo horumarinta ilaha tamarta ee kale si loo yareeyo jarista geedaha.",
      component3Title: "Barnaamijka Nololeed",
      component3Text:
        "Waxay xoojisaa hab-nololeedyada hore iyo kuwa aan hore u ahayn iyada oo loo marayo horumarinta xirfadaha, helitaanka maalgelin, iyo xiriirka suuqa ee labadaba bulshooyinka martigeliya iyo qaxootiga, iyada oo horumarinaysa isdhexgalka dhaqaale iyo isku filnaanta.",
      component4Title: "Maaraynta Mashruuca iyo Taageerada Hay'adaha",
      component4Text:
        "Waxay xoojisaa awoodda hay'adaha gobolka iyo kuwa maxalliga ah si ay u qorsheeyaan, u fuliyaan, oo ay ula socdaan faragelinta horumarinta ee ka jawaabta barakaca, iyada oo hubinaysa waara ka dib muddada mashruuca.",
      achievementsTitle: "Guulaha Muhiimka ah",
      achievementsText:
        "Tan iyo hirgelintii Gobolka Soomaalida, DRDIP-II waxay gaadhay natiijooyin muhiim ah oo lagu hagaajinayo xaaladaha bulshooyinka martigeliya.",
      socialInfrastructure: "Kaabayaasha Bulshada",
      socialInfrastructure1: "Waxay dhisay 15 dugsi oo cusub waxayna dib u soo celisay 20 dugsi oo jira",
      socialInfrastructure2: "Waxay dhisay 10 xarun caafimaad waxayna casriyeysay 5 xarumo caafimaad oo jira",
      socialInfrastructure3:
        "Waxay horumarisay 30 nidaam oo biyaha ah oo ka faa'iideysanaya in ka badan 100,000 oo qof",
      socialInfrastructure4:
        "Waxay dhisay 5 xarun suuq ah si loo xoojiyo ganacsiga u dhexeeya bulshooyinka martigeliya iyo qaxootiga",
      environmentalManagement: "Maaraynta Deegaanka",
      environmentalManagement1: "Waxay dib u soo celisay 5,000 hektar oo dhul hoos u dhacay",
      environmentalManagement2: "Waxay qaybisay 10,000 foorno la hagaajiyay si loo yareeyo isticmaalka xaabada",
      environmentalManagement3: "Waxay samaysay 20 beer-xanaaneed oo geed oo bulshada ah",
      environmentalManagement4: "Waxay rakibtay 500 nidaam oo iftiinka qoraxda ah oo ku yaalla xarumaha dadweynaha",
      livelihoodSupport: "Taageerada Nololeed",
      livelihoodSupport1:
        "Waxay siisay tababar xirfadeed 5,000 oo dhallinyaro ah oo ka tirsan bulshooyinka martigeliya",
      livelihoodSupport2: "Waxay taageertay 300 kooxood oo ku salaysan bulshada oo keydinta iyo amaahda ah",
      livelihoodSupport3: "Waxay samaysay 50 kooxood oo wax soo saara beeraha iyo xoolaha",
      livelihoodSupport4: "Waxay siisay deeqo bilowga ah 1,000 ganacsi yar-yar",
      contactInfo: "Macluumaadka Xiriirka",
      programCoordinator: "Isku-duwaha Barnaamijka",
      coordinatorName: "Faaduma Xuseen",
      email: "Iimaylka",
      emailValue: "drdip@srs-banr.gov.et",
      phone: "Telefoonka",
      phoneValue: "+251-XXX-XXX",
      contactUs: "Nala Soo Xiriir",
      relatedResources: "Ilaha La Xiriira",
      resource1: "Dukumentiga Mashruuca DRDIP-II",
      resource2: "Warbixinta Horumarka Sanadlaha ah 2024",
      resource3: "Hagaha Hirgelinta Bulshada",
      viewAllResources: "Arag Dhammaan Ilaha",
      otherPrograms: "Barnaamijyada Kale",
    },
    am: {
      title: "የተፈናቃዮች ተጽዕኖ የልማት ምላሽ ፕሮጀክት (DRDIP-II)",
      breadcrumb: "ፕሮግራሞች እና ፕሮጀክቶች",
      overview: "የፕሮግራሙ አጠቃላይ እይታ",
      overviewText1:
        "የተፈናቃዮች ተጽዕኖ የልማት ምላሽ ፕሮጀክት (DRDIP-II) በኢትዮጵያ፣ በተለይም በሶማሌ ክልል፣ በአስገድዶ መፈናቀል ምክንያት በአስተናጋጅ ማህበረሰቦች ላይ የሚደርሱ ተጽዕኖዎችን ለመቅረፍ የሚያለመ የክልል ተነሳሽነት ነው። ፕሮጀክቱ ለስደተኞችን ለሚያስተናግዱ ማህበረሰቦች መሰረታዊ ማህበራዊ አገልግሎቶችን ተደራሽነት ማሻሻል፣ የኢኮኖሚ እድሎችን ማስፋት እና የአካባቢ አስተዳደርን ማሻሻል ላይ ያተኩራል።",
      overviewText2:
        "በሶማሌ ክልል፣ DRDIP-II ከሶማሊያ የመጡ ስደተኞችን በሚያስተናግዱ ወረዳዎች ውስጥ ይሰራል፣ በቀድሞው አነስተኛ ሀብቶች እና ውስን መሰረተ ልማት ላይ የጨመረውን ጫና ይቀርፋል። ፕሮግራሙ በሶማሌ ክልል የግብርና ቢሮ በዓለም ባንክ እና በሌሎች አጋሮች ትብብር ይተገበራል።",
      components: "ክፍሎች",
      achievements: "ውጤቶች",
      programDuration: "የፕሮግራም ጊዜ",
      durationValue: "2022 - 2027",
      coverageArea: "የሽፋን አካባቢ",
      coverageValue: "በፋፋን፣ ጃራር እና ዶሎ ዞኖች ውስጥ ስደተኞችን የሚያስተናግዱ ወረዳዎች",
      beneficiaries: "ተጠቃሚዎች",
      beneficiariesValue: "በአስተናጋጅ ማህበረሰቦች ውስጥ ከ200,000 በላይ ሰዎች",
      fundingPartners: "የገንዘብ አጋሮች",
      fundingValue: "የዓለም ባንክ፣ የኢትዮጵያ መንግስት",
      component1Title: "ማህበራዊ እና ኢኮኖሚያዊ አገልግሎቶች እና መሰረተ ልማት",
      component1Text:
        "በአስተናጋጅ ማህበረሰቦች ውስጥ ትምህርት ቤቶችን፣ የጤና ተቋማትን፣ የውሃ አቅርቦት ስርዓቶችን እና የገበያ መሰረተ ልማትን በመገንባት ወይም በማደስ መሰረታዊ ማህበራዊ አገልግሎቶች እና የኢኮኖሚ መሰረተ ልማት ተደራሽነትን ያሻሽላል።",
      component2Title: "ዘላቂ የአካባቢ አስተዳደር",
      component2Text:
        "በዘላቂ የመሬት አስተዳደር፣ የተራቆቱ መሬቶችን በማደስ እና የደን መጨፍጨፍን ለመቀነስ አማራጭ የኃይል ምንጮችን በማስፋፋት አማካኝነት ስደተኞችን በሚያስተናግዱ አካባቢዎች ውስጥ የአካባቢ መራቆትን ይቀርፋል።",
      component3Title: "የኑሮ ፕሮግራም",
      component3Text:
        "ለአስተናጋጅ ማህበረሰቦች እና ለስደተኞች ሁለቱም የክህሎት ልማት፣ የፋይናንስ ተደራሽነት እና የገበያ ግንኙነቶች አማካኝነት ባህላዊ እና ባህላዊ ያልሆኑ የኑሮ መንገዶችን ያሻሽላል፣ የኢኮኖሚ ውህደት እና ራስን መቻልን ያበረታታል።",
      component4Title: "የፕሮጀክት አስተዳደር እና ተቋማዊ ድጋፍ",
      component4Text:
        "ከፕሮጀክቱ ጊዜ በኋላ ዘላቂነትን በማረጋገጥ፣ የክልል እና የአካባቢ ተቋማት የተፈናቃዮችን ምላሽ የሚሰጡ የልማት ጣልቃ ገብነቶችን ለማቀድ፣ ለመተግበር እና ለመከታተል ያላቸውን አቅም ያጠናክራል።",
      achievementsTitle: "ዋና ዋና ውጤቶች",
      achievementsText: "በሶማሌ ክልል ከተተገበረበት ጊዜ ጀምሮ፣ DRDIP-II ለአስተናጋጅ ማህበረሰቦች ሁኔታዎችን በማሻሻል ረገድ ጉልህ ውጤቶችን አስመዝግቧል።",
      socialInfrastructure: "ማህበራዊ መሰረተ ልማት",
      socialInfrastructure1: "15 አዳዲስ ትምህርት ቤቶችን ገንብቷል እና 20 ነባር ትምህርት ቤቶችን አድሷል",
      socialInfrastructure2: "10 የጤና ጣቢያዎችን ገንብቷል እና 5 ነባር የጤና ተቋማትን አሻሽሏል",
      socialInfrastructure3: "ከ100,000 በላይ ሰዎችን የሚጠቅሙ 30 የውሃ አቅርቦት ስርዓቶችን አዳብሯል",
      socialInfrastructure4: "በአስተናጋጅ ማህበረሰቦች እና በስደተኞች መካከል ንግድን ለማሻሻል 5 የገበያ ማዕከላትን ገንብቷል",
      environmentalManagement: "የአካባቢ አስተዳደር",
      environmentalManagement1: "5,000 ሄክታር የተራቆተ መሬት አድሷል",
      environmentalManagement2: "የእንጨት ፍጆታን ለመቀነስ 10,000 የተሻሻሉ ምድጃዎችን አከፋፍሏል",
      environmentalManagement3: "20 የማህበረሰብ የዛፍ መሸጫዎችን አቋቁሟል",
      environmentalManagement4: "በህዝብ ተቋማት ውስጥ 500 የፀሐይ ብርሃን ስርዓቶችን ተክሏል",
      livelihoodSupport: "የኑሮ ድጋፍ",
      livelihoodSupport1: "ከአስተናጋጅ ማህበረሰቦች ለ5,000 ወጣቶች የሙያ ስልጠና ሰጥቷል",
      livelihoodSupport2: "300 በማህበረሰብ ላይ የተመሰረቱ የቁጠባ እና የብድር ቡድኖችን ደግፏል",
      livelihoodSupport3: "50 የግብርና እና የእንስሳት አምራች ቡድኖችን አቋቁሟል",
      livelihoodSupport4: "ለ1,000 ጥቃቅን ተቋማት የመነሻ ድጋፍ ሰጥቷል",
      contactInfo: "የመገኛ መረጃ",
      programCoordinator: "የፕሮግራም አስተባባሪ",
      coordinatorName: "ፋጢማ ሁሴን",
      email: "ኢሜይል",
      emailValue: "drdip@srs-banr.gov.et",
      phone: "ስልክ",
      phoneValue: "+251-XXX-XXX",
      contactUs: "ያግኙን",
      relatedResources: "ተዛማጅ ሀብቶች",
      resource1: "የDRDIP-II ፕሮጀክት ሰነድ",
      resource2: "የ2024 ዓመታዊ የሂደት ሪፖርት",
      resource3: "የማህበረሰብ አተገባበር መመሪያ",
      viewAllResources: "ሁሉንም ሀብቶች ይመልከቱ",
      otherPrograms: "ሌሎች ፕሮግራሞች",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground">
          <Link href="/projects" className="text-turquoise hover:underline">
            {currentTranslations.breadcrumb}
          </Link>{" "}
          / DRDIP-II
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-3">
        <div className="md:col-span-2">
          <div className="relative mb-8 h-64 w-full overflow-hidden rounded-lg md:h-80">
            <div className="relative flex justify-center items-center">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/DRDIP%20II%20Logo-Rv4d12vOQ4yuheyRMG6R8dmuIaZGV2.png"
                alt="DRDIP-II Program Logo"
                width={400}
                height={400}
                className="object-contain"
                priority
              />
            </div>
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">{currentTranslations.overview}</TabsTrigger>
              <TabsTrigger value="components">{currentTranslations.components}</TabsTrigger>
              <TabsTrigger value="achievements">{currentTranslations.achievements}</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6 space-y-4">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.overview}</h2>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText1}</p>
                <p className="mt-4 text-muted-foreground">{currentTranslations.overviewText2}</p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-turquoise" />
                      {currentTranslations.programDuration}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.durationValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-turquoise" />
                      {currentTranslations.coverageArea}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.coverageValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.beneficiaries}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.beneficiariesValue}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.fundingPartners}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{currentTranslations.fundingValue}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="components" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.components}</h2>
                <p className="mt-2 text-muted-foreground">
                  DRDIP-II consists of several integrated components designed to address the impacts of displacement on
                  host communities.
                </p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component1Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component1Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component2Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component2Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component3Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component3Text}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{currentTranslations.component4Title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{currentTranslations.component4Text}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="achievements" className="mt-6 space-y-6">
              <div>
                <h2 className="text-2xl font-bold">{currentTranslations.achievementsTitle}</h2>
                <p className="mt-2 text-muted-foreground">{currentTranslations.achievementsText}</p>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-turquoise" />
                      {currentTranslations.socialInfrastructure}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.socialInfrastructure1}</li>
                      <li>{currentTranslations.socialInfrastructure2}</li>
                      <li>{currentTranslations.socialInfrastructure3}</li>
                      <li>{currentTranslations.socialInfrastructure4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-turquoise" />
                      {currentTranslations.environmentalManagement}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.environmentalManagement1}</li>
                      <li>{currentTranslations.environmentalManagement2}</li>
                      <li>{currentTranslations.environmentalManagement3}</li>
                      <li>{currentTranslations.environmentalManagement4}</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-turquoise" />
                      {currentTranslations.livelihoodSupport}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                      <li>{currentTranslations.livelihoodSupport1}</li>
                      <li>{currentTranslations.livelihoodSupport2}</li>
                      <li>{currentTranslations.livelihoodSupport3}</li>
                      <li>{currentTranslations.livelihoodSupport4}</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.contactInfo}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-medium">{currentTranslations.programCoordinator}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.coordinatorName}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.email}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.emailValue}</p>
              </div>
              <div>
                <h3 className="font-medium">{currentTranslations.phone}</h3>
                <p className="text-sm text-muted-foreground">{currentTranslations.phoneValue}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/contact">{currentTranslations.contactUs}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.relatedResources}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource1}</p>
                  <p className="text-xs text-muted-foreground">PDF • 3.2 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource2}</p>
                  <p className="text-xs text-muted-foreground">PDF • 2.1 MB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="rounded-full bg-turquoise/10 p-2">
                  <FileText className="h-4 w-4 text-turquoise" />
                </div>
                <div>
                  <p className="text-sm font-medium">{currentTranslations.resource3}</p>
                  <p className="text-xs text-muted-foreground">PDF • 1.5 MB</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/resources">{currentTranslations.viewAllResources}</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{currentTranslations.otherPrograms}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/projects/psnp-5" className="block text-sm text-turquoise hover:underline">
                PSNP-5 Program
              </Link>
              <Link href="/projects/pact" className="block text-sm text-turquoise hover:underline">
                PACT
              </Link>
              <Link href="/projects/crew" className="block text-sm text-turquoise hover:underline">
                CREW
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

