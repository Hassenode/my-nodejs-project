"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

type Project = {
  id: number
  title: string
  description: string
  category: "ongoing" | "completed" | "partnerships"
  location: string
  image: string
}

const projects: Project[] = [
  {
    id: 1,
    title: "Gode Zone Irrigation Expansion",
    description:
      "Expanding irrigation infrastructure to support 500 farmers in the Gode Zone with sustainable water access.",
    category: "ongoing",
    location: "Gode Zone",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    id: 3,
    title: "Drought-Resistant Crop Introduction",
    description:
      "Introduction of drought-resistant crop varieties to 200 farmers to improve resilience to climate change.",
    category: "ongoing",
    location: "Sitti Zone",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    id: 4,
    title: "Milk Processing Facility",
    description: "Establishment of a community milk processing facility to support dairy value chain development.",
    category: "completed",
    location: "Jijiga",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    id: 5,
    title: "Farmer Training Centers",
    description:
      "Construction and equipping of 5 farmer training centers to provide continuous education on modern farming techniques.",
    category: "completed",
    location: "Multiple Zones",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    id: 6,
    title: "FAO Pastoral Livelihoods Initiative",
    description:
      "Partnership with FAO to strengthen pastoral livelihoods through improved rangeland management and market access.",
    category: "partnerships",
    location: "Regional",
    image: "/placeholder.svg?height=300&width=500",
  },
  {
    id: 7,
    title: "World Bank Climate Resilience Project",
    description: "Collaboration with the World Bank on climate resilience initiatives for agricultural communities.",
    category: "partnerships",
    location: "Regional",
    image: "/placeholder.svg?height=300&width=500",
  },
]

export default function ProjectsPage() {
  const [filter, setFilter] = useState<"all" | "ongoing" | "completed" | "partnerships">("all")

  const filteredProjects = filter === "all" ? projects : projects.filter((project) => project.category === filter)

  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">Our Projects</h1>

      <div className="mb-8 flex flex-wrap gap-2">
        <Button variant={filter === "all" ? "default" : "outline"} onClick={() => setFilter("all")}>
          All Projects
        </Button>
        <Button variant={filter === "ongoing" ? "default" : "outline"} onClick={() => setFilter("ongoing")}>
          Ongoing
        </Button>
        <Button variant={filter === "completed" ? "default" : "outline"} onClick={() => setFilter("completed")}>
          Completed
        </Button>
        <Button variant={filter === "partnerships" ? "default" : "outline"} onClick={() => setFilter("partnerships")}>
          Partnerships
        </Button>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filteredProjects.map((project) => (
          <Card key={project.id} className="overflow-hidden">
            <div className="relative h-48 w-full">
              <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
              <div className="absolute right-2 top-2 rounded-full bg-card px-2 py-1 text-xs font-medium shadow">
                {project.category === "ongoing" && "Ongoing"}
                {project.category === "completed" && "Completed"}
                {project.category === "partnerships" && "Partnership"}
              </div>
            </div>
            <CardHeader>
              <CardTitle className="line-clamp-1">{project.title}</CardTitle>
              <CardDescription>{project.location}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="line-clamp-3 text-sm text-muted-foreground">{project.description}</p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm">
                View Details
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredProjects.length === 0 && (
        <div className="mt-12 text-center">
          <p className="text-lg text-muted-foreground">No projects found in this category.</p>
        </div>
      )}
    </div>
  )
}

