"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Leaf, Droplets, Factory } from "lucide-react"

const services = [
  {
    id: "farmer-support",
    title: "Farmer Support",
    icon: <Leaf className="h-6 w-6" />,
    description:
      "We provide comprehensive support to farmers through training programs, seed distribution, and technical assistance to improve crop yields and farming practices.",
    image: "/placeholder.svg?height=400&width=600",
    details: [
      "Training on modern farming techniques",
      "Distribution of high-quality seeds",
      "Soil testing and analysis",
      "Pest management guidance",
      "Market linkage support",
    ],
  },
  {
    id: "irrigation-water",
    title: "Irrigation & Water",
    icon: <Droplets className="h-6 w-6" />,
    description:
      "We develop and implement irrigation systems and water management solutions to help farmers overcome drought challenges and improve water efficiency.",
    image: "/placeholder.svg?height=400&width=600",
    details: [
      "Small-scale irrigation schemes",
      "Water harvesting techniques",
      "Drip irrigation systems",
      "Water resource mapping",
      "Borehole drilling coordination",
    ],
  },
  {
    id: "agro-processing",
    title: "Agro-Processing",
    icon: <Factory className="h-6 w-6" />,
    description:
      "Our agro-processing initiatives help farmers add value to their products, reduce post-harvest losses, and access better markets for processed goods.",
    image: "/placeholder.svg?height=400&width=600",
    details: [
      "Food processing training",
      "Equipment support for small processors",
      "Quality control guidance",
      "Packaging improvement",
      "Market access for processed products",
    ],
  },
]

export default function ServicesPage() {
  const [activeTab, setActiveTab] = useState("farmer-support")

  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">Our Services</h1>

      <Tabs defaultValue="farmer-support" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          {services.map((service) => (
            <TabsTrigger key={service.id} value={service.id} className="flex items-center gap-2">
              {service.icon}
              <span className="hidden md:inline">{service.title}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {services.map((service) => (
          <TabsContent key={service.id} value={service.id} className="mt-6">
            <Card>
              <div className="relative h-64 w-full overflow-hidden rounded-t-lg md:h-80">
                <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
              </div>
              <CardHeader>
                <CardTitle className="text-2xl">{service.title}</CardTitle>
                <CardDescription>{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <h3 className="mb-2 font-medium">What We Offer:</h3>
                <ul className="ml-6 list-disc space-y-1">
                  {service.details.map((detail, index) => (
                    <li key={index} className="text-muted-foreground">
                      {detail}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild>
                  <Link href={`/services/${service.id}`}>Learn More</Link>
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

