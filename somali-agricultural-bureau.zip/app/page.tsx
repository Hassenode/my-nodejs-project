"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Leaf, Target, BarChart, Users, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import WeatherWidget from "@/components/weather-widget"
import { useTranslation } from "@/contexts/translation-context"

// Statistics data
const getStats = (t) => [
  {
    id: 1,
    label: t("stats.cultivated"),
    value: "155,625.76",
    unit: t("stats.hectares"),
    icon: <Leaf className="h-6 w-6" />,
  },
  {
    id: 2,
    label: t("stats.land"),
    value: "112,850.4",
    unit: t("stats.hectares"),
    icon: <Target className="h-6 w-6" />,
  },
  {
    id: 3,
    label: t("stats.agricultural"),
    value: "37,232",
    unit: t("stats.hectares"),
    icon: <BarChart className="h-6 w-6" />,
  },
  { id: 4, label: t("stats.forest"), value: "23.6", unit: "%", icon: <Users className="h-6 w-6" /> },
]

// Banner slideshow data
const getBannerSlides = (t) => [
  {
    id: 1,
    image: "/placeholder.svg?height=600&width=1920&text=Green+Farming&bgcolor=2e7d32&textcolor=ffffff",
    title: t("banner.title1"),
    description: t("banner.desc1"),
  },
  {
    id: 2,
    image: "/placeholder.svg?height=600&width=1920&text=Sustainable+Agriculture&bgcolor=388e3c&textcolor=ffffff",
    title: t("banner.title2"),
    description: t("banner.desc2"),
  },
  {
    id: 3,
    image: "/placeholder.svg?height=600&width=1920&text=Green+Community+Development&bgcolor=1b5e20&textcolor=ffffff",
    title: t("banner.title3"),
    description: t("banner.desc3"),
  },
]

export default function Home() {
  const { t } = useTranslation()
  const [currentSlide, setCurrentSlide] = useState(0)

  // Get translated data
  const stats = getStats(t)
  const bannerSlides = getBannerSlides(t)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerSlides.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [bannerSlides.length])

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative">
        <div className="relative h-[600px] w-full">
          {bannerSlides.map((slide, index) => (
            <div
              key={slide.id}
              className={`absolute inset-0 transition-opacity duration-1000 ${
                index === currentSlide ? "opacity-100" : "opacity-0 pointer-events-none"
              }`}
            >
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl mx-auto px-6 py-12 bg-green-600/85 backdrop-blur-sm rounded-lg shadow-lg flex flex-col items-center justify-center text-center text-white">
                <h1 className="max-w-4xl text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">{slide.title}</h1>
                <p className="mt-4 max-w-2xl text-lg md:text-xl">{slide.description}</p>
              </div>
            </div>
          ))}

          {/* Navigation arrows */}
          <button
            onClick={() => setCurrentSlide((prev) => (prev - 1 + bannerSlides.length) % bannerSlides.length)}
            className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white hover:bg-black/50"
            aria-label={t("banner.previous")}
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={() => setCurrentSlide((prev) => (prev + 1) % bannerSlides.length)}
            className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-black/30 p-2 text-white hover:bg-black/50"
            aria-label={t("banner.next")}
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </section>

      {/* Bureau Head's Message */}
      <section className="py-16">
        <div className="container max-w-4xl">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-green-600 mb-4">{t("bureau.head.title")}</h2>
            <div className="flex items-center justify-center gap-4">
              <div className="h-0.5 w-32 bg-green-600"></div>
              <Leaf className="h-8 w-8 text-green-600" />
              <div className="h-0.5 w-32 bg-green-600"></div>
            </div>
          </div>

          <div className="grid gap-12 md:grid-cols-2">
            <div className="text-center">
              <div className="relative h-80 w-80 mx-auto overflow-hidden rounded-lg border-4 border-green-600 mb-4">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250314-WA0006.jpg-RcVzrCyG0WLXWONAi8Hx5cpCW7y09Y.jpeg"
                  alt={t("bureau.head.name")}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="text-green-600 font-medium">{t("bureau.head.position").split(",")[0]}</div>
              <h3 className="text-2xl font-bold mt-1">{t("bureau.head.name")}</h3>
              <p className="text-gray-600">{t("bureau.head.position")}</p>
            </div>

            <div className="space-y-6">
              <p className="text-slate-800 text-justify leading-relaxed">{t("bureau.head.message1")}</p>
              <p className="text-slate-800 text-justify leading-relaxed">{t("bureau.head.message2")}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Vision, Mission, Goal */}
      <section className="bg-green-50 py-16">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-3">
            <Card className="bg-green-800 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-6 w-6" />
                  {t("about.vision.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{t("vision.short")}</p>
              </CardContent>
            </Card>

            <Card className="bg-green-700 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-6 w-6" />
                  {t("about.mission.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{t("mission.short")}</p>
              </CardContent>
            </Card>

            <Card className="bg-green-600 text-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-6 w-6" />
                  {t("bureau.goal")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{t("goal.text")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16">
        <div className="container">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {stats.map((stat) => (
              <Card key={stat.id}>
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <div className="rounded-full bg-green-100 p-3 text-green-600">{stat.icon}</div>
                  <h3 className="mt-4 text-3xl font-bold text-green-800">{stat.value}</h3>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="text-xs text-gray-500">{stat.unit}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Recent News */}
      <section className="bg-gray-50 py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold text-green-800">{t("news.title")}</h2>
          <div className="grid gap-8 md:grid-cols-3">
            {[1, 2, 3].map((item) => (
              <Card key={item} className="overflow-hidden">
                <div className="relative h-48 w-full">
                  <Image
                    src={`/placeholder.svg?height=200&width=400&text=News+${item}`}
                    alt={`${t("news.item")} ${item}`}
                    fill
                    className="object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="line-clamp-2">{t("news.item.title", { number: item })}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="line-clamp-3 text-sm text-gray-600">{t("news.item.desc")}</p>
                  <Button asChild variant="link" className="mt-4 p-0 text-green-600">
                    <Link href="/news">{t("news.readmore")}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Development Partners */}
      <section className="py-16">
        <div className="container">
          <h2 className="mb-8 text-center text-3xl font-bold text-green-800">{t("partners.title")}</h2>
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {[1, 2, 3, 4].map((item) => (
              <div key={item} className="flex items-center justify-center">
                <div className="relative h-20 w-40">
                  <Image
                    src={`/placeholder.svg?height=80&width=160&text=Partner+${item}`}
                    alt={`${t("partner")} ${item}`}
                    fill
                    className="object-contain"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Weather Widget */}
      <section className="bg-green-50 py-8">
        <div className="container">
          <div className="mx-auto max-w-md">
            <h2 className="mb-4 text-center text-2xl font-bold text-green-800">{t("weather.current")}</h2>
            <WeatherWidget />
          </div>
        </div>
      </section>
    </div>
  )
}

