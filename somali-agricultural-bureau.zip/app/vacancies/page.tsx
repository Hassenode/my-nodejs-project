import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Briefcase, MapPin } from "lucide-react"

const vacancies = [
  {
    id: 1,
    title: "Agricultural Extension Officer",
    department: "Crop Production",
    location: "Jijiga",
    type: "Full-time",
    posted: "March 10, 2025",
    deadline: "March 31, 2025",
    description:
      "We are seeking an experienced Agricultural Extension Officer to provide technical support and training to farmers in the Jijiga area.",
  },
  {
    id: 2,
    title: "Irrigation Engineer",
    department: "Irrigation & Water Management",
    location: "Gode Zone",
    type: "Full-time",
    posted: "March 8, 2025",
    deadline: "March 29, 2025",
    description:
      "An Irrigation Engineer is needed to design, implement and maintain irrigation systems for agricultural projects in the Gode Zone.",
  },
  {
    id: 3,
    title: "Agricultural Economist",
    department: "Planning & Research",
    location: "Jijiga",
    type: "Full-time",
    posted: "March 5, 2025",
    deadline: "March 26, 2025",
    description:
      "We are looking for an Agricultural Economist to analyze market trends, conduct research, and provide economic insights for agricultural development programs.",
  },
  {
    id: 4,
    title: "Administrative Assistant",
    department: "Administration",
    location: "Jijiga",
    type: "Full-time",
    posted: "March 3, 2025",
    deadline: "March 24, 2025",
    description:
      "An Administrative Assistant is required to provide clerical and administrative support to the bureau's management team.",
  },
]

export default function VacanciesPage() {
  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">Current Vacancies</h1>

      <div className="mb-8 bg-turquoise p-6 text-white rounded-lg">
        <h2 className="text-xl font-bold mb-2">Join Our Team</h2>
        <p>
          The Somali Regional State Agricultural Bureau is looking for talented and dedicated professionals to join our
          team. We offer competitive salaries, opportunities for professional growth, and the chance to make a real
          difference in the agricultural development of the Somali Region.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {vacancies.map((vacancy) => (
          <Card key={vacancy.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-xl">{vacancy.title}</CardTitle>
                <Badge variant="outline" className="bg-turquoise text-white">
                  {vacancy.type}
                </Badge>
              </div>
              <CardDescription className="flex flex-col gap-1 mt-2">
                <div className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                  <span>{vacancy.department}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{vacancy.location}</span>
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">{vacancy.description}</p>
              <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  <span>Posted: {vacancy.posted}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  <span>Deadline: {vacancy.deadline}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild>
                <Link href={`/vacancies/${vacancy.id}`}>View Details & Apply</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-12 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-xl font-bold mb-4">Application Process</h2>
        <ol className="list-decimal ml-6 space-y-2">
          <li>Review the job description and requirements carefully</li>
          <li>Prepare your CV and cover letter</li>
          <li>Submit your application through our online portal or via email</li>
          <li>Shortlisted candidates will be contacted for interviews</li>
          <li>Final selection and job offer</li>
        </ol>
        <p className="mt-4 text-sm text-muted-foreground">
          For any questions regarding the application process, please contact our HR department at
          <a href="mailto:hr@srs-banr.gov.et" className="text-turquoise-dark ml-1">
            hr@srs-banr.gov.et
          </a>
        </p>
      </div>
    </div>
  )
}

