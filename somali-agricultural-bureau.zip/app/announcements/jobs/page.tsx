"use client"

import { useTranslation } from "@/contexts/translation-context"
import Link from "next/link"
import { ArrowLeft, Calendar, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function JobVacanciesPage() {
  const { t, language } = useTranslation()

  // Translation keys for Job Vacancies page
  const translations = {
    en: {
      title: "Job Vacancies",
      backToAnnouncements: "Back to Announcements",
      description:
        "Current job openings at the Somali Regional State Agricultural Bureau. Join our team and contribute to agricultural development in the region.",
      job1Title: "Agricultural Extension Officer",
      job1Department: "Crop Production",
      job1Location: "Jijiga",
      job1Type: "Full-time",
      job1Posted: "March 15, 2025",
      job1Deadline: "April 15, 2025",
      job1Description:
        "We are seeking an experienced Agricultural Extension Officer to provide technical support and training to farmers in the Jijiga area.",
      job1Status: "Open",
      job2Title: "Irrigation Engineer",
      job2Department: "Irrigation & Water Management",
      job2Location: "Gode Zone",
      job2Type: "Full-time",
      job2Posted: "March 12, 2025",
      job2Deadline: "April 10, 2025",
      job2Description:
        "An Irrigation Engineer is needed to design, implement and maintain irrigation systems for agricultural projects in the Gode Zone.",
      job2Status: "Open",
      job3Title: "Agricultural Economist",
      job3Department: "Planning & Research",
      job3Location: "Jijiga",
      job3Type: "Full-time",
      job3Posted: "March 10, 2025",
      job3Deadline: "April 5, 2025",
      job3Description:
        "We are looking for an Agricultural Economist to analyze market trends and provide economic insights for agricultural development programs.",
      job3Status: "Open",
      viewDetails: "View Details & Apply",
      posted: "Posted",
      deadline: "Deadline",
    },
    so: {
      title: "Shaqooyinka Bannaan",
      backToAnnouncements: "Ku Noqo Ogeysiisyada",
      description:
        "Shaqooyinka bannaan ee hadda ka jira Xafiiska Beeraha Gobolka Soomaalida. Ku soo biir kooxdayada oo gacan ka geyso horumarinta beeraha ee gobolka.",
      job1Title: "Sarkaalka Fidinta Beeraha",
      job1Department: "Wax Soo Saarka Dalagga",
      job1Location: "Jigjiga",
      job1Type: "Waqti-buuxa",
      job1Posted: "Maarso 15, 2025",
      job1Deadline: "Abriil 15, 2025",
      job1Description:
        "Waxaan raadinaynaa Sarkaal Fidinta Beeraha oo khibrad leh si uu u bixiyo taageero farsamo iyo tababar beeralayda aagga Jigjiga.",
      job1Status: "Furan",
      job2Title: "Injineerka Waraabka",
      job2Department: "Waraabka & Maaraynta Biyaha",
      job2Location: "Aagga Qoode",
      job2Type: "Waqti-buuxa",
      job2Posted: "Maarso 12, 2025",
      job2Deadline: "Abriil 10, 2025",
      job2Description:
        "Injineerka Waraabka ayaa loo baahan yahay si uu u naqshadeeyo, u fuliyo oo u dayactiro nidaamyada waraabka ee mashaariicda beeraha ee Aagga Qoode.",
      job2Status: "Furan",
      job3Title: "Dhaqaalaha Beeraha",
      job3Department: "Qorshaynta & Cilmi-baarista",
      job3Location: "Jigjiga",
      job3Type: "Waqti-buuxa",
      job3Posted: "Maarso 10, 2025",
      job3Deadline: "Abriil 5, 2025",
      job3Description:
        "Waxaan raadinaynaa Dhaqaalaha Beeraha si uu u falanqeeyo isbeddelada suuqa oo uu u bixiyo aragtiyo dhaqaale oo loogu talagalay barnaamijyada horumarinta beeraha.",
      job3Status: "Furan",
      viewDetails: "Arag Faahfaahinta & Codso",
      posted: "La dhigay",
      deadline: "Waqtiga kama dambeysta ah",
    },
    am: {
      title: "ክፍት የሥራ ቦታዎች",
      backToAnnouncements: "ወደ ማስታወቂያዎች ተመለስ",
      description: "በሶማሌ ክልል የግብርና ቢሮ ያሉ የአሁኑ ክፍት የሥራ ቦታዎች። ቡድናችን ይቀላቀሉ እና በክልሉ የግብርና ልማት ላይ አስተዋጽኦ ያድርጉ።",
      job1Title: "የግብርና ኤክስቴንሽን መኮንን",
      job1Department: "የሰብል ምርት",
      job1Location: "ጂጂጋ",
      job1Type: "ሙሉ ጊዜ",
      job1Posted: "መጋቢት 15, 2025",
      job1Deadline: "ሚያዝያ 15, 2025",
      job1Description: "በጂጂጋ አካባቢ ለአርሶ አደሮች ቴክኒካዊ ድጋፍ እና ስልጠና የሚሰጥ ልምድ ያለው የግብርና ኤክስቴንሽን መኮንን እየፈለግን ነው።",
      job1Status: "ክፍት",
      job2Title: "የመስኖ ኢንጂነር",
      job2Department: "የመስኖ እና የውሃ አስተዳደር",
      job2Location: "ጎዴ ዞን",
      job2Type: "ሙሉ ጊዜ",
      job2Posted: "መጋቢት 12, 2025",
      job2Deadline: "ሚያዝያ 10, 2025",
      job2Description: "በጎዴ ዞን ለግብርና ፕሮጀክቶች የመስኖ ስርዓቶችን ለመንደፍ፣ ለመተግበር እና ለመጠበቅ የመስኖ ኢንጂነር ያስፈልጋል።",
      job2Status: "ክፍት",
      job3Title: "የግብርና ኢኮኖሚስት",
      job3Department: "ዕቅድ እና ምርምር",
      job3Location: "ጂጂጋ",
      job3Type: "ሙሉ ጊዜ",
      job3Posted: "መጋቢት 10, 2025",
      job3Deadline: "ሚያዝያ 5, 2025",
      job3Description: "የገበያ አዝማሚያዎችን ለመተንተን እና ለግብርና ልማት ፕሮግራሞች የኢኮኖሚ ግንዛቤዎችን ለመስጠት የግብርና ኢኮኖሚስት እየፈለግን ነው።",
      job3Status: "ክፍት",
      viewDetails: "ዝርዝሮችን ይመልከቱ እና ያመልክቱ",
      posted: "የተለጠፈበት",
      deadline: "የመጨረሻ ቀን",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  const jobs = [
    {
      id: 1,
      title: currentTranslations.job1Title,
      department: currentTranslations.job1Department,
      location: currentTranslations.job1Location,
      type: currentTranslations.job1Type,
      posted: currentTranslations.job1Posted,
      deadline: currentTranslations.job1Deadline,
      description: currentTranslations.job1Description,
      status: currentTranslations.job1Status,
    },
    {
      id: 2,
      title: currentTranslations.job2Title,
      department: currentTranslations.job2Department,
      location: currentTranslations.job2Location,
      type: currentTranslations.job2Type,
      posted: currentTranslations.job2Posted,
      deadline: currentTranslations.job2Deadline,
      description: currentTranslations.job2Description,
      status: currentTranslations.job2Status,
    },
    {
      id: 3,
      title: currentTranslations.job3Title,
      department: currentTranslations.job3Department,
      location: currentTranslations.job3Location,
      type: currentTranslations.job3Type,
      posted: currentTranslations.job3Posted,
      deadline: currentTranslations.job3Deadline,
      description: currentTranslations.job3Description,
      status: currentTranslations.job3Status,
    },
  ]

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/announcements" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            {currentTranslations.backToAnnouncements}
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground max-w-3xl">{currentTranslations.description}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {jobs.map((job) => (
          <Card key={job.id} className="flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{job.title}</CardTitle>
                  <CardDescription className="mt-1">{job.department}</CardDescription>
                </div>
                <Badge variant="outline" className="bg-green-500 text-white">
                  {job.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-sm text-muted-foreground mb-4">{job.description}</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span>{job.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>
                    {currentTranslations.posted}: {job.posted}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>
                    {currentTranslations.deadline}: {job.deadline}
                  </span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <Button asChild className="w-full">
                <Link href={`/announcements/jobs/${job.id}`}>{currentTranslations.viewDetails}</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

