import Link from "next/link"
import { ArrowLeft, Calendar, Building, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const tenders = [
  {
    id: 1,
    title: "Supply of Agricultural Equipment",
    reference: "SRSAB/2024/T001",
    category: "Equipment Supply",
    deadline: "April 20, 2025",
    postedDate: "March 15, 2025",
    description:
      "Supply and delivery of agricultural equipment including tractors and irrigation systems for the Bureau's development projects.",
    status: "Open",
    value: "ETB 5,000,000",
  },
  {
    id: 2,
    title: "Construction of Irrigation Infrastructure",
    reference: "SRSAB/2024/T002",
    category: "Construction",
    deadline: "April 15, 2025",
    postedDate: "March 12, 2025",
    description:
      "Construction of irrigation channels and water storage facilities in the Gode Zone agricultural development area.",
    status: "Open",
    value: "ETB 8,000,000",
  },
  {
    id: 3,
    title: "Supply of Agricultural Inputs",
    reference: "SRSAB/2024/T003",
    category: "Input Supply",
    deadline: "April 10, 2025",
    postedDate: "March 10, 2025",
    description: "Supply of fertilizers, seeds, and other agricultural inputs for the 2024 farming season.",
    status: "Open",
    value: "ETB 3,500,000",
  },
]

export default function TendersPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/announcements" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Announcements
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Tenders</h1>
        <p className="text-muted-foreground max-w-3xl">
          Current tender opportunities at the Somali Regional State Agricultural Bureau. View our open tenders and
          submission requirements.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {tenders.map((tender) => (
          <Card key={tender.id} className="flex flex-col">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{tender.title}</CardTitle>
                  <CardDescription className="mt-1">Ref: {tender.reference}</CardDescription>
                </div>
                <Badge variant="outline" className="bg-green-500 text-white">
                  {tender.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-sm text-muted-foreground mb-4">{tender.description}</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Building className="h-4 w-4 text-muted-foreground" />
                  <span>{tender.category}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Posted: {tender.postedDate}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Deadline: {tender.deadline}</span>
                </div>
                <div className="mt-2 font-medium">Estimated Value: {tender.value}</div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <Button asChild className="w-full">
                <Link href={`/announcements/tenders/${tender.id}`}>View Details & Apply</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-12 bg-gray-50 p-6 rounded-lg">
        <h2 className="text-xl font-bold mb-4">Tender Submission Guidelines</h2>
        <ul className="list-disc ml-6 space-y-2 text-muted-foreground">
          <li>All tenders must be submitted in sealed envelopes</li>
          <li>Include the tender reference number clearly on all documents</li>
          <li>Submit all required documentation as specified in the tender document</li>
          <li>Ensure compliance with all technical specifications</li>
          <li>Submit before the specified deadline</li>
        </ul>
        <Button className="mt-6" asChild>
          <Link href="/resources/manuals-and-guidelines">Download Full Guidelines</Link>
        </Button>
      </div>
    </div>
  )
}

