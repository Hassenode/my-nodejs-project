"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Globe } from "lucide-react"
import { useTranslation } from "@/contexts/translation-context"

export default function ContactPage() {
  const { t } = useTranslation()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, you would handle form submission here
    console.log("Form submitted:", formData)
    alert("Thank you for your message. We will get back to you soon!")
    setFormData({ name: "", email: "", message: "" })
  }

  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">{t("contact.us")}</h1>

      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <Card>
            <CardHeader>
              <CardTitle>{t("send.message")}</CardTitle>
              <CardDescription>{t("contact.form.desc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t("name")}</Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder={t("name")}
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">{t("email")}</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder={t("email")}
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">{t("message")}</Label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder={t("message")}
                    rows={5}
                    value={formData.message}
                    onChange={handleChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  {t("submit")}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>{t("contact.info")}</CardTitle>
              <CardDescription>{t("contact.reach")}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="mt-1 h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-medium">{t("address")}</h3>
                  <p className="text-sm text-muted-foreground">JigJiga, Somali Regional State</p>
                  <p className="text-sm text-muted-foreground">P.O. Box: 206</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="mt-1 h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-medium">{t("phone")}</h3>
                  <p className="text-sm text-muted-foreground">+251-257753584/7418</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="mt-1 h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-medium">{t("email")}</h3>
                  <p className="text-sm text-muted-foreground">
                    <a href="mailto:srs-banr@gov.et" className="hover:text-primary">
                      srs-banr@gov.et
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Globe className="mt-1 h-5 w-5 text-primary" />
                <div>
                  <h3 className="font-medium">{t("website")}</h3>
                  <p className="text-sm text-muted-foreground">
                    <a
                      href="http://srs-banr.gov.et/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary"
                    >
                      http://srs-banr.gov.et/
                    </a>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("office.location")}</CardTitle>
              <CardDescription>{t("map.desc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video overflow-hidden rounded-md bg-muted">
                {/* In a real application, you would embed an actual map here */}
                <div className="flex h-full w-full items-center justify-center bg-muted p-8 text-center text-muted-foreground">
                  <p>Interactive map of Jijiga, Somali Region would be embedded here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

