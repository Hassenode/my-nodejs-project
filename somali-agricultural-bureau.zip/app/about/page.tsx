"use client"

import { useTranslation } from "@/contexts/translation-context"
import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Users, FileText, Target, Building } from "lucide-react"

export default function AboutPage() {
  const { t, language } = useTranslation()

  // Translation keys for About page
  const translations = {
    en: {
      title: "About Us",
      background: "Background",
      backgroundText1:
        "The Bureau of Agriculture and Natural Resources (BoANR) of Somali Regional State (SRS), is one of the first-ranked bureaus of development. It was founded on May 15, 1993 GC. It was established for the responsibility of agricultural and natural resources development of Somali regional state.",
      backgroundText2:
        "It has the mandates of policy & guidelines development and directional progression for the development and advancement of agriculture and natural resources. Its main office of the bureau is located in JigJiga city and it has sub-branch offices in the 93 woredas and 6 self-administrative cities.",
      backgroundText3:
        "In addition, the bureau has 11 zonal coordination centers in agriculture and natural resources. There are 11 coordinators at these centers who report directly to the main Bureau. In total, the Bureau operates in 13 directorates. Out of those 8 directorates are technical while the remaining 5 directorates are supportive for the technical directives. Additionally, all sub-bureaus offices at the district level consists 3 technical directorates.",
      backgroundText4:
        "Meanwhile, this bureau also leads its partners in the field of agriculture such as the bureau of cooperatives, the research institute, the seed improving agency and the irrigation and basin development bureaus of SRS. The bureau is also directive for all NGOs which involves in the development of agriculture and natural resources sectors.",
      vision: "Vision",
      visionText:
        "To see the pastoral and agro-pastoral communities in the region moved from the subsistence pastoralist and farming system to self-reliance market-oriented production and become one of marketable products suppliers in the horn of Africa.",
      mission: "Mission",
      missionText:
        "To transform the existing pastoralists and agro-pastoralists way of life of the region to a modern sustainable production system, by adopting the appropriate agriculture technologies and to eventually alleviate the deeply rooted poverty of the region.",
      mandates: "Mandates",
      mandatesIntro:
        "The Bureau of Agriculture and Natural Resources was established by the Proclamation No. 7/1992 and approved by the regional council in 1992 E.C. The statement was published by the regional council's newspaper which is known as \"Dhool Gazette, 1992\". According to this statement, the bureau's responsibilities include the following:",
      viewAllMandates: "View all 35 mandates",
      leadership: "Leadership",
      structure: "Organizational Structure",
      facts: "Key Facts",
      factsEstablished: "Established",
      factsDirectorates: "Directorates",
      factsZones: "Zonal Centers",
      factsCoverage: "Coverage",
      fullMandates: "Full Mandates of the Bureau",
      bureauHead: "Bureau Head",
      deputyHead: "Deputy Bureau Head",
      programsDirector: "Director of Programs",
    },
    so: {
      title: "Ku Saabsan",
      background: "Asalka",
      backgroundText1:
        "Xafiiska Beeraha iyo Kheyraadka Dabiiciga ah (BoANR) ee Gobolka Soomaalida, waa mid ka mid ah xafiisyada horumarinta ee heerka koowaad. Waxaa la aasaasay May 15, 1993 GC. Waxaa loo aasaasay mas'uuliyadda horumarinta beeraha iyo kheyraadka dabiiciga ah ee gobolka Soomaalida.",
      backgroundText2:
        "Waxay leedahay awoodaha horumarinta siyaasadda & tilmaamaha iyo horumarka jihada ee horumarinta iyo horumarinta beeraha iyo kheyraadka dabiiciga ah. Xafiiska ugu weyn ee xafiiska wuxuu ku yaallaa magaalada Jigjiga wuxuuna leeyahay xafiisyo laamaha hoose ah oo ku yaalla 93 degmo iyo 6 magaalo oo is-maamula.",
      backgroundText3:
        "Intaa waxaa dheer, xafiiska wuxuu leeyahay 11 xarumood oo isku dubarid ah oo ku yaalla beeraha iyo kheyraadka dabiiciga ah. Waxaa jira 11 isku-duwayaal oo ku sugan xarumahan oo si toos ah ugu soo warrama Xafiiska weyn. Guud ahaan, Xafiiska wuxuu ka shaqeeyaa 13 agaasime. Kuwaas oo 8 ka mid ah yihiin farsamo halka 5-ta kale ay yihiin taageero agaasimahaas farsamo. Intaa waxaa dheer, dhammaan xafiisyada hoose ee xafiisyada heerka degmada waxay ka kooban yihiin 3 agaasime oo farsamo.",
      backgroundText4:
        "Isla mar ahaantaas, xafiiskani wuxuu sidoo kale hogaamiyaa lammaanayaashiisa dhinaca beeraha sida xafiiska iskaashatooyinka, machadka cilmi-baarista, hay'adda hagaajinta abuurka iyo xafiisyada horumarinta waraabka iyo wabiyada ee SRS. Xafiiska waa sidoo kale tilmaame dhammaan NGO-yada ku lug leh horumarinta beeraha iyo qaybaha kheyraadka dabiiciga ah.",
      vision: "Aragtida",
      visionText:
        "In la arko bulshada xoolo-dhaqatada iyo beeralayda ee gobolka oo ka gudubtay nidaamka xoolo-dhaqashada iyo beerashada ee isagu filnaanta ah, una gudubtay wax-soo-saar suuq ku salaysan oo isagu filan, kana mid noqday kuwa ugu waaweyn ee bixiya alaabaha suuqa ee Geeska Afrika.",
      mission: "Hawlgalka",
      missionText:
        "In la beddelo hab-nololeedka xoolo-dhaqatada iyo beeralayda ee gobolka si loo gaaro nidaam wax-soo-saar casri ah oo waara, iyada oo la adeegsanayo tignoolajiyada beeraha ee ku habboon, si ugu dambeyntii looga takhaluso saboolnimada aad u xididda dheer ee gobolka.",
      mandates: "Awoodaha",
      mandatesIntro:
        'Xafiiska Beeraha iyo Kheyraadka Dabiiciga ah waxaa la aasaasay Xeerka Tirsigiisu yahay 7/1992 waxaana ansixiyay golaha gobolka sanadkii 1992 E.C. Bayaanka waxaa lagu daabacay wargeyska golaha gobolka oo lagu magacaabo "Dhool Gazette, 1992". Sida ku cad bayaankan, mas\'uuliyadaha xafiiska waxaa ka mid ah kuwan soo socda:',
      viewAllMandates: "Arag dhammaan 35-ka awood",
      leadership: "Hoggaaminta",
      structure: "Qaab-dhismeedka Hay'adda",
      facts: "Xaqiiqooyinka Muhiimka ah",
      factsEstablished: "La aasaasay",
      factsDirectorates: "Agaasimayaal",
      factsZones: "Xarumaha Xudunta",
      factsCoverage: "Daboolka",
      fullMandates: "Awoodaha Buuxa ee Xafiiska",
      bureauHead: "Madaxa Xafiiska",
      deputyHead: "Ku-xigeenka Madaxa Xafiiska",
      programsDirector: "Agaasimaha Barnaamijyada",
    },
    am: {
      title: "ስለ እኛ",
      background: "ዳራ",
      backgroundText1:
        "የሶማሌ ክልል የግብርና እና የተፈጥሮ ሀብት ቢሮ (BoANR) ከልማት ቢሮዎች መካከል በመጀመሪያ ደረጃ የሚመደብ ነው። በግሪጎሪያን አቆጣጠር ግንቦት 15 ቀን 1993 ዓ.ም. ተመሰረተ። የሶማሌ ክልል የግብርና እና የተፈጥሮ ሀብት ልማት ኃላፊነት እንዲወስድ ተቋቋመ።",
      backgroundText2:
        "የግብርና እና የተፈጥሮ ሀብት ልማት እና እድገት ፖሊሲዎችን እና መመሪያዎችን የማዘጋጀት እና አቅጣጫ የመስጠት ኃላፊነት አለው። የቢሮው ዋና ጽህፈት ቤት በጂጂጋ ከተማ ውስጥ ሲሆን በ93 ወረዳዎች እና በ6 ራስ-አስተዳዳሪ ከተሞች ንዑስ-ቅርንጫፍ ጽህፈት ቤቶች አሉት።",
      backgroundText3:
        "በተጨማሪም፣ ቢሮው በግብርና እና በተፈጥሮ ሀብት ውስጥ 11 የዞን ማስተባበሪያ ማዕከላት አሉት። በእነዚህ ማዕከላት ውስጥ ለዋናው ቢሮ በቀጥታ ሪፖርት የሚያደርጉ 11 አስተባባሪዎች አሉ። በአጠቃላይ፣ ቢሮው በ13 ዳይሬክቶሬቶች ይሰራል። ከእነዚህ ውስጥ 8 ቴክኒካዊ ሲሆኑ ቀሪዎቹ 5 ዳይሬክቶሬቶች ለቴክኒካዊ ዳይሬክቶሬቶች ድጋፍ ሰጪ ናቸው። በተጨማሪም፣ በወረዳ ደረጃ ያሉ ሁሉም ንዑስ-ቢሮዎች 3 ቴክኒካዊ ዳይሬክቶሬቶችን ይይዛሉ።",
      backgroundText4:
        "በዚህ ጊዜ፣ ይህ ቢሮ በግብርና መስክ ያሉትን አጋሮቹን ይመራል፣ ለምሳሌ የህብረት ሥራ ማህበራት ቢሮ፣ የምርምር ተቋም፣ የዘር ማሻሻያ ኤጀንሲ እና የሶማሌ ክልል የመስኖ እና የተፋሰስ ልማት ቢሮዎች። ቢሮው በግብርና እና በተፈጥሮ ሀብት ዘርፎች ልማት ውስጥ ለሚሳተፉ ሁሉም መንግስታዊ ያልሆኑ ድርጅቶች መመሪያ ነው።",
      vision: "ራዕይ",
      visionText:
        "በአካባቢው ያሉ የአርብቶ አደርና የግብርና ማህበረሰቦች ከራስ-ብቃት ያለው የአርብቶ አደርነትና የእርሻ ስርዓት ወደ ራስ-ተመራጭ ገበያ-ተኮር ምርት እንዲሸጋገሩና በአፍሪካ ቀንድ ውስጥ ከሚገኙ ገበያዎች አቅራቢዎች መካከል አንዱ እንዲሆኑ ማድረግ።",
      mission: "ተልዕኮ",
      missionText:
        "በአካባቢው ያለውን የአርብቶ አደርና የግብርና ማህበረሰብ የኑሮ ዘይቤ ወደ ዘመናዊ ዘላቂ የምርት ስርዓት ለመቀየር፣ ተገቢውን የግብርና ቴክኖሎጂዎችን በመጠቀም እና በመጨረሻም በአካባቢው ያለውን ከስር የሰደደ ድህነት ለማስወገድ።",
      mandates: "ተልዕኮዎች",
      mandatesIntro:
        'የግብርናና የተፈጥሮ ሀብት ቢሮ በአዋጅ ቁጥር 7/1992 ተቋቁሞ በ1992 ዓ.ም በክልሉ ምክር ቤት ጸድቋል። መግለጫው በክልሉ ምክር ቤት ጋዜጣ "ዱል ጋዜጣ፣ 1992" በሚታወቀው ላይ ታትሟል። በዚህ መግለጫ መሰረት፣ የቢሮው ኃላፊነቶች የሚከተሉትን ያካትታሉ፡-',
      viewAllMandates: "ሁሉንም 35 ተልዕኮዎች ይመልከቱ",
      leadership: "አመራር",
      structure: "የድርጅት መዋቅር",
      facts: "ዋና ዋና እውነታዎች",
      factsEstablished: "የተቋቋመበት",
      factsDirectorates: "ዳይሬክቶሬቶች",
      factsZones: "የዞን ማዕከላት",
      factsCoverage: "ሽፋን",
      fullMandates: "የቢሮው ሙሉ ተልዕኮዎች",
      bureauHead: "የቢሮ ኃላፊ",
      deputyHead: "የቢሮ ምክትል ኃላፊ",
      programsDirector: "የፕሮግራሞች ዳይሬክተር",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>

      {/* Background Section */}
      <section className="mb-12">
        <h2 className="mb-4 text-2xl font-bold">{currentTranslations.background}</h2>
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <p className="mb-4 text-muted-foreground">{currentTranslations.backgroundText1}</p>
            <p className="mb-4 text-muted-foreground">{currentTranslations.backgroundText2}</p>
            <p className="text-muted-foreground">{currentTranslations.backgroundText3}</p>
            <p className="mt-4 text-muted-foreground">{currentTranslations.backgroundText4}</p>
          </div>
          <div className="flex flex-col items-center justify-center h-full">
            <div className="relative h-64 w-64 overflow-hidden rounded-full border-4 border-turquoise">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/XB%20logo-l6c4Xi1v7ZUYu8OIY6TfB5SlS9MCNj.png"
                alt="Somali Regional State Agricultural Bureau Logo"
                fill
                className="object-contain p-2"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Vision, Mission, Mandates Tabs */}
      <section className="mb-12">
        <Tabs defaultValue="vision" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="vision" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              <span>{currentTranslations.vision}</span>
            </TabsTrigger>
            <TabsTrigger value="mission" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span>{currentTranslations.mission}</span>
            </TabsTrigger>
            <TabsTrigger value="mandates" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              <span>{currentTranslations.mandates}</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="vision" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{currentTranslations.vision}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{currentTranslations.visionText}</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mission" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{currentTranslations.mission}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{currentTranslations.missionText}</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mandates" className="mt-6 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>{currentTranslations.mandates}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4 text-muted-foreground">{currentTranslations.mandatesIntro}</p>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex gap-2">
                    <span className="font-medium">1.</span>
                    <p>
                      By relying on the laws, policies and strategies of agriculture and natural resources development
                      in the country, it prepares laws, policies and strategies towards on agriculture, rural
                      employment, rural land use and natural resources for regional level and once it approved it is
                      enforced.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-medium">2.</span>
                    <p>
                      Prepares policies of agricultural production and natural resources for the region, prepares the
                      various inputs needed and also finds a suitable market for agricultural and natural resources
                      production.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-medium">3.</span>
                    <p>
                      The bureau leads and directs agencies under it, reviews their work plans, submitting their budgets
                      to the regional government for approval, and after approval it shall ensure the implementation of
                      their work plans.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-medium">4.</span>
                    <p>
                      Enables the environment to expand the use of agriculture, crop production and natural resources.
                      It ensures that awareness, investment and support are provided to farmers and agro-pastoralists to
                      reduce poverty and improve the livelihoods of the community.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-medium">5.</span>
                    <p>
                      Manages, directs, and coordinates programs and projects to achieve food security and
                      self-sufficiency in rural areas.
                    </p>
                  </div>

                  <p className="text-center italic mt-4">
                    <a href="#full-mandates" className="text-turquoise hover:underline">
                      {currentTranslations.viewAllMandates}
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>

      {/* Leadership Section */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">{currentTranslations.leadership}</h2>

        {/* Bureau Head - Centered and Prominent */}
        <div className="mb-8 flex justify-center">
          <Card className="overflow-hidden w-full max-w-md">
            <div className="relative aspect-square w-full max-h-80">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG-20250314-WA0006.jpg-RcVzrCyG0WLXWONAi8Hx5cpCW7y09Y.jpeg"
                alt="Abdulahi Mohamed Muse"
                fill
                className="object-cover"
              />
            </div>
            <CardHeader className="p-4 text-center bg-primary text-primary-foreground">
              <CardTitle className="text-xl">Abdulahi Mohamed Muse</CardTitle>
              <p className="text-sm">{currentTranslations.bureauHead}</p>
            </CardHeader>
          </Card>
        </div>

        {/* Deputy Head and Programs Director - Side by Side */}
        <div className="grid gap-6 sm:grid-cols-2">
          {[
            {
              name: "Abdirahman Nur Mahamed",
              title: currentTranslations.deputyHead,
              image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-symhweYoUap2WCCfkNIywEMiO8fKUw.png",
            },
            {
              name: "Ahmednur Abdi Mahamed",
              title: currentTranslations.programsDirector,
              image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-iTxDDhL1NtdRfJQQ6zrUMA5sOMKll2.png",
            },
          ].map((leader) => (
            <Card key={leader.name} className="overflow-hidden">
              <div className="relative aspect-square w-full">
                <Image src={leader.image || "/placeholder.svg"} alt={leader.name} fill className="object-cover" />
              </div>
              <CardHeader className="p-4 bg-green-50">
                <CardTitle className="text-xl">{leader.name}</CardTitle>
                <p className="text-sm text-muted-foreground">{leader.title}</p>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      {/* Organizational Structure */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">{currentTranslations.structure}</h2>
        <div className="overflow-hidden rounded-lg border bg-card p-6">
          <div className="mx-auto max-w-5xl">
            <div className="flex flex-col items-center">
              {/* Top Leadership */}
              <Card className="mb-4 w-64 bg-primary text-primary-foreground">
                <CardContent className="p-4 text-center">
                  <h3 className="font-bold">{currentTranslations.bureauHead}</h3>
                </CardContent>
              </Card>

              <div className="grid grid-cols-3 gap-4 w-full mb-4">
                <Card className="bg-green-100">
                  <CardContent className="p-3 text-center">
                    <h3 className="font-medium text-sm">Advisor</h3>
                  </CardContent>
                </Card>

                <Card className="bg-green-200">
                  <CardContent className="p-3 text-center">
                    <h3 className="font-medium text-sm">{currentTranslations.deputyHead}</h3>
                  </CardContent>
                </Card>

                <Card className="bg-green-100">
                  <CardContent className="p-3 text-center">
                    <h3 className="font-medium text-sm">D/Head Advisor</h3>
                  </CardContent>
                </Card>
              </div>

              <div className="h-8 w-1 bg-border"></div>

              {/* Main Sections */}
              <div className="grid w-full grid-cols-1 gap-8 md:grid-cols-2 mb-8">
                {/* Left Section */}
                <div className="space-y-4">
                  <h3 className="text-center font-bold text-green-700 border-b border-green-200 pb-2">Left Section</h3>

                  {/* SSI Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">SSI Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <ul className="text-sm space-y-1">
                        <li>• Irrigation Infrastructure</li>
                        <li>• Irrigation Water Management</li>
                        <li>• Irrigation Technology</li>
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Food Security Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">Food Security Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <ul className="text-sm space-y-1">
                        <li>• Food Security</li>
                        <li>• PSNP Program</li>
                        <li>• Resettlement</li>
                      </ul>
                    </CardContent>
                  </Card>

                  {/* NRM Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">NRM Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <ul className="text-sm space-y-1">
                        <li>• Soil & Water Conservation</li>
                        <li>• Forestry Development</li>
                        <li>• CRGE Project</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Right Section */}
                <div className="space-y-4">
                  <h3 className="text-center font-bold text-green-700 border-b border-green-200 pb-2">Right Section</h3>

                  {/* Extension Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">Extension Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <ul className="text-sm space-y-1">
                        <li>• Agri/Techno Transfer</li>
                        <li>• Agri/Communication</li>
                        <li>• Household Asset Building</li>
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Marketing Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">Marketing Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <p className="text-sm">Marketing operations</p>
                    </CardContent>
                  </Card>

                  {/* Crop Directorate */}
                  <Card>
                    <CardHeader className="bg-green-600 text-white p-3">
                      <CardTitle className="text-base">Crop Directorate</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3">
                      <ul className="text-sm space-y-1">
                        <li>• Input Supply</li>
                        <li>• Marketing</li>
                        <li>• Crop Production</li>
                        <li>• Crop Protection</li>
                        <li>• Crop Supply</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Supporting Directorates */}
              <div className="w-full">
                <h3 className="text-center font-bold text-green-700 border-b border-green-200 pb-2 mb-4">
                  Supporting Directorates, Programs and Projects
                </h3>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                  <Card className="bg-gray-50">
                    <CardContent className="p-3 text-center">
                      <p className="text-sm font-medium">DRDIP Project</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50">
                    <CardContent className="p-3 text-center">
                      <p className="text-sm font-medium">HR Directorate</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50">
                    <CardContent className="p-3 text-center">
                      <p className="text-sm font-medium">Finance & Logistics Directorate</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50">
                    <CardContent className="p-3 text-center">
                      <p className="text-sm font-medium">Planning and Budgeting Directorate</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-50">
                    <CardContent className="p-3 text-center">
                      <p className="text-sm font-medium">Public Relation Directorate</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Facts */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">{currentTranslations.facts}</h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="flex flex-col items-center justify-center p-6">
              <Calendar className="h-12 w-12 text-turquoise mb-4" />
              <h3 className="text-xl font-bold">{currentTranslations.factsEstablished}</h3>
              <p className="text-center text-muted-foreground">May 15, 1993</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center justify-center p-6">
              <Building className="h-12 w-12 text-turquoise mb-4" />
              <h3 className="text-xl font-bold">{currentTranslations.factsDirectorates}</h3>
              <p className="text-center text-muted-foreground">13 Total (8 Technical, 5 Support)</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center justify-center p-6">
              <Users className="h-12 w-12 text-turquoise mb-4" />
              <h3 className="text-xl font-bold">{currentTranslations.factsZones}</h3>
              <p className="text-center text-muted-foreground">11 Coordination Centers</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex flex-col items-center justify-center p-6">
              <Target className="h-12 w-12 text-turquoise mb-4" />
              <h3 className="text-xl font-bold">{currentTranslations.factsCoverage}</h3>
              <p className="text-center text-muted-foreground">93 Woredas & 6 Self-Administrative Cities</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Full Mandates Section */}
      <section id="full-mandates">
        <h2 className="mb-6 text-2xl font-bold">{currentTranslations.fullMandates}</h2>
        <Card>
          <CardContent className="p-6">
            <p className="mb-4 text-muted-foreground">{currentTranslations.mandatesIntro}</p>
            <div className="space-y-3 text-muted-foreground">
              <div className="flex gap-2">
                <span className="font-medium">1.</span>
                <p>
                  By relying on the laws, policies and strategies of agriculture and natural resources development in
                  the country, it prepares laws, policies and strategies towards on agriculture, rural employment, rural
                  land use and natural resources for regional level and once it approved it is enforced.
                </p>
              </div>
              <div className="flex gap-2">
                <span className="font-medium">2.</span>
                <p>
                  Prepares policies of agricultural production and natural resources for the region, prepares the
                  various inputs needed and also finds a suitable market for agricultural and natural resources
                  production.
                </p>
              </div>
              {/* Additional mandates would go here */}
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}

