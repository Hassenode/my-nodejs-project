import Link from "next/link"
import { FileText, Download, BarChart, FileArchive, FileSpreadsheet, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const resources = [
  {
    id: 1,
    title: "Farming Guide",
    description:
      "Comprehensive guide for farmers in the Somali Region covering crop selection, planting techniques, and pest management.",
    type: "PDF",
    icon: <FileText className="h-6 w-6" />,
    size: "2.4 MB",
  },
  {
    id: 2,
    title: "Market Prices",
    description: "Current and historical market prices for common agricultural products in the Somali Region.",
    type: "Excel",
    icon: <BarChart className="h-6 w-6" />,
    size: "1.8 MB",
  },
  {
    id: 3,
    title: "Research Report",
    description: "Latest research findings on climate-resilient agriculture practices for the Somali Region.",
    type: "PDF",
    icon: <FileText className="h-6 w-6" />,
    size: "3.5 MB",
  },
]

const marketData = [
  { crop: "Maize", price: "15.50 ETB/kg", demand: "High" },
  { crop: "Sorghum", price: "12.75 ETB/kg", demand: "Medium" },
  { crop: "Wheat", price: "18.25 ETB/kg", demand: "High" },
  { crop: "Beans", price: "22.00 ETB/kg", demand: "Medium" },
  { crop: "Tomatoes", price: "10.50 ETB/kg", demand: "Low" },
  { crop: "Onions", price: "14.00 ETB/kg", demand: "High" },
]

const resourceCategories = [
  {
    id: "reports",
    title: "Progress Reports",
    description: "Access official progress reports, annual reports, and program-specific assessments",
    icon: <FileArchive className="h-6 w-6" />,
    link: "/resources/progress-reports",
    featured: true,
  },
  {
    id: "guides",
    title: "Farming Guides",
    description: "Technical guides and manuals for farmers and agricultural practitioners",
    icon: <FileText className="h-6 w-6" />,
    link: "/resources",
  },
  {
    id: "data",
    title: "Agricultural Data",
    description: "Statistics, market data, and research findings on regional agriculture",
    icon: <FileSpreadsheet className="h-6 w-6" />,
    link: "/resources",
  },
  {
    id: "calendar",
    title: "Seasonal Calendar",
    description: "Agricultural calendar showing optimal planting and harvesting times",
    icon: <Calendar className="h-6 w-6" />,
    link: "/resources",
  },
]

export default function ResourcesPage() {
  return (
    <div className="container py-12">
      <h1 className="mb-8 text-3xl font-bold md:text-4xl">Resources</h1>

      {/* Resource Categories */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">Resource Categories</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {resourceCategories.map((category) => (
            <Card
              key={category.id}
              className={`transition-all hover:shadow-md ${category.featured ? "border-turquoise" : ""}`}
            >
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div
                    className={`rounded-full p-2 ${category.featured ? "bg-turquoise text-white" : "bg-primary/10 text-primary"}`}
                  >
                    {category.icon}
                  </div>
                  <CardTitle>{category.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </CardContent>
              <CardFooter>
                <Button asChild variant={category.featured ? "default" : "outline"} className="w-full">
                  <Link href={category.link}>Browse {category.title}</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>

      {/* Downloadable Resources */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">Downloadable Resources</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {resources.map((resource) => (
            <Card key={resource.id}>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="rounded-full bg-primary/10 p-2 text-primary">{resource.icon}</div>
                  <div>
                    <CardTitle>{resource.title}</CardTitle>
                    <CardDescription>
                      {resource.type} • {resource.size}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{resource.description}</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full gap-2">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>

      {/* Market Data */}
      <section>
        <h2 className="mb-6 text-2xl font-bold">Current Market Data</h2>
        <Card>
          <CardHeader>
            <CardTitle>Crop Market Prices</CardTitle>
            <CardDescription>
              Updated market prices as of March 15, 2025. Prices are subject to change based on market conditions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Crop</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Demand</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {marketData.map((item) => (
                  <TableRow key={item.crop}>
                    <TableCell className="font-medium">{item.crop}</TableCell>
                    <TableCell>{item.price}</TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                          item.demand === "High"
                            ? "bg-green-100 text-green-800"
                            : item.demand === "Medium"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-red-100 text-red-800"
                        }`}
                      >
                        {item.demand}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
          <CardFooter>
            <Button variant="outline" asChild>
              <Link href="#">Download Full Market Report</Link>
            </Button>
          </CardFooter>
        </Card>
      </section>
    </div>
  )
}

