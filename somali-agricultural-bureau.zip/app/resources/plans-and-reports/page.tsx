import Link from "next/link"
import { ArrowLeft, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const documents = [
  {
    id: 1,
    title: "Annual Work Plan 2024",
    description: "Detailed work plan outlining the Bureau's activities and targets for 2024",
    date: "December 2023",
    size: "3.5 MB",
    type: "PDF",
  },
  {
    id: 2,
    title: "Progress Report Q4 2023",
    description: "Quarterly report on agricultural development activities and achievements",
    date: "January 2024",
    size: "2.8 MB",
    type: "PDF",
  },
  {
    id: 3,
    title: "Five-Year Development Plan 2024-2028",
    description: "Strategic plan for agricultural development in the Somali Region",
    date: "March 2024",
    size: "4.2 MB",
    type: "PDF",
  },
]

export default function PlansAndReportsPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Resources
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Plans and Reports</h1>
        <p className="text-muted-foreground max-w-3xl">
          Access the Bureau's planning documents and progress reports that detail our activities and achievements.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {documents.map((doc) => (
          <Card key={doc.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{doc.title}</CardTitle>
                  <CardDescription className="mt-2">{doc.date}</CardDescription>
                </div>
                <div className="rounded-full bg-primary/10 p-2">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{doc.description}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex w-full items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {doc.type} • {doc.size}
                </span>
                <Button size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

