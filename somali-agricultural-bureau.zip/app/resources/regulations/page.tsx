import Link from "next/link"
import { ArrowLeft, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const regulations = [
  {
    id: 1,
    title: "Agricultural Land Use Regulations",
    description: "Regulations governing agricultural land use and management",
    number: "REG/2024/01",
    date: "March 2024",
    size: "2.3 MB",
    type: "PDF",
  },
  {
    id: 2,
    title: "Irrigation Systems Regulations",
    description: "Technical regulations for irrigation system development",
    number: "REG/2024/02",
    date: "February 2024",
    size: "1.9 MB",
    type: "PDF",
  },
  {
    id: 3,
    title: "Agricultural Input Quality Control Regulations",
    description: "Standards and regulations for agricultural inputs",
    number: "REG/2024/03",
    date: "January 2024",
    size: "2.5 MB",
    type: "PDF",
  },
]

export default function RegulationsPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Resources
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Regulations</h1>
        <p className="text-muted-foreground max-w-3xl">
          Access official regulations governing agricultural activities in the Somali Region.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {regulations.map((regulation) => (
          <Card key={regulation.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{regulation.title}</CardTitle>
                  <CardDescription className="mt-2">
                    {regulation.number} • {regulation.date}
                  </CardDescription>
                </div>
                <div className="rounded-full bg-primary/10 p-2">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{regulation.description}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex w-full items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {regulation.type} • {regulation.size}
                </span>
                <Button size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

