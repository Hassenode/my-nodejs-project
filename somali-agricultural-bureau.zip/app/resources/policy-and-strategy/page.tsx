"use client"

import { useTranslation } from "@/contexts/translation-context"
import Link from "next/link"
import { ArrowLeft, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function PolicyAndStrategyPage() {
  const { t, language } = useTranslation()

  // Translation keys for Policy and Strategy page
  const translations = {
    en: {
      title: "Policy and Strategy",
      backToResources: "Back to Resources",
      description:
        "Access the Bureau's key policy documents and strategic frameworks that guide agricultural development in the Somali Region.",
      policy1Title: "Agricultural Development Strategy 2024-2030",
      policy1Description: "Comprehensive strategy for agricultural development in the Somali Region",
      policy1Date: "March 2024",
      policy1Size: "2.8 MB",
      policy1Type: "PDF",
      policy2Title: "Climate-Smart Agriculture Policy",
      policy2Description: "Policy framework for promoting climate-resilient agricultural practices",
      policy2Date: "January 2024",
      policy2Size: "3.2 MB",
      policy2Type: "PDF",
      policy3Title: "Irrigation Development Strategy",
      policy3Description: "Strategic framework for expanding irrigation infrastructure",
      policy3Date: "December 2023",
      policy3Size: "4.1 MB",
      policy3Type: "PDF",
      download: "Download",
    },
    so: {
      title: "Siyaasadda iyo Istiraatiijiyada",
      backToResources: "Ku Noqo Ilaha",
      description:
        "Hel dukumeentiyada muhiimka ah ee siyaasadda iyo qaab-dhismeedyada istiraatiijiga ah ee Xafiiska ee hagaya horumarinta beeraha ee Gobolka Soomaalida.",
      policy1Title: "Istiraatiijiyada Horumarinta Beeraha 2024-2030",
      policy1Description: "Istiraatiijiyad dhammaystiran oo loogu talagalay horumarinta beeraha ee Gobolka Soomaalida",
      policy1Date: "Maarso 2024",
      policy1Size: "2.8 MB",
      policy1Type: "PDF",
      policy2Title: "Siyaasadda Beeraha Cimilada-Caqliga leh",
      policy2Description: "Qaab-dhismeedka siyaasadda ee horumarinta hab-dhaqannada beeraha ee adkeysi u leh cimilada",
      policy2Date: "Janaayo 2024",
      policy2Size: "3.2 MB",
      policy2Type: "PDF",
      policy3Title: "Istiraatiijiyada Horumarinta Waraabka",
      policy3Description: "Qaab-dhismeedka istiraatiijiga ah ee ballaarinta kaabayaasha waraabka",
      policy3Date: "Diseembar 2023",
      policy3Size: "4.1 MB",
      policy3Type: "PDF",
      download: "Soo Dejiso",
    },
    am: {
      title: "ፖሊሲ እና ስትራቴጂ",
      backToResources: "ወደ ሀብቶች ተመለስ",
      description: "በሶማሌ ክልል የግብርና ልማትን የሚመሩ የቢሮውን ዋና ዋና የፖሊሲ ሰነዶች እና ስትራቴጂያዊ ማዕቀፎችን ይመልከቱ።",
      policy1Title: "የግብርና ልማት ስትራቴጂ 2024-2030",
      policy1Description: "በሶማሌ ክልል ለግብርና ልማት ሁለገብ ስትራቴጂ",
      policy1Date: "መጋቢት 2024",
      policy1Size: "2.8 MB",
      policy1Type: "PDF",
      policy2Title: "የአየር ንብረት-ብልህ ግብርና ፖሊሲ",
      policy2Description: "የአየር ንብረት-ለውጥ የሚቋቋሙ የግብርና ልምዶችን ለማስፋፋት የፖሊሲ ማዕቀፍ",
      policy2Date: "ጥር 2024",
      policy2Size: "3.2 MB",
      policy2Type: "PDF",
      policy3Title: "የመስኖ ልማት ስትራቴጂ",
      policy3Description: "የመስኖ መሰረተ ልማትን ለማስፋፋት ስትራቴጂያዊ ማዕቀፍ",
      policy3Date: "ታህሳስ 2023",
      policy3Size: "4.1 MB",
      policy3Type: "PDF",
      download: "አውርድ",
    },
  }

  // Get translations based on current language
  const currentTranslations = translations[language] || translations.en

  const policies = [
    {
      id: 1,
      title: currentTranslations.policy1Title,
      description: currentTranslations.policy1Description,
      date: currentTranslations.policy1Date,
      size: currentTranslations.policy1Size,
      type: currentTranslations.policy1Type,
    },
    {
      id: 2,
      title: currentTranslations.policy2Title,
      description: currentTranslations.policy2Description,
      date: currentTranslations.policy2Date,
      size: currentTranslations.policy2Size,
      type: currentTranslations.policy2Type,
    },
    {
      id: 3,
      title: currentTranslations.policy3Title,
      description: currentTranslations.policy3Description,
      date: currentTranslations.policy3Date,
      size: currentTranslations.policy3Size,
      type: currentTranslations.policy3Type,
    },
  ]

  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            {currentTranslations.backToResources}
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">{currentTranslations.title}</h1>
        <p className="text-muted-foreground max-w-3xl">{currentTranslations.description}</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {policies.map((policy) => (
          <Card key={policy.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{policy.title}</CardTitle>
                  <CardDescription className="mt-2">{policy.date}</CardDescription>
                </div>
                <div className="rounded-full bg-primary/10 p-2">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{policy.description}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex w-full items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {policy.type} • {policy.size}
                </span>
                <Button size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  {currentTranslations.download}
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

