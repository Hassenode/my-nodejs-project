import Link from "next/link"
import { FileText, Download, Calendar, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const reports = {
  "2024": [
    {
      id: 1,
      title: "Semi-Annual Progress Report 2024",
      description: "Comprehensive report covering the Bureau's activities and achievements from January to June 2024.",
      date: "July 15, 2024",
      size: "3.2 MB",
      type: "PDF",
    },
    {
      id: 2,
      title: "DRDIP-II Implementation Progress Report",
      description:
        "Detailed report on the implementation progress of the Development Response to Displacement Impacts Project (Phase II).",
      date: "May 30, 2024",
      size: "4.5 MB",
      type: "PDF",
    },
    {
      id: 3,
      title: "PSNP-5 Quarterly Report Q1 2024",
      description: "First quarter report on the Productive Safety Net Program activities and outcomes.",
      date: "April 10, 2024",
      size: "2.8 MB",
      type: "PDF",
    },
  ],
  "2023": [
    {
      id: 4,
      title: "Annual Progress Report 2023",
      description:
        "Comprehensive annual report covering all Bureau activities, achievements, and challenges for the year 2023.",
      date: "February 15, 2024",
      size: "5.6 MB",
      type: "PDF",
    },
    {
      id: 5,
      title: "PACT Program Implementation Report",
      description: "Progress report on the implementation of the Pastoral Areas Climate Transformation Program.",
      date: "November 20, 2023",
      size: "3.7 MB",
      type: "PDF",
    },
    {
      id: 6,
      title: "CREW Mid-Year Assessment",
      description: "Mid-year assessment of the Climate Resilience and Economic Wellbeing Program implementation.",
      date: "August 5, 2023",
      size: "2.9 MB",
      type: "PDF",
    },
    {
      id: 7,
      title: "Irrigation Projects Status Report",
      description: "Status report on all irrigation projects implemented by the Bureau across the Somali Region.",
      date: "June 22, 2023",
      size: "4.1 MB",
      type: "PDF",
    },
  ],
  "2022": [
    {
      id: 8,
      title: "Annual Progress Report 2022",
      description:
        "Comprehensive annual report covering all Bureau activities, achievements, and challenges for the year 2022.",
      date: "January 30, 2023",
      size: "5.2 MB",
      type: "PDF",
    },
    {
      id: 9,
      title: "Drought Response Interventions Report",
      description: "Report on the Bureau's interventions to address the 2022 drought in the Somali Region.",
      date: "October 15, 2022",
      size: "3.8 MB",
      type: "PDF",
    },
    {
      id: 10,
      title: "Agricultural Extension Services Report",
      description: "Assessment of agricultural extension services provided to farmers across the region.",
      date: "July 8, 2022",
      size: "2.5 MB",
      type: "PDF",
    },
  ],
}

export default function ProgressReportsPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Resources
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Progress Reports</h1>
        <p className="text-muted-foreground max-w-3xl">
          Access the Bureau's official progress reports, including annual reports, program-specific assessments, and
          implementation updates. These documents provide transparent information about our activities, achievements,
          and challenges.
        </p>
      </div>

      <Tabs defaultValue="2024" className="w-full">
        <TabsList className="mb-6 w-full max-w-md">
          {Object.keys(reports).map((year) => (
            <TabsTrigger key={year} value={year} className="flex-1">
              {year}
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(reports).map(([year, yearReports]) => (
          <TabsContent key={year} value={year} className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {yearReports.map((report) => (
                <Card key={report.id} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{report.title}</CardTitle>
                        <CardDescription className="mt-1 flex items-center">
                          <Calendar className="mr-1 h-3.5 w-3.5" />
                          {report.date}
                        </CardDescription>
                      </div>
                      <div className="rounded-full bg-primary/10 p-2">
                        <FileText className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-sm text-muted-foreground">{report.description}</p>
                  </CardContent>
                  <CardFooter className="border-t pt-4">
                    <div className="flex w-full items-center justify-between">
                      <span className="text-xs text-muted-foreground">
                        {report.type} • {report.size}
                      </span>
                      <Button size="sm" className="gap-1">
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-12 rounded-lg bg-turquoise p-6 text-white">
        <h2 className="text-xl font-bold mb-2">Request Additional Reports</h2>
        <p className="mb-4">
          If you need access to specific reports or data not listed here, please contact our information office. We are
          committed to transparency and can provide additional information upon request.
        </p>
        <Button asChild variant="outline" className="bg-white text-turquoise hover:bg-gray-100">
          <Link href="/contact">Contact Information Office</Link>
        </Button>
      </div>
    </div>
  )
}

