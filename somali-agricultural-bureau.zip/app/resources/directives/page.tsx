import Link from "next/link"
import { ArrowLeft, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const directives = [
  {
    id: 1,
    title: "Agricultural Extension Services Directive",
    description: "Guidelines for the implementation of agricultural extension services",
    number: "DIR/2024/01",
    date: "March 2024",
    size: "1.5 MB",
    type: "PDF",
  },
  {
    id: 2,
    title: "Irrigation Water Management Directive",
    description: "Operational guidelines for irrigation water management",
    number: "DIR/2024/02",
    date: "February 2024",
    size: "1.8 MB",
    type: "PDF",
  },
  {
    id: 3,
    title: "Pest Control and Management Directive",
    description: "Guidelines for implementing pest control measures",
    number: "DIR/2024/03",
    date: "January 2024",
    size: "2.1 MB",
    type: "PDF",
  },
]

export default function DirectivesPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Resources
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Directives</h1>
        <p className="text-muted-foreground max-w-3xl">
          Access official directives and implementation guidelines issued by the Bureau.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {directives.map((directive) => (
          <Card key={directive.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{directive.title}</CardTitle>
                  <CardDescription className="mt-2">
                    {directive.number} • {directive.date}
                  </CardDescription>
                </div>
                <div className="rounded-full bg-primary/10 p-2">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{directive.description}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex w-full items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {directive.type} • {directive.size}
                </span>
                <Button size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

