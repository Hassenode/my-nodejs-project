import Link from "next/link"
import { ArrowLeft, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const documents = [
  {
    id: 1,
    title: "Farmer Training Manual",
    description: "Comprehensive guide for agricultural extension workers and farmers",
    category: "Training Manual",
    date: "March 2024",
    size: "4.2 MB",
    type: "PDF",
  },
  {
    id: 2,
    title: "Irrigation System Management Guidelines",
    description: "Technical guidelines for managing irrigation systems",
    category: "Technical Guide",
    date: "February 2024",
    size: "3.5 MB",
    type: "PDF",
  },
  {
    id: 3,
    title: "Pest Management Handbook",
    description: "Guidelines for integrated pest management practices",
    category: "Handbook",
    date: "January 2024",
    size: "2.8 MB",
    type: "PDF",
  },
]

export default function ManualsAndGuidelinesPage() {
  return (
    <div className="container py-12">
      <div className="mb-8 flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <Link href="/resources" className="text-turquoise hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Resources
          </Link>
        </div>
        <h1 className="text-3xl font-bold md:text-4xl">Manuals and Guidelines</h1>
        <p className="text-muted-foreground max-w-3xl">
          Access technical manuals, handbooks, and guidelines for agricultural practices.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {documents.map((doc) => (
          <Card key={doc.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{doc.title}</CardTitle>
                  <CardDescription className="mt-2">
                    {doc.category} • {doc.date}
                  </CardDescription>
                </div>
                <div className="rounded-full bg-primary/10 p-2">
                  <FileText className="h-5 w-5 text-primary" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{doc.description}</p>
            </CardContent>
            <CardFooter className="border-t pt-4">
              <div className="flex w-full items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {doc.type} • {doc.size}
                </span>
                <Button size="sm" className="gap-1">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

