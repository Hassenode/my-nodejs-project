"use client"

import { useTranslation } from "@/contexts/translation-context"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function NotFound() {
  const { t } = useTranslation()

  return (
    <div className="container flex flex-col items-center justify-center min-h-[70vh] text-center px-4 py-16">
      <h1 className="text-4xl font-bold text-gray-800 mb-4">{t("not_found.title") || "Page Not Found"}</h1>
      <p className="text-xl text-gray-600 max-w-md mb-8">
        {t("not_found.message") || "The page you are looking for doesn't exist or has been moved."}
      </p>
      <Button asChild className="flex items-center gap-2">
        <Link href="/">
          <ArrowLeft className="h-4 w-4" />
          {t("not_found.back_home") || "Back to Home"}
        </Link>
      </Button>
    </div>
  )
}

